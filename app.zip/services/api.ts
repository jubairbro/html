/**
 * API Service Entry Point
 * -----------------------
 * This file acts as a switchboard for the API services.
 * It conditionally exports either the mock API service or the real API service
 * based on the `USE_MOCK_API` flag.
 *
 * The rest of the application should import the `api` object from this file ONLY.
 * This ensures that the entire app can be switched from mock data to a live backend
 * by changing a single variable here.
 */
import { mockApi } from './mockApiService';
import { realApi } from './realApiService';

// --- API Switch ---
// Set this to `false` when you have a live backend API ready.
const USE_MOCK_API = false;

// The `api` object that the entire application will use.
export const api = USE_MOCK_API ? mockApi : realApi;