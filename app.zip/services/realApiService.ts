
/**
 * Real API Service
 * --------------------------
 * This file contains the live API logic that communicates with the Node.js backend.
 * It handles JWT authentication for secure requests.
 */
import { User, Transaction, SmsLog, SafeListItem, BlacklistItem, RedeemCode, SystemSettings, Broadcast, SmsApiResponse, TaskStatusResponse } from '../types';

const API_BASE_URL = '/api';

// --- JWT & Request Helpers ---
const getToken = () => localStorage.getItem('authToken');

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = getToken();
    const headers: HeadersInit = {
        'Content-Type': 'application/json',
        ...options.headers,
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
    });

    if (!response.ok) {
        try {
            const error = await response.json();
            throw new Error(error.message || `API request failed with status ${response.status}`);
        } catch (e) {
            if (e instanceof Error) throw e;
            throw new Error(`API request failed: ${response.statusText}`);
        }
    }
    
    const contentType = response.headers.get("content-type");
    if (contentType && contentType.indexOf("application/json") !== -1) {
        return response.json();
    }
    return Promise.resolve(null as T);
}

const handleSmsApiError = async (response: Response): Promise<string> => {
    switch(response.status) {
        case 401: return "Invalid API Key. Please check the key in the admin settings.";
        case 429: return "API Rate Limit Exceeded. Please try again later.";
        case 400:
        case 422:
             try {
                const errorData = await response.json();
                return errorData.message || "Invalid Input: The API rejected the phone number or amount.";
            } catch {
                return "Invalid Input: The API rejected the request.";
            }
        case 500:
        case 502:
        case 503:
        case 504:
            return "SMS API Server Error. Please try again later.";
        default:
            return `API Error: Received status code ${response.status}.`;
    }
}


export const realApi = {
    // --- Auth ---
    async getLoggedInUser(): Promise<User | null> {
        const token = getToken();
        if (!token) return Promise.resolve(null);
        try {
            const { user } = await request<{ user: User }>('/auth/me', { method: 'GET' });
            return user;
        } catch (error) {
            console.error('Session validation failed:', error);
            localStorage.removeItem('authToken');
            return null;
        }
    },
    async login(username: string, passwordIn: string): Promise<User | null> {
        const { token, user } = await request<{ token: string, user: User }>('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password: passwordIn }),
        });
        if (token && user) {
            localStorage.setItem('authToken', token);
            return user;
        }
        return null;
    },
    async logout(): Promise<void> {
        localStorage.removeItem('authToken');
        return Promise.resolve();
    },
    async register(username: string, firstName: string, passwordIn: string, referralCode?: string): Promise<User | null> {
         const { token, user } = await request<{ token: string, user: User }>('/auth/register', {
            method: 'POST',
            body: JSON.stringify({ username, firstName, password: passwordIn, referralCode }),
        });
        if (token && user) {
            localStorage.setItem('authToken', token);
            return user;
        }
        return null;
    },

    // --- User Actions ---
    async getRecentUsers(limit: number): Promise<User[]> {
        return request<User[]>(`/admin/users/recent?limit=${limit}`);
    },
    async claimDailyBonus(userId: number): Promise<{ success: boolean, message: string, amount?: number }> {
        return request(`/users/${userId}/claim-bonus`, { method: 'POST' });
    },
    async changePassword(userId: number, oldPass: string, newPass: string): Promise<{success: boolean, message: string}> {
        return request(`/users/${userId}/change-password`, { method: 'POST', body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass }) });
    },
    async redeemCode(userId: number, code: string): Promise<{success: boolean, message: string}> {
         return request(`/users/${userId}/redeem`, { method: 'POST', body: JSON.stringify({ code }) });
    },

    // --- Data Retrieval ---
    async getTransactions(userId: number, limit: number): Promise<Transaction[]> {
         return request<Transaction[]>(`/users/${userId}/transactions?limit=${limit}`);
    },
    async getLeaderboard(type: 'diamonds' | 'referrals' | 'smss', limit: number): Promise<User[]> {
        return request<User[]>(`/leaderboard?type=${type}&limit=${limit}`);
    },
    
    // --- Safelist ---
    async getSafelist(userId: number): Promise<SafeListItem[]> {
        return request<SafeListItem[]>(`/users/${userId}/safelist`);
    },
    async addToSafelist(userId: number, phoneNumber: string, note: string): Promise<{ success: boolean, message: string }> {
        return request(`/users/${userId}/safelist`, { method: 'POST', body: JSON.stringify({ phoneNumber, note }) });
    },
    async removeFromSafelist(userId: number, phoneNumber: string): Promise<{ success: boolean, message: string }> {
         return request(`/users/${userId}/safelist/${phoneNumber}`, { method: 'DELETE' });
    },

    // --- Broadcast ---
    async getRecentBroadcasts(limit: number): Promise<Broadcast[]> {
        return request<Broadcast[]>(`/broadcasts/recent?limit=${limit}`);
    },
    async getUnreadBroadcasts(userId: number): Promise<Broadcast[]> {
        return request<Broadcast[]>(`/broadcasts/unread`);
    },
    async getUnreadBroadcastsCount(userId: number): Promise<number> {
        return request<number>(`/broadcasts/unread/count`);
    },
    async markBroadcastsAsRead(userId: number): Promise<void> {
        return request(`/broadcasts/mark-read`, { method: 'POST' });
    },

    // --- Admin ---
    async getAllUsers(page: number, limit: number, searchTerm: string): Promise<{users: User[], total: number}> {
        return request<{users: User[], total: number}>(`/admin/users?page=${page}&limit=${limit}&search=${searchTerm}`);
    },
    async getSystemStats(): Promise<any> {
        return request<any>('/admin/stats');
    },
    async toggleUserBan(userId: number): Promise<{user: User | null, message: string}> {
        return request(`/admin/users/${userId}/toggle-ban`, { method: 'POST' });
    },
    async adminResetPassword(userId: number, newPass: string): Promise<{success: boolean, message: string}> {
        return request(`/admin/users/${userId}/reset-password`, { method: 'POST', body: JSON.stringify({ newPassword: newPass }) });
    },
    async manageDiamonds(userId: number, amount: number): Promise<{user: User | null, message: string}> {
        return request(`/admin/users/${userId}/manage-diamonds`, { method: 'POST', body: JSON.stringify({ amount }) });
    },
    async broadcastMessage(message: string): Promise<{ success: number, failed: number }> {
        return request('/admin/broadcast', { method: 'POST', body: JSON.stringify({ message }) });
    },
    async getSettings(): Promise<SystemSettings> {
        return request<SystemSettings>('/admin/settings');
    },
    async updateSettings(newSettings: SystemSettings): Promise<SystemSettings> {
        return request('/admin/settings', { method: 'PUT', body: JSON.stringify(newSettings) });
    },
    async getBlacklist(): Promise<BlacklistItem[]> {
        return request<BlacklistItem[]>('/admin/blacklist');
    },
    async addToBlacklist(phoneNumber: string, reason: string): Promise<{ success: boolean, message: string }> {
        return request('/admin/blacklist', { method: 'POST', body: JSON.stringify({ phoneNumber, reason }) });
    },
    async removeFromBlacklist(phoneNumber: string): Promise<{ success: boolean, message: string }> {
        return request(`/admin/blacklist/${phoneNumber}`, { method: 'DELETE' });
    },
    async getRedeemCodes(): Promise<RedeemCode[]> {
        return request<RedeemCode[]>('/admin/redeem-codes');
    },
    async createRedeemCode(code: string, amount: number, maxUsers: number): Promise<{ success: boolean, message: string }> {
        return request('/admin/redeem-codes', { method: 'POST', body: JSON.stringify({ code, amount, maxUsers }) });
    },
    async deleteRedeemCode(code: string): Promise<{ success: boolean, message: string }> {
        return request(`/admin/redeem-codes/${code}`, { method: 'DELETE' });
    },
    async getAllSmsLogs(page: number, limit: number): Promise<{logs: SmsLog[], total: number}> {
        return request<{logs: SmsLog[], total: number}>(`/admin/sms-logs?page=${page}&limit=${limit}`);
    },
    async getAllTransactions(page: number, limit: number): Promise<{transactions: Transaction[], total: number}> {
        return request<{transactions: Transaction[], total: number}>(`/admin/transactions?page=${page}&limit=${limit}`);
    },
    async getBroadcastHistory(): Promise<Broadcast[]> {
        return request<Broadcast[]>('/admin/broadcast-history');
    },
    async getAdmins(): Promise<User[]> {
        return request<User[]>('/admin/admins');
    },
    async addAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        return request('/admin/admins', { method: 'POST', body: JSON.stringify({ userId }) });
    },
    async removeAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        return request(`/admin/admins/${userId}`, { method: 'DELETE' });
    },
    
    // --- SMS API (THIS PART IS LIVE via Proxy) ---
    async sendSmsRequest(settings: SystemSettings, targetNumber: string, amount: number): Promise<SmsApiResponse> {
        const SMS_API_BASE_URL = '/api-proxy';
        const url = new URL(`${window.location.origin}${SMS_API_BASE_URL}/api`);
        url.searchParams.append('key', settings.apiKey);
        url.searchParams.append('num', targetNumber);
        url.searchParams.append('amount', amount.toString());

        try {
            const response = await fetch(url.toString(), {
                method: 'GET',
                signal: AbortSignal.timeout(settings.requestTimeout * 1000)
            });
            if (!response.ok) {
                const errorMessage = await handleSmsApiError(response);
                return { success: false, message: errorMessage };
            }
             const result = await response.json() as SmsApiResponse;
             if (result.success && result.task_id) {
                await request('/sms/log-attack', {
                    method: 'POST',
                    body: JSON.stringify({ targetNumber, amount, cost: amount * settings.smsCost, taskId: result.task_id })
                });
             }
            return result;
        } catch (error) {
            if (error instanceof Error) {
                if (error.name === 'TimeoutError') return { success: false, message: `API request timed out after ${settings.requestTimeout} seconds.` };
                if(error.message.includes('Failed to fetch')) return { success: false, message: "Network Error: Could not connect to the API." };
                return { success: false, message: error.message };
            }
            return { success: false, message: "An unknown network error occurred." };
        }
    },
    async checkTaskStatus(taskId: string): Promise<TaskStatusResponse> {
        const SMS_API_BASE_URL = '/api-proxy';
        const url = new URL(`${window.location.origin}${SMS_API_BASE_URL}/task_status`);
        url.searchParams.append('task_id', taskId);

        try {
            const response = await fetch(url.toString(), {
                method: 'GET',
                signal: AbortSignal.timeout(10000)
            });
            if (!response.ok) throw new Error(`API returned status ${response.status}`);
            
            const result = await response.json() as TaskStatusResponse;
             await request(`/sms/update-status`, {
                method: 'POST',
                body: JSON.stringify({ taskId: result.task_id, status: result.status, progress: result.progress })
             });
            return result;
        } catch (error) {
            return {
                task_id: taskId, status: 'failed', phone: 'Unknown', amount: 0,
                created_at: new Date().toISOString(), error: 'Failed to fetch status update.'
            };
        }
    },
    // The functions below are no longer needed here, as the logic is handled by the backend
    logSmsAttack: () => Promise.reject("This function is handled by the backend."),
    updateSmsLogStatus: () => Promise.reject("This function is handled by the backend."),
    getUserHistory: () => Promise.reject("Not implemented, use admin/sms-logs.")
};
