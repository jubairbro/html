/**
 * Real API Service
 * --------------------------
 * This file contains the live API logic that communicates with the Node.js backend.
 * It handles JWT authentication for secure requests.
 */
import { User, Transaction, SmsLog, SafeListItem, BlacklistItem, RedeemCode, SystemSettings, Broadcast, SmsApiResponse, TaskStatusResponse } from '../types';

const API_BASE_URL = '/api';

// --- JWT & Request Helpers ---
const getToken = () => localStorage.getItem('authToken');

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = getToken();
    const headers: HeadersInit = {
        'Content-Type': 'application/json',
        ...options.headers,
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
    });

    if (!response.ok) {
        try {
            const error = await response.json();
            throw new Error(error.message || `API request failed with status ${response.status}`);
        } catch (e) {
            throw new Error(`API request failed: ${response.statusText}`);
        }
    }
    
    // Handle cases where response might be empty (e.g., a 204 No Content)
    const contentType = response.headers.get("content-type");
    if (contentType && contentType.indexOf("application/json") !== -1) {
        return response.json();
    }
    return Promise.resolve(null as T);
}

const handleSmsApiError = async (response: Response): Promise<string> => {
    switch(response.status) {
        case 401: return "Invalid API Key. Please check the key in the admin settings.";
        case 429: return "API Rate Limit Exceeded. Please try again later.";
        case 400:
        case 422:
             try {
                const errorData = await response.json();
                return errorData.message || "Invalid Input: The API rejected the phone number or amount.";
            } catch {
                return "Invalid Input: The API rejected the request.";
            }
        case 500:
        case 502:
        case 503:
        case 504:
            return "SMS API Server Error. Please try again later.";
        default:
            return `API Error: Received status code ${response.status}.`;
    }
}


export const realApi = {
    // --- Auth ---
    async getLoggedInUser(): Promise<User | null> {
        const token = getToken();
        if (!token) return Promise.resolve(null);
        try {
            // This endpoint will verify the token and return fresh user data
            const { user } = await request<{ user: User }>('/auth/me', { method: 'GET' });
            return user;
        } catch (error) {
            console.error('Session validation failed:', error);
            localStorage.removeItem('authToken'); // Clean up invalid token
            return null;
        }
    },
    async login(username: string, passwordIn: string): Promise<User | null> {
        const { token, user } = await request<{ token: string, user: User }>('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password: passwordIn }),
        });
        if (token && user) {
            localStorage.setItem('authToken', token);
            return user;
        }
        return null;
    },
    async logout(): Promise<void> {
        localStorage.removeItem('authToken');
        return Promise.resolve();
    },
    async register(username: string, firstName: string, passwordIn: string, referralCode?: string): Promise<User | null> {
         const { token, user } = await request<{ token: string, user: User }>('/auth/register', {
            method: 'POST',
            body: JSON.stringify({ username, firstName, password: passwordIn, referralCode }),
        });
        if (token && user) {
            localStorage.setItem('authToken', token);
            return user;
        }
        return null;
    },

    // --- User Actions ---
    async getRecentUsers(limit: number): Promise<User[]> {
        return request<User[]>(`/users/recent?limit=${limit}`);
    },
    async claimDailyBonus(userId: number): Promise<{ success: boolean, message: string, amount?: number }> {
        return request(`/users/${userId}/claim-bonus`, { method: 'POST' });
    },
    async changePassword(userId: number, oldPass: string, newPass: string): Promise<{success: boolean, message: string}> {
        return request(`/users/${userId}/change-password`, { method: 'POST', body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass }) });
    },
    async redeemCode(userId: number, code: string): Promise<{success: boolean, message: string}> {
         return request(`/users/${userId}/redeem`, { method: 'POST', body: JSON.stringify({ code }) });
    },

    // --- Data Retrieval ---
    async getTransactions(userId: number, limit: number): Promise<Transaction[]> {
         return request<Transaction[]>(`/users/${userId}/transactions?limit=${limit}`);
    },
    async getLeaderboard(type: 'diamonds' | 'referrals' | 'smss', limit: number): Promise<User[]> {
        return request<User[]>(`/leaderboard?type=${type}&limit=${limit}`);
    },
    
    // --- Safelist ---
    async getSafelist(userId: number): Promise<SafeListItem[]> {
        console.warn('Real API: getSafelist not implemented. Needs backend.');
        return Promise.resolve([]);
    },
    async addToSafelist(userId: number, phoneNumber: string, note: string): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: addToSafelist not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    async removeFromSafelist(userId: number, phoneNumber: string): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: removeFromSafelist not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },

    // --- Broadcast ---
    async getRecentBroadcasts(limit: number): Promise<Broadcast[]> {
        console.warn('Real API: getRecentBroadcasts not implemented. Needs backend.');
        return Promise.resolve([]);
    },
    async getUnreadBroadcasts(userId: number): Promise<Broadcast[]> {
        console.warn('Real API: getUnreadBroadcasts not implemented. Needs backend.');
        return Promise.resolve([]);
    },
    async getUnreadBroadcastsCount(userId: number): Promise<number> {
        console.warn('Real API: getUnreadBroadcastsCount not implemented. Needs backend.');
        return Promise.resolve(0);
    },
    async markBroadcastsAsRead(userId: number): Promise<void> {
        console.warn('Real API: markBroadcastsAsRead not implemented. Needs backend.');
        return Promise.resolve();
    },

    // --- Admin ---
    async getAllUsers(page: number, limit: number, searchTerm: string): Promise<{users: User[], total: number}> {
        console.warn('Real API: getAllUsers not implemented. Needs backend.');
        return Promise.resolve({ users: [], total: 0 });
    },
    async getSystemStats(): Promise<any> {
        console.warn('Real API: getSystemStats not implemented. Needs backend.');
        return Promise.resolve({ users: 0, activeToday: 0, smss: 0, diamonds: 0, bannedUsers: 0, blacklistedNumbers: 0, totalTransactions: 0 });
    },
    async toggleUserBan(userId: number): Promise<{user: User | null, message: string}> {
        console.warn('Real API: toggleUserBan not implemented. Needs backend.');
        return Promise.resolve({ user: null, message: 'Backend not implemented.' });
    },
    async adminResetPassword(userId: number, newPass: string): Promise<{success: boolean, message: string}> {
        console.warn('Real API: adminResetPassword not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    async manageDiamonds(userId: number, amount: number): Promise<{user: User | null, message: string}> {
        console.warn('Real API: manageDiamonds not implemented. Needs backend.');
        return Promise.resolve({ user: null, message: 'Backend not implemented.' });
    },
    async broadcastMessage(message: string): Promise<{ success: number, failed: number }> {
        console.warn('Real API: broadcastMessage not implemented. Needs backend.');
        return Promise.resolve({ success: 0, failed: 0 });
    },
    async getSettings(): Promise<SystemSettings> {
        return request<SystemSettings>('/admin/settings');
    },
    async updateSettings(newSettings: SystemSettings): Promise<SystemSettings> {
        console.warn('Real API: updateSettings not implemented. Needs backend.');
        return Promise.resolve(newSettings);
    },
    async getBlacklist(): Promise<BlacklistItem[]> {
        console.warn('Real API: getBlacklist not implemented. Needs backend.');
        return Promise.resolve([]);
    },
    async addToBlacklist(phoneNumber: string, reason: string): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: addToBlacklist not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    async removeFromBlacklist(phoneNumber: string): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: removeFromBlacklist not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    async getRedeemCodes(): Promise<RedeemCode[]> {
        console.warn('Real API: getRedeemCodes not implemented. Needs backend.');
        return Promise.resolve([]);
    },
    async createRedeemCode(code: string, amount: number, maxUsers: number): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: createRedeemCode not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    async deleteRedeemCode(code: string): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: deleteRedeemCode not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    async getAllSmsLogs(page: number, limit: number): Promise<{logs: SmsLog[], total: number}> {
        console.warn('Real API: getAllSmsLogs not implemented. Needs backend.');
        return Promise.resolve({ logs: [], total: 0 });
    },
    async getAllTransactions(page: number, limit: number): Promise<{transactions: Transaction[], total: number}> {
        console.warn('Real API: getAllTransactions not implemented. Needs backend.');
        return Promise.resolve({ transactions: [], total: 0 });
    },
    async getBroadcastHistory(): Promise<Broadcast[]> {
        console.warn('Real API: getBroadcastHistory not implemented. Needs backend.');
        return Promise.resolve([]);
    },
    async getAdmins(): Promise<User[]> {
        console.warn('Real API: getAdmins not implemented. Needs backend.');
        return Promise.resolve([]);
    },
    async addAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: addAdmin not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    async removeAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        console.warn('Real API: removeAdmin not implemented. Needs backend.');
        return Promise.resolve({ success: false, message: 'Backend not implemented.' });
    },
    
    // --- SMS API (THIS PART IS LIVE via Proxy) ---
    async sendSmsRequest(settings: SystemSettings, targetNumber: string, amount: number): Promise<SmsApiResponse> {
        // This uses the Nginx proxy to the external service
        const SMS_API_BASE_URL = '/api-proxy';
        const url = new URL(`${window.location.origin}${SMS_API_BASE_URL}/api`);
        url.searchParams.append('key', settings.apiKey);
        url.searchParams.append('num', targetNumber);
        url.searchParams.append('amount', amount.toString());

        try {
            const response = await fetch(url.toString(), {
                method: 'GET',
                signal: AbortSignal.timeout(settings.requestTimeout * 1000)
            });
            if (!response.ok) {
                const errorMessage = await handleSmsApiError(response);
                return { success: false, message: errorMessage };
            }
             const result = await response.json() as SmsApiResponse;
             // Log the successful attack to our own backend
             if (result.success && result.task_id) {
                await request('/sms/log-attack', {
                    method: 'POST',
                    body: JSON.stringify({
                        targetNumber,
                        amount,
                        cost: amount * settings.smsCost,
                        taskId: result.task_id
                    })
                });
             }
            return result;
        } catch (error) {
            console.error("SMS API Request Error:", error);
            if (error instanceof Error) {
                if (error.name === 'TimeoutError') {
                    return { success: false, message: `API request timed out after ${settings.requestTimeout} seconds.` };
                }
                if(error.message.includes('Failed to fetch')) {
                    return { success: false, message: "Network Error: Could not connect to the API. Check your connection and proxy settings." };
                }
                return { success: false, message: error.message };
            }
            return { success: false, message: "An unknown network error occurred." };
        }
    },
    async checkTaskStatus(taskId: string): Promise<TaskStatusResponse> {
        const SMS_API_BASE_URL = '/api-proxy';
        const url = new URL(`${window.location.origin}${SMS_API_BASE_URL}/task_status`);
        url.searchParams.append('task_id', taskId);

        try {
            const response = await fetch(url.toString(), {
                method: 'GET',
                signal: AbortSignal.timeout(10000) // 10s timeout for status checks
            });
            if (!response.ok) {
                throw new Error(`API returned status ${response.status}`);
            }
            const result = await response.json() as TaskStatusResponse;
             // Update our own backend with the latest status
             await request(`/sms/update-status`, {
                method: 'POST',
                body: JSON.stringify({
                    taskId: result.task_id,
                    status: result.status,
                    progress: result.progress
                })
             });
            return result;
        } catch (error) {
            console.error("Task Status API Error:", error);
            return {
                task_id: taskId,
                status: 'failed',
                phone: 'Unknown',
                amount: 0,
                created_at: new Date().toISOString(),
                error: 'Failed to fetch status update.'
            };
        }
    },
    // The functions below are no longer needed here, as the logic is moved to the calls above
    logSmsAttack: () => Promise.reject("This function is handled internally by sendSmsRequest"),
    updateSmsLogStatus: () => Promise.reject("This function is handled internally by checkTaskStatus"),
    getUserHistory: () => {
        console.warn('Real API: getUserHistory not implemented. Needs backend.');
        return Promise.resolve([]);
    }
};