
import React, { useEffect, useState } from 'react';
// FIX: Updated react-router-dom imports for v6 compatibility.
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import AdminPage from './pages/AdminPage';
import ProfilePage from './pages/ProfilePage';
import LeaderboardPage from './pages/LeaderboardPage';
import Layout from './contexts/Layout';
import NotFoundPage from './pages/NotFoundPage';
import { ToastProvider } from './contexts/ToastContext';
import ToastContainer from './components/Toast';
import BroadcastModal from './components/BroadcastModal';
import { api } from './services/api';
import { Broadcast } from './types';

const PrivateRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-950">
        <div className="w-16 h-16 border-4 border-t-transparent border-sky-500 rounded-full animate-spin"></div>
      </div>
    );
  }
  // FIX: Replaced Redirect with Navigate for v6 compatibility.
  return user ? children : <Navigate to="/login" />;
};

const AdminRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) {
    return (
       <div className="flex items-center justify-center h-screen bg-slate-950">
        <div className="w-16 h-16 border-4 border-t-transparent border-sky-500 rounded-full animate-spin"></div>
      </div>
    );
  }
  // FIX: Replaced Redirect with Navigate for v6 compatibility.
  return user && user.isAdmin ? children : <Navigate to="/" />;
};

const AppContent: React.FC = () => {
    const { user, fetchUnreadCount } = useAuth();
    const [showBroadcastModal, setShowBroadcastModal] = useState(false);
    const [unreadBroadcasts, setUnreadBroadcasts] = useState<Broadcast[]>([]);

    useEffect(() => {
        const checkBroadcasts = async () => {
            if (user && !sessionStorage.getItem(`broadcast_checked_${user.id}`)) {
                const unread = await api.getUnreadBroadcasts(user.id);
                if (unread.length > 0) {
                    setUnreadBroadcasts(unread);
                    setShowBroadcastModal(true);
                    sessionStorage.setItem(`broadcast_checked_${user.id}`, 'true');
                }
            }
        };
        checkBroadcasts();
    }, [user]);

    const handleCloseBroadcastModal = async () => {
        if(user) {
            await api.markBroadcastsAsRead(user.id);
            await fetchUnreadCount(); // Refresh count in navbar
        }
        setShowBroadcastModal(false);
    }

    return (
        <>
            <Layout>
                {/* FIX: Replaced Switch with Routes and updated Route syntax for v6 compatibility. */}
                <Routes>
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/" element={<PrivateRoute><DashboardPage /></PrivateRoute>} />
                    <Route path="/profile" element={<PrivateRoute><ProfilePage /></PrivateRoute>} />
                    <Route path="/leaderboard" element={<PrivateRoute><LeaderboardPage /></PrivateRoute>} />
                    <Route path="/admin/*" element={<AdminRoute><AdminPage /></AdminRoute>} />
                    <Route path="*" element={<NotFoundPage />} />
                </Routes>
            </Layout>
            <BroadcastModal 
                isOpen={showBroadcastModal} 
                onClose={handleCloseBroadcastModal}
                broadcasts={unreadBroadcasts}
            />
        </>
    );
};

const App: React.FC = () => {
  return (
      <AuthProvider>
        <ToastProvider>
          <HashRouter>
              <AppContent />
              <ToastContainer />
          </HashRouter>
        </ToastProvider>
      </AuthProvider>
  );
};

export default App;
