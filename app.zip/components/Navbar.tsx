
import React, { useState } from 'react';
// FIX: Replaced useHistory with useNavigate for v6 compatibility.
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { styleText, APP_NAME } from '../constants';
import { api } from '../services/api';
import NotificationDropdown from './NotificationDropdown';
import { BellIcon } from '@heroicons/react/24/solid';

const Header: React.FC = () => {
  const { user, logout, unreadCount, fetchUnreadCount } = useAuth();
  // FIX: Replaced useHistory with useNavigate for v6 compatibility.
  const navigate = useNavigate();
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const handleLogout = () => {
    logout();
    // FIX: Replaced history.push with navigate for v6 compatibility.
    navigate('/login');
  };

  const handleNotificationsToggle = async () => {
    const currentlyOpening = !isNotificationsOpen;
    setIsNotificationsOpen(currentlyOpening);
    
    if (currentlyOpening && unreadCount > 0 && user) {
        await api.markBroadcastsAsRead(user.id);
        await fetchUnreadCount(); 
    }
  };
  
  // Desktop Nav Links
  const commonLinkClasses = "px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200";
  const activeLinkClasses = "bg-sky-500 text-white shadow-lg";
  const inactiveLinkClasses = "text-slate-300 hover:bg-slate-700";

  const navLink = ({ isActive }: { isActive: boolean }) => 
    `${commonLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`;

  return (
    <header className="glass-card fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-white font-bold text-xl">
              <NavLink to="/" className="flex items-center gap-2 group">
                <span className="text-3xl group-hover:animate-pulse">💣</span>
                <span className="hidden sm:inline bg-clip-text text-transparent bg-gradient-to-r from-sky-400 to-cyan-400 font-extrabold">{styleText(APP_NAME)}</span>
              </NavLink>
            </div>
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                  {/* FIX: Replaced exact prop with end for v6 compatibility. */}
                  <NavLink to="/" className={navLink} end>💣 {styleText('Bomb')}</NavLink>
                  <NavLink to="/profile" className={navLink}>👤 {styleText('Profile')}</NavLink>
                  <NavLink to="/leaderboard" className={navLink}>🏆 {styleText('Leaders')}</NavLink>
                  {user?.isAdmin && <NavLink to="/admin" className={navLink}>👑 {styleText('Admin')}</NavLink>}
              </div>
            </div>
          </div>
          <div className="flex items-center">
              <div className="flex items-center md:ml-6">
                <div className="relative">
                  <button
                    onClick={handleNotificationsToggle}
                    className="relative p-2 rounded-full text-slate-300 hover:text-white hover:bg-slate-700/50 transition-colors"
                    aria-label="View notifications"
                  >
                    <BellIcon className="h-6 w-6" />
                    {unreadCount > 0 && (
                      <span className="absolute top-1 right-1 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                      </span>
                    )}
                  </button>
                  <NotificationDropdown isOpen={isNotificationsOpen} onClose={() => setIsNotificationsOpen(false)} />
                </div>
              <div className="text-slate-300 mx-4 font-semibold text-lg flex items-center">
                💎 <span className="font-mono">{user?.diamonds.toLocaleString() || 0}</span>
              </div>
              <button
                onClick={handleLogout}
                className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-red-700 transition-colors shadow-md hidden md:block"
              >
                {styleText('Logout')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
