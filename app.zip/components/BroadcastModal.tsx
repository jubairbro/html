import React from 'react';
import { Broadcast } from '../types';
import { styleText } from '../constants';
import { XMarkIcon, SpeakerWaveIcon } from '@heroicons/react/24/solid';

interface BroadcastModalProps {
    isOpen: boolean;
    onClose: () => void;
    broadcasts: Broadcast[];
}

const BroadcastModal: React.FC<BroadcastModalProps> = ({ isOpen, onClose, broadcasts }) => {
    if (!isOpen || broadcasts.length === 0) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[100] p-4 animate-fade-in">
            <div className="glass-card rounded-2xl shadow-2xl w-full max-w-lg relative border border-sky-500/50">
                <button onClick={onClose} className="absolute top-4 right-4 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white">
                    <XMarkIcon className="h-6 w-6" />
                </button>
                <div className="p-8">
                    <div className="text-center mb-6">
                         <SpeakerWaveIcon className="h-12 w-12 mx-auto text-sky-500 dark:text-sky-400 mb-4" />
                        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{styleText('Recent Announcements')}</h2>
                    </div>
                    <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                        {broadcasts.map(broadcast => (
                            <div key={broadcast.id} className="bg-slate-200/50 dark:bg-slate-800/50 p-4 rounded-xl">
                                <p className="text-slate-800 dark:text-slate-200 text-sm">{broadcast.message}</p>
                                <p className="text-right text-xs text-slate-500 dark:text-slate-500 mt-2">{new Date(broadcast.sentAt).toLocaleString()}</p>
                            </div>
                        ))}
                    </div>
                     <button 
                        onClick={onClose} 
                        className="w-full mt-8 bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2.5 px-4 rounded-lg text-sm"
                     >
                        {styleText('Got It!')}
                    </button>
                </div>
            </div>
             <style>{`
                @keyframes fade-in {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                .animate-fade-in {
                    animation: fade-in 0.3s ease-out forwards;
                }
             `}</style>
        </div>
    );
};

export default BroadcastModal;