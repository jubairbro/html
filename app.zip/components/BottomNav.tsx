
import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { styleText } from '../constants';
import { HomeIcon, UserIcon, TrophyIcon, ShieldCheckIcon } from '@heroicons/react/24/solid';

const BottomNav: React.FC = () => {
    const { user } = useAuth();

    const commonLinkClasses = "flex flex-col items-center justify-center gap-1 w-full pt-2 pb-1 text-xs transition-colors duration-200";
    const activeLinkClasses = "text-sky-500 dark:text-sky-400";
    const inactiveLinkClasses = "text-slate-500 hover:text-sky-500 dark:hover:text-sky-400";

    const navLink = ({ isActive }: { isActive: boolean }) =>
        `${commonLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`;

    const menuItems = [
        { path: '/', name: 'Bomb', icon: HomeIcon },
        { path: '/profile', name: 'Profile', icon: UserIcon },
        { path: '/leaderboard', name: 'Leaders', icon: TrophyIcon },
    ];

    if (user?.isAdmin) {
        menuItems.push({ path: '/admin', name: 'Admin', icon: ShieldCheckIcon });
    }

    return (
        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 flex justify-around md:hidden z-40">
            {menuItems.map(item => (
                 // FIX: Replaced end prop with exact for v6 compatibility.
                 <NavLink key={item.path} to={item.path} className={navLink} end={item.path === '/'}>
                    <item.icon className="h-6 w-6" />
                    <span className="font-medium">{styleText(item.name)}</span>
                </NavLink>
            ))}
        </nav>
    );
};

export default BottomNav;
