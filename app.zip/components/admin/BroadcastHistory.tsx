import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Broadcast } from '../../types';
import { styleText } from '../../constants';

const BroadcastHistory: React.FC = () => {
    const [history, setHistory] = useState<Broadcast[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchHistory = async () => {
            setLoading(true);
            const data = await api.getBroadcastHistory();
            setHistory(data);
            setLoading(false);
        };
        fetchHistory();
    }, []);

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-sky-500 rounded-full animate-spin"></div></div>;
    }

    return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">{styleText('Broadcast History')}</h1>

            <div className="space-y-4">
                {history.length > 0 ? history.map(log => (
                    <div key={log.id} className="bg-slate-100 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 p-4 rounded-xl">
                        <p className="text-slate-800 dark:text-slate-200 mb-2">"{log.message}"</p>
                        <div className="text-xs text-slate-500 dark:text-slate-400 flex justify-between items-center">
                            <span>Sent by Admin ID {log.adminId} on {new Date(log.sentAt).toLocaleString()}</span>
                            <span>
                                <span className="text-green-600 dark:text-green-400">Success: {log.stats.success}</span> | <span className="text-red-600 dark:text-red-400">Failed: {log.stats.failed}</span>
                            </span>
                        </div>
                    </div>
                )) : (
                    <p className="text-center text-slate-500 dark:text-slate-400 py-8">No broadcast history found.</p>
                )}
            </div>
        </div>
    );
};

export default BroadcastHistory;