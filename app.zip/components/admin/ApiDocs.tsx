
import React from 'react';
import { styleText } from '../../constants';

const ApiDocs: React.FC = () => {
    return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">{styleText('API Documentation')}</h1>
            
            <div className="space-y-8 bg-slate-100 dark:bg-slate-900/50 p-6 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200">
                
                <section>
                    <h2 className="text-xl font-bold mb-2">🚀 {styleText('Ultimate SMS API Server')}</h2>
                    <p className="text-slate-600 dark:text-slate-400">{styleText('Powerful • Fast • Reliable')}</p>
                </section>
                
                <hr className="border-slate-300 dark:border-slate-700"/>

                <section>
                    <h3 className="text-lg font-semibold mb-2">📨 {styleText('Send SMS (Instant Background)')}</h3>
                    <p className="mb-3 text-slate-600 dark:text-slate-400">{styleText('Send OTP bombs with instant response. The process runs in the background.')}</p>
                    <code className="block bg-slate-200 dark:bg-slate-800 p-3 rounded-md text-sm font-mono text-sky-600 dark:text-sky-400 whitespace-pre-wrap">
                        {styleText('GET /api?key=API_KEY&num=01XXXXXXXXX&amount=10')}
                    </code>
                </section>
                
                 <section>
                    <h3 className="text-lg font-semibold mb-2">📊 {styleText('Check Task Status')}</h3>
                    <p className="mb-3 text-slate-600 dark:text-slate-400">{styleText('Track the progress of your bombing task.')}</p>
                    <code className="block bg-slate-200 dark:bg-slate-800 p-3 rounded-md text-sm font-mono text-sky-600 dark:text-sky-400 whitespace-pre-wrap">
                        {styleText('GET /task_status?task_id=TASK_ID')}
                    </code>
                </section>
                
                 <section>
                    <h3 className="text-lg font-semibold mb-2">🔑 {styleText('Check Key Status')}</h3>
                    <p className="mb-3 text-slate-600 dark:text-slate-400">{styleText('View your daily limit and usage.')}</p>
                    <code className="block bg-slate-200 dark:bg-slate-800 p-3 rounded-md text-sm font-mono text-sky-600 dark:text-sky-400 whitespace-pre-wrap">
                        {styleText('GET /key_status?key=API_KEY')}
                    </code>
                </section>

                <hr className="border-slate-300 dark:border-slate-700"/>
                
                <section className="text-center text-slate-500 dark:text-slate-400 text-sm">
                    <p>{styleText('Developer: @JubairZ | Telegram: @JubairFF')}</p>
                </section>
            </div>
        </div>
    );
};

export default ApiDocs;
