import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/api';
import { SmsLog } from '../../types';
import { styleText } from '../../constants';

const SmsLogs: React.FC = () => {
    const [logs, setLogs] = useState<SmsLog[]>([]);
    const [totalLogs, setTotalLogs] = useState(0);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const logsPerPage = 15;

    const fetchLogs = useCallback(async (page: number) => {
        setLoading(true);
        const { logs: fetchedLogs, total } = await api.getAllSmsLogs(page, logsPerPage);
        setLogs(fetchedLogs);
        setTotalLogs(total);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchLogs(currentPage);
    }, [currentPage, fetchLogs]);

    const totalPages = Math.ceil(totalLogs / logsPerPage);

    const getStatusChip = (status: SmsLog['status']) => {
        switch (status) {
            case 'completed': return <span className="px-2 py-1 text-xs font-semibold text-green-800 bg-green-200 dark:text-green-200 dark:bg-green-900 rounded-full">Completed</span>;
            case 'failed': return <span className="px-2 py-1 text-xs font-semibold text-red-800 bg-red-200 dark:text-red-200 dark:bg-red-900 rounded-full">Failed</span>;
            case 'running': return <span className="px-2 py-1 text-xs font-semibold text-sky-800 bg-sky-200 dark:text-sky-200 dark:bg-sky-900 rounded-full">Running</span>;
            case 'started': return <span className="px-2 py-1 text-xs font-semibold text-yellow-800 bg-yellow-200 dark:text-yellow-200 dark:bg-yellow-900 rounded-full">Started</span>;
        }
    };
    
    return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">{styleText('System-Wide SMS Logs')}</h1>

            <div className="bg-slate-100 dark:bg-slate-900/50 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-700 dark:text-slate-300">
                        <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-200 dark:bg-slate-700">
                            <tr>
                                <th scope="col" className="px-6 py-3">User</th>
                                <th scope="col" className="px-6 py-3">Target</th>
                                <th scope="col" className="px-6 py-3">Amount</th>
                                <th scope="col" className="px-6 py-3">Cost</th>
                                <th scope="col" className="px-6 py-3">Status</th>
                                <th scope="col" className="px-6 py-3">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                <tr><td colSpan={6} className="text-center py-8"><div className="w-8 h-8 border-2 border-t-transparent border-sky-500 rounded-full animate-spin mx-auto"></div></td></tr>
                            ) : logs.map(log => (
                                <tr key={log.id} className="border-b border-slate-200 dark:border-slate-700 hover:bg-slate-200/50 dark:hover:bg-slate-700/50">
                                    <td className="px-6 py-4">{log.username} ({log.userId})</td>
                                    <td className="px-6 py-4 font-mono">{log.targetNumber}</td>
                                    <td className="px-6 py-4">{log.amount}</td>
                                    <td className="px-6 py-4 text-red-500 dark:text-red-400">{log.cost} 💎</td>
                                    <td className="px-6 py-4">{getStatusChip(log.status)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {logs.length === 0 && !loading && <p className="text-center py-8 text-slate-500 dark:text-slate-400">No SMS logs found.</p>}
            </div>
            
             {totalPages > 1 && (
                <div className="flex justify-center mt-6">
                    <nav className="inline-flex rounded-md shadow">
                        <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-white bg-white dark:bg-slate-800 rounded-l-lg hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-50 border border-slate-300 dark:border-slate-600">Prev</button>
                        <span className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-900 border-t border-b border-slate-300 dark:border-slate-600">Page {currentPage} of {totalPages}</span>
                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-white bg-white dark:bg-slate-800 rounded-r-lg hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-50 border border-slate-300 dark:border-slate-600">Next</button>
                    </nav>
                </div>
            )}
        </div>
    );
};

export default SmsLogs;