import React, { useState, useEffect, useRef } from 'react';
import { Broadcast } from '../types';
import { api } from '../services/api';
import { styleText } from '../constants';

interface NotificationDropdownProps {
    isOpen: boolean;
    onClose: () => void;
}

const NotificationDropdown: React.FC<NotificationDropdownProps> = ({ isOpen, onClose }) => {
    const [broadcasts, setBroadcasts] = useState<Broadcast[]>([]);
    const [loading, setLoading] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            const fetchBroadcasts = async () => {
                setLoading(true);
                const data = await api.getRecentBroadcasts(5);
                setBroadcasts(data);
                setLoading(false);
            };
            fetchBroadcasts();
        }
    }, [isOpen]);
    
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                onClose();
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [onClose]);

    if (!isOpen) return null;

    return (
        <div
          ref={dropdownRef}
          className="origin-top-right absolute right-0 mt-2 w-80 rounded-md shadow-lg bg-white dark:bg-slate-700 ring-1 ring-black ring-opacity-5 focus:outline-none"
          role="menu"
          aria-orientation="vertical"
        >
          <div className="py-1">
            <div className="px-4 py-2 border-b border-slate-200 dark:border-slate-600">
              <p className="text-sm font-semibold text-slate-900 dark:text-white">{styleText('Notifications')}</p>
            </div>
            <div className="max-h-80 overflow-y-auto">
              {loading ? (
                <p className="text-center text-slate-500 dark:text-slate-400 py-4 text-sm">{styleText('Loading...')}</p>
              ) : broadcasts.length > 0 ? (
                broadcasts.map(log => (
                  <div key={log.id} className="block px-4 py-3 text-sm text-slate-700 dark:text-slate-300 border-b border-slate-200/50 dark:border-slate-600/50">
                    <p className="font-semibold text-slate-800 dark:text-slate-100 mb-1">📢 {styleText('System Broadcast')}</p>
                    <p className="text-xs mb-1">{log.message}</p>
                    <p className="text-right text-xs text-slate-500 dark:text-slate-500">{new Date(log.sentAt).toLocaleDateString()}</p>
                  </div>
                ))
              ) : (
                <p className="text-center text-slate-500 dark:text-slate-400 py-4 text-sm">{styleText('No new notifications.')}</p>
              )}
            </div>
          </div>
        </div>
    );
};

export default NotificationDropdown;