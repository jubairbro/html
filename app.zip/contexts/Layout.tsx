
import React from 'react';
import { useLocation } from 'react-router-dom';
import Header from '../components/Navbar';
import BottomNav from '../components/BottomNav';
import Footer from '../components/Footer';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isLoginPage = location.pathname === '/login';
  const isAdminPage = location.pathname.startsWith('/admin');

  return (
    <div className="min-h-screen font-sans flex flex-col relative">
        <div className="absolute top-0 left-0 w-full h-full bg-grid-white/[0.05] -z-10"></div>
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent to-slate-900 -z-10"></div>
        
        {!isLoginPage && <Header />}
        <main className={`flex-grow w-full ${!isLoginPage ? "pt-24 pb-20 md:pb-4" : ""}`}>
            {children}
        </main>
        {!isLoginPage && !isAdminPage && <Footer />}
        {!isLoginPage && !isAdminPage && <BottomNav />}
        <style>{`
          .bg-grid-white\\/\\[0\\.05\\] {
            background-image: linear-gradient(to right, rgba(255, 255, 255, 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
            background-size: 40px 40px;
          }
        `}</style>
    </div>
  );
};

export default Layout;