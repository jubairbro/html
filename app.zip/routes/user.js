
const express = require('express');
const router = express.Router();

module.exports = (User, Transaction, SmsLog, SafeListItem, RedeemCode, getSettings) => {
    
    // Middleware to ensure the acting user matches the user in the URL
    const isOwner = (req, res, next) => {
        if (req.user.id !== parseInt(req.params.userId)) {
            return res.status(403).json({ message: 'You are not authorized to perform this action.' });
        }
        next();
    };

    router.post('/:userId/claim-bonus', isOwner, async (req, res) => {
        const user = req.user;
        const settings = await getSettings();
        const today = new Date().toISOString().split('T')[0];
        const lastClaimDate = user.dailyBonusClaimed ? new Date(user.dailyBonusClaimed).toISOString().split('T')[0] : null;

        if (lastClaimDate === today) {
            return res.status(400).json({ success: false, message: "You have already claimed your daily bonus today." });
        }
        
        user.diamonds += settings.dailyBonus;
        user.dailyBonusClaimed = new Date();
        await user.save();
        await Transaction.create({ userId: user.id, username: user.username, amount: settings.dailyBonus, reason: 'daily_bonus' });
        
        res.json({ success: true, message: `You claimed ${settings.dailyBonus} diamonds!`, amount: settings.dailyBonus });
    });

    router.post('/:userId/change-password', isOwner, async (req, res) => {
        const { oldPassword, newPassword } = req.body;
        const userWithPassword = await User.findByPk(req.user.id);
        
        if (!userWithPassword || !await require('bcryptjs').compare(oldPassword, userWithPassword.password)) {
            return res.status(401).json({ success: false, message: "Incorrect old password." });
        }
        
        userWithPassword.password = await require('bcryptjs').hash(newPassword, 10);
        await userWithPassword.save();
        res.json({ success: true, message: "Password changed successfully." });
    });
    
    router.post('/:userId/redeem', isOwner, async (req, res) => {
        const { code } = req.body;
        const user = req.user;
        const codeData = await RedeemCode.findByPk(code);

        if (!codeData || !codeData.isActive) return res.status(404).json({ success: false, message: "Invalid or inactive code." });
        if (codeData.usedBy.includes(user.id)) return res.status(400).json({ success: false, message: "You have already used this code." });
        if (codeData.usedBy.length >= codeData.maxUsers) {
            codeData.isActive = false;
            await codeData.save();
            return res.status(400).json({ success: false, message: "This code has reached its usage limit." });
        }

        user.diamonds += codeData.amount;
        codeData.usedBy = [...codeData.usedBy, user.id];
        if (codeData.usedBy.length >= codeData.maxUsers) codeData.isActive = false;
        
        await user.save();
        await codeData.save();
        await Transaction.create({ userId: user.id, username: user.username, amount: codeData.amount, reason: `redeem_${code}` });
        
        res.json({ success: true, message: `Successfully redeemed ${codeData.amount} diamonds!` });
    });

    router.get('/:userId/transactions', isOwner, async (req, res) => {
        const { limit = 10 } = req.query;
        const transactions = await Transaction.findAll({
            where: { userId: req.params.userId },
            limit: parseInt(limit),
            order: [['timestamp', 'DESC']]
        });
        res.json(transactions);
    });
    
    router.get('/:userId/sms-logs', isOwner, async (req, res) => {
        const { limit = 10 } = req.query;
        const logs = await SmsLog.findAll({
            where: { userId: req.params.userId },
            limit: parseInt(limit),
            order: [['timestamp', 'DESC']]
        });
        res.json(logs);
    });

    // --- Safelist ---
    router.get('/:userId/safelist', isOwner, async (req, res) => {
        const safelist = await SafeListItem.findAll({ where: { userId: req.params.userId } });
        res.json(safelist);
    });
    
    router.post('/:userId/safelist', isOwner, async (req, res) => {
        const { phoneNumber, note } = req.body;
        const exists = await SafeListItem.findOne({ where: { userId: req.params.userId, phoneNumber } });
        if (exists) return res.status(409).json({ success: false, message: 'Number already in safelist.' });
        
        await SafeListItem.create({ userId: req.params.userId, phoneNumber, note });
        res.status(201).json({ success: true, message: 'Added to safelist.' });
    });
    
    router.delete('/:userId/safelist/:phoneNumber', isOwner, async (req, res) => {
        const deleted = await SafeListItem.destroy({ where: { userId: req.params.userId, phoneNumber: req.params.phoneNumber } });
        res.json({ success: !!deleted, message: deleted ? 'Removed from safelist.' : 'Number not found.' });
    });

    return router;
};