
const express = require('express');
const { Op } = require('sequelize');
const router = express.Router();

module.exports = (User, Transaction, SmsLog, BlacklistItem, RedeemCode, Broadcast, Setting, getSettings) => {
    
    // --- Dashboard ---
    router.get('/stats', async (req, res) => {
        const stats = {
            users: await User.count(),
            activeToday: await User.count({ where: { lastActive: { [Op.gt]: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
            smss: await SmsLog.count(),
            diamonds: await User.sum('diamonds'),
            bannedUsers: await User.count({ where: { isBlocked: true } }),
            blacklistedNumbers: await BlacklistItem.count(),
            totalTransactions: await Transaction.count()
        };
        res.json(stats);
    });

    router.get('/users/recent', async (req, res) => {
        const { limit = 5 } = req.query;
        const users = await User.findAll({ order: [['joinedDate', 'DESC']], limit: parseInt(limit), attributes: { exclude: ['password'] }});
        res.json(users);
    });

    // --- User Management ---
    router.get('/users', async (req, res) => {
        const { page = 1, limit = 10, search = '' } = req.query;
        const offset = (page - 1) * limit;
        const whereClause = search ? {
            [Op.or]: [
                { id: { [Op.like]: `%${search}%` } },
                { username: { [Op.like]: `%${search}%` } },
                { firstName: { [Op.like]: `%${search}%` } }
            ]
        } : {};
        const { count, rows } = await User.findAndCountAll({ where: whereClause, limit: parseInt(limit), offset, attributes: { exclude: ['password'] }, order: [['id', 'ASC']] });
        res.json({ users: rows, total: count });
    });

    router.post('/users/:userId/toggle-ban', async (req, res) => {
        if (parseInt(req.params.userId) === 1) return res.status(403).json({ message: 'Cannot ban the owner.' });
        const user = await User.findByPk(req.params.userId);
        if (!user) return res.status(404).json({ message: 'User not found.' });
        user.isBlocked = !user.isBlocked;
        await user.save();
        const { password, ...userWithoutPassword } = user.toJSON();
        res.json({ user: userWithoutPassword, message: `User has been ${user.isBlocked ? 'banned' : 'unbanned'}.` });
    });

    router.post('/users/:userId/reset-password', async (req, res) => {
        const user = await User.findByPk(req.params.userId);
        if (!user) return res.status(404).json({ message: 'User not found.' });
        user.password = await require('bcryptjs').hash(req.body.newPassword, 10);
        await user.save();
        res.json({ success: true, message: "Password reset successfully." });
    });

    router.post('/users/:userId/manage-diamonds', async (req, res) => {
        const { amount } = req.body;
        const user = await User.findByPk(req.params.userId);
        if (!user) return res.status(404).json({ message: 'User not found.' });
        if (amount < 0 && user.diamonds < Math.abs(amount)) return res.status(400).json({ message: 'User has insufficient diamonds to deduct.' });
        
        user.diamonds += amount;
        await user.save();
        await Transaction.create({ userId: user.id, username: user.username, amount, reason: amount > 0 ? 'admin_gift' : 'admin_deduct' });
        
        const { password, ...userWithoutPassword } = user.toJSON();
        res.json({ user: userWithoutPassword, message: `Successfully managed diamonds.` });
    });

    // --- Content & Settings ---
    router.post('/broadcast', async (req, res) => {
        const { message, buttonText, buttonUrl } = req.body;
        const successCount = await User.count({ where: { isBlocked: false } });
        const broadcast = await Broadcast.create({ 
            adminId: req.user.id, 
            message, 
            buttonText,
            buttonUrl,
            stats: { success: successCount, failed: 0 } 
        });
        res.status(201).json(broadcast.stats);
    });
    
    router.get('/broadcast-history', async (req, res) => {
        const history = await Broadcast.findAll({ order: [['sentAt', 'DESC']] });
        res.json(history);
    });

    router.put('/settings', async (req, res) => {
        const settings = req.body;
        for (const key in settings) {
            await Setting.upsert({ key, value: JSON.stringify(settings[key]) });
        }
        res.json(await getSettings());
    });
    
    // --- Lists ---
    router.get('/blacklist', async (req, res) => res.json(await BlacklistItem.findAll({ order: [['addedAt', 'DESC']] })));
    router.post('/blacklist', async (req, res) => {
        const { phoneNumber, reason } = req.body;
        const [_, created] = await BlacklistItem.findOrCreate({ where: { phoneNumber }, defaults: { reason, addedBy: req.user.id } });
        res.status(created ? 201 : 409).json({ success: created, message: created ? 'Added to blacklist.' : 'Number already blacklisted.' });
    });
    router.delete('/blacklist/:phoneNumber', async (req, res) => {
        const deleted = await BlacklistItem.destroy({ where: { phoneNumber: req.params.phoneNumber } });
        res.json({ success: !!deleted, message: deleted ? 'Removed from blacklist.' : 'Number not found.' });
    });
    
    // --- Redeem Codes ---
    router.get('/redeem-codes', async (req, res) => res.json(await RedeemCode.findAll({ order: [['createdAt', 'DESC']] })));
    router.post('/redeem-codes', async (req, res) => {
        const { code, amount, maxUsers } = req.body;
        const [_, created] = await RedeemCode.findOrCreate({ where: { code }, defaults: { amount, maxUsers, createdBy: req.user.id } });
        res.status(created ? 201 : 409).json({ success: created, message: created ? 'Code created.' : 'Code already exists.' });
    });
    router.delete('/redeem-codes/:code', async (req, res) => {
        const deleted = await RedeemCode.destroy({ where: { code: req.params.code } });
        res.json({ success: !!deleted, message: deleted ? 'Code deleted.' : 'Code not found.' });
    });
    
    // --- Logs ---
    router.get('/sms-logs', async (req, res) => {
        const { page = 1, limit = 15 } = req.query;
        const offset = (page - 1) * limit;
        const { count, rows } = await SmsLog.findAndCountAll({ order: [['timestamp', 'DESC']], limit: parseInt(limit), offset });
        res.json({ logs: rows, total: count });
    });
    router.get('/transactions', async (req, res) => {
        const { page = 1, limit = 15 } = req.query;
        const offset = (page - 1) * limit;
        const { count, rows } = await Transaction.findAndCountAll({ order: [['timestamp', 'DESC']], limit: parseInt(limit), offset });
        res.json({ transactions: rows, total: count });
    });

    // --- Admin Management ---
    router.get('/admins', async (req, res) => {
        const admins = await User.findAll({ where: { isAdmin: true }, attributes: { exclude: ['password'] } });
        res.json(admins);
    });
    router.post('/admins', async (req, res) => {
        const user = await User.findByPk(req.body.userId);
        if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
        user.isAdmin = true;
        await user.save();
        res.json({ success: true, message: 'Admin added.' });
    });
    router.delete('/admins/:userId', async (req, res) => {
        if (parseInt(req.params.userId) === 1) return res.status(403).json({ message: 'Cannot remove the owner.' });
        const user = await User.findByPk(req.params.userId);
        if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
        user.isAdmin = false;
        await user.save();
        res.json({ success: true, message: 'Admin removed.' });
    });

    return router;
};