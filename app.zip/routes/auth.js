
const express = require('express');
const router = express.Router();

module.exports = (User, bcrypt, jwt, JWT_SECRET, getSettings) => {

    router.post('/register', async (req, res) => {
        try {
            let { username, firstName, password, referralCode } = req.body;
            if (!username || !firstName || !password) {
                return res.status(400).json({ message: 'Username, First Name, and Password are required' });
            }
            
            username = username.toLowerCase().trim();
            if (await User.findOne({ where: { username } })) {
                return res.status(400).json({ message: 'Username is already taken.' });
            }
            
            const hashedPassword = await bcrypt.hash(password, 10);
            
            const newUser = await User.create({
                username, firstName, password: hashedPassword,
                diamonds: referralCode ? 50 : 0 // Initial bonus for using a code
            });

            // Handle referral
            if (referralCode) {
                // Find referrer by their unique referral code, not their primary key ID
                const referrer = await User.findOne({ where: { referralCode: referralCode } });
                if(referrer) {
                    const settings = await getSettings();
                    referrer.referralCount += 1;
                    referrer.diamonds += settings.referralBonus;
                    await referrer.save();
                }
            }
            
            // Re-fetch to get the final state after hooks
            const finalUser = await User.findByPk(newUser.id);
            const { password: _, ...userToReturn } = finalUser.toJSON();
            const token = jwt.sign({ id: finalUser.id }, JWT_SECRET, { expiresIn: '7d' });
            res.status(201).json({ token, user: userToReturn });

        } catch (error) {
            console.error("Registration Error:", error);
            res.status(500).json({ message: 'Server error during registration' });
        }
    });

    router.post('/login', async (req, res) => {
        try {
            const { username, password } = req.body;
            const user = await User.findOne({ where: { username: username.toLowerCase() } });
            
            if (!user || !(await bcrypt.compare(password, user.password))) {
                return res.status(401).json({ message: 'Invalid username or password.' });
            }
            if (user.isBlocked) {
                return res.status(403).json({ message: 'Your account has been banned.' });
            }
            
            user.lastActive = new Date();
            await user.save();
            
            const { password: _, ...userToReturn } = user.toJSON();
            const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
            res.json({ token, user: userToReturn });
        } catch (error) {
            console.error("Login Error:", error);
            res.status(500).json({ message: 'Server error during login' });
        }
    });

    router.get('/me', (req, res, next) => {
        // This route needs the auth middleware, so we add it here
        const authMiddleware = async (req, res, next) => {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ message: 'Authorization token required' });
            const token = authHeader.split(' ')[1];
            try {
                const decoded = jwt.verify(token, JWT_SECRET);
                const user = await User.findByPk(decoded.id, { attributes: { exclude: ['password'] } });
                if (!user) return res.status(401).json({ message: 'User not found' });
                req.user = user;
                next();
            } catch (error) {
                res.status(401).json({ message: 'Invalid or expired token' });
            }
        };
        authMiddleware(req, res, next);
    }, (req, res) => {
        res.json({ user: req.user });
    });
    
    return router;
};
