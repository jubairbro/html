import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { User } from '../types';
import { styleText } from '../constants';

type LeaderboardType = 'diamonds' | 'referrals' | 'smss';

const LeaderboardPage: React.FC = () => {
    const [leaderboardType, setLeaderboardType] = useState<LeaderboardType>('smss');
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLeaderboard = async () => {
            setLoading(true);
            setUsers([]); // Clear previous users to show loader
            const data = await api.getLeaderboard(leaderboardType, 20);
            setUsers(data);
            setLoading(false);
        };
        fetchLeaderboard();
    }, [leaderboardType]);
    
    const getMedal = (index: number) => {
        if (index === 0) return <span className="text-3xl">🥇</span>;
        if (index === 1) return <span className="text-2xl">🥈</span>;
        if (index === 2) return <span className="text-xl">🥉</span>;
        return <span className="text-slate-500 dark:text-slate-400 font-bold">{index + 1}</span>;
    };

    const renderValue = (user: User) => {
        switch (leaderboardType) {
            case 'diamonds': return `💎 ${user.diamonds.toLocaleString()}`;
            case 'referrals': return `👥 ${user.referralCount.toLocaleString()}`;
            case 'smss': return `💣 ${user.totalSmss.toLocaleString()}`;
        }
    };
    
    const getTabClass = (type: LeaderboardType) => {
      return `w-full py-2.5 text-sm font-semibold rounded-lg transition-all duration-300 ${leaderboardType === type ? 'bg-sky-500 text-white shadow-lg' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`;
    };

    const SkeletonLoader = () => (
        <div className="space-y-3">
            {[...Array(10)].map((_, i) => (
                <div key={i} className="flex items-center glass-card p-4 rounded-lg animate-pulse">
                    <div className="w-12 h-6 bg-slate-300 dark:bg-slate-700 rounded-md"></div>
                    <div className="flex-1 h-6 bg-slate-300 dark:bg-slate-700 rounded-md mx-4"></div>
                    <div className="w-24 h-6 bg-slate-300 dark:bg-slate-700 rounded-md"></div>
                </div>
            ))}
        </div>
    );

    return (
        <div className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-8 px-4 sm:px-0 text-center">{styleText('🏆 Leaderboards')}</h1>
            
            <div className="glass-card shadow-2xl rounded-2xl p-4 md:p-6">
                <div className="flex justify-center bg-slate-200 dark:bg-slate-900/50 p-1 rounded-xl mb-6">
                    <button onClick={() => setLeaderboardType('smss')} className={getTabClass('smss')}>{styleText('Top Bombers')}</button>
                    <button onClick={() => setLeaderboardType('diamonds')} className={getTabClass('diamonds')}>{styleText('Top Richest')}</button>
                    <button onClick={() => setLeaderboardType('referrals')} className={getTabClass('referrals')}>{styleText('Top Referrers')}</button>
                </div>
                
                {loading ? (
                   <SkeletonLoader />
                ) : (
                    <div className="space-y-3">
                        {users.map((user, index) => (
                            <div key={user.id} className="flex items-center bg-slate-200/50 dark:bg-slate-800/50 p-4 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors border border-transparent hover:border-sky-500">
                                <div className="w-12 text-center font-bold text-lg flex items-center justify-center">{getMedal(index)}</div>
                                <div className="flex-1 font-semibold text-slate-800 dark:text-slate-200 ml-4">{user.firstName}</div>
                                <div className="font-bold text-sky-500 dark:text-sky-400 font-mono text-lg">{renderValue(user)}</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default LeaderboardPage;