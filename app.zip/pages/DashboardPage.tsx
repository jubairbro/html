import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { api } from '../services/api';
import { styleText } from '../constants';
import { SmsLog, SystemSettings, TaskStatusResponse } from '../types';
import { CheckCircleIcon, XCircleIcon, ArrowPathIcon } from '@heroicons/react/24/solid';

const DashboardPage: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const { addToast } = useToast();
  const [target, setTarget] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [attackStatus, setAttackStatus] = useState<SmsLog | null>(null);
  const pollingInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const fetchSettings = async () => {
        const appSettings = await api.getSettings();
        setSettings(appSettings);
    };
    fetchSettings();
    return () => {
        if (pollingInterval.current) {
            clearInterval(pollingInterval.current);
        }
    };
  }, []);
  
  const cost = settings ? (parseInt(amount) || 0) * settings.smsCost : 0;

  const handleStatusUpdate = async (taskId: string) => {
    try {
        const statusRes: TaskStatusResponse = await api.checkTaskStatus(taskId);
        const finalStatus: SmsLog['status'] = statusRes.status === 'completed' ? 'completed' : (statusRes.status === 'not_found' ? 'failed' : statusRes.status);
        
        if (statusRes.status === 'completed' || statusRes.status === 'failed' || statusRes.status === 'not_found') {
            if (pollingInterval.current) clearInterval(pollingInterval.current);
             setAttackStatus(prev => prev ? {...prev, status: finalStatus, progress: finalStatus === 'completed' ? 'Finished!' : 'Task ended.'} : null);
             await api.updateSmsLogStatus(taskId, finalStatus);
        } else { // running
            setAttackStatus(prev => prev ? {...prev, status: 'running', progress: statusRes.progress} : null);
            await api.updateSmsLogStatus(taskId, 'running', statusRes.progress);
        }
    } catch (error) {
        console.error("Failed to check task status", error);
        if (pollingInterval.current) clearInterval(pollingInterval.current);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !settings) return;
    
    if (pollingInterval.current) clearInterval(pollingInterval.current);
    setAttackStatus(null);

    const parsedAmount = parseInt(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return addToast('Please enter a valid amount.', 'error');
    }
    if (parsedAmount > settings.maxSmsAmount) {
      return addToast(`Maximum amount is ${settings.maxSmsAmount}.`, 'error');
    }
    if (!/^01[3-9]\d{8}$/.test(target)) {
        return addToast('Invalid BD phone number format (e.g., 017XXXXXXXX).', 'error');
    }
    if (user.diamonds < cost) {
      return addToast('Insufficient diamonds.', 'error');
    }
    
    setLoading(true);
    try {
        const result = await api.sendSmsRequest(settings, target, parsedAmount);
        if (result.success && result.task_id) {
            addToast(`Attack on ${target} initiated successfully!`, 'success');
            const localLog = await api.logSmsAttack(user.id, target, parsedAmount, cost, result.task_id);
            setAttackStatus(localLog);
            await refreshUser();
            setTarget('');
            setAmount('');
            
            // Start polling
            pollingInterval.current = setInterval(() => {
                handleStatusUpdate(result.task_id!);
            }, 3000); // Poll every 3 seconds

        } else {
            addToast(result.message, 'error');
        }
    } catch(err: any) {
        console.error("SMS API Request Error:", err);
        addToast(err.message || "An unknown error occurred.", 'error');
    } finally {
        setLoading(false);
    }
  };
  
  const StatusIcon = ({ status, className = "h-5 w-5" }: { status: SmsLog['status'], className?: string }) => {
    if (status === 'completed') return <CheckCircleIcon className={`${className} text-green-400`} />;
    if (status === 'failed') return <XCircleIcon className={`${className} text-red-400`} />;
    if (status === 'running') return <ArrowPathIcon className={`${className} text-sky-400 animate-spin`} />;
    return <ArrowPathIcon className={`${className} text-sky-400`} />;
  };

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <div className="w-full max-w-5xl mx-auto py-6 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
            <div className="lg:col-span-3">
                <div className="glass-card shadow-2xl rounded-2xl p-6 md:p-8 relative overflow-hidden">
                    <div className="absolute -top-10 -right-10 w-40 h-40 bg-sky-600/20 rounded-full blur-3xl"></div>
                    <h2 className="text-2xl font-bold text-white mb-2">{styleText('Initiate Attack')}</h2>
                    <p className="text-slate-400 mb-6">{styleText('Lock on your target below')}</p>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <input type="tel" value={target} onChange={e => setTarget(e.target.value)} placeholder="Target Number (e.g., 017...)"
                            className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500"/>
                        <div className="grid grid-cols-2 gap-4">
                            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder={`Amount (Max ${settings?.maxSmsAmount || 200})`}
                                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500"/>
                            <div className="flex items-center justify-center bg-slate-900/50 border border-slate-700 rounded-lg">
                                <p className="text-slate-400">{styleText('Cost:')} <span className="font-bold text-sky-400">{cost} 💎</span></p>
                            </div>
                        </div>
                        <button type="submit" disabled={loading} className="w-full py-3.5 font-semibold text-white bg-sky-600 rounded-lg hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 focus:ring-offset-slate-900 disabled:bg-slate-600 transition-all duration-300 flex items-center justify-center shadow-lg">
                            {loading ? <div className="w-6 h-6 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : `🚀 ${styleText('LAUNCH ATTACK')}`}
                        </button>
                    </form>
                </div>
            </div>
            <div className="lg:col-span-2">
                <div className="glass-card shadow-xl rounded-2xl p-6 h-full">
                <h2 className="text-xl font-bold text-white mb-4">{styleText('Live Attack Status')}</h2>
                {attackStatus ? (
                    <div className="flex items-center gap-4 bg-slate-900/50 p-4 rounded-lg">
                        <StatusIcon status={attackStatus.status} className="h-8 w-8 flex-shrink-0" />
                        <div>
                            <p className="font-semibold text-white">Target: <span className="font-mono">{attackStatus.targetNumber}</span></p>
                            <p className="text-sm text-slate-300">
                                Status: <span className="font-semibold capitalize">{attackStatus.status}</span>
                                {attackStatus.progress && ` - ${attackStatus.progress}`}
                            </p>
                        </div>
                    </div>
                ) : (
                    <div className="text-center py-10">
                        <p className="text-slate-400">{styleText('Standby for next mission...')}</p>
                    </div>
                )}
                </div>
            </div>
            </div>
        </div>
    </div>
  );
};

export default DashboardPage;