
import React, { useState } from 'react';
// FIX: Updated react-router-dom imports for v6 compatibility.
import { Routes, Route, NavLink } from 'react-router-dom';
import AdminDashboard from '../components/admin/AdminDashboard';
import UserManagement from '../components/admin/UserManagement';
import Broadcast from '../components/admin/Broadcast';
import Settings from '../components/admin/Settings';
import Blacklist from '../components/admin/Blacklist';
import RedeemCodes from '../components/admin/RedeemCodes';
import AdminManagement from '../components/admin/AdminManagement';
import SmsLogs from '../components/admin/SmsLogs';
import Transactions from '../components/admin/Transactions';
import BroadcastHistory from '../components/admin/BroadcastHistory';
import ApiDocs from '../components/admin/ApiDocs';
import NotFoundPage from './NotFoundPage';
import { styleText } from '../constants';
import { ChartPieIcon, UsersIcon, SpeakerWaveIcon, Cog6ToothIcon, ShieldExclamationIcon, TicketIcon, KeyIcon, EnvelopeIcon, BanknotesIcon, ClockIcon, Bars3Icon, XMarkIcon, ArrowUturnLeftIcon, DocumentTextIcon } from '@heroicons/react/24/solid';

const AdminPage: React.FC = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    // FIX: useRouteMatch is removed in v6. Nested routes are now relative.

    const commonLinkClasses = "flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors duration-200 w-full text-left";
    const activeLinkClasses = "bg-sky-600 text-white shadow-lg";
    const inactiveLinkClasses = "text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white";

    const navLink = ({ isActive }: { isActive: boolean }) => 
        `${commonLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`;

    const menuItems = [
        { path: '', name: 'Dashboard', icon: ChartPieIcon },
        { path: 'users', name: 'User Management', icon: UsersIcon },
        { path: 'broadcast', name: 'Broadcast', icon: SpeakerWaveIcon },
        { path: 'sms-logs', name: 'SMS Logs', icon: EnvelopeIcon },
        { path: 'transactions', name: 'Transactions', icon: BanknotesIcon },
        { path: 'redeem-codes', name: 'Redeem Codes', icon: TicketIcon },
        { path: 'blacklist', name: 'Blacklist', icon: ShieldExclamationIcon },
        { path: 'broadcast-history', name: 'Broadcast History', icon: ClockIcon },
        { path: 'admins', name: 'Admin Management', icon: KeyIcon },
        { path: 'settings', name: 'Settings', icon: Cog6ToothIcon },
        { path: 'api-docs', name: 'API Docs', icon: DocumentTextIcon },
    ];
  
    const sidebarContent = (
         <nav className="space-y-2">
            {menuItems.map(item => (
                <NavLink key={item.name} 
                    to={item.path === '' ? '/admin' : `/admin/${item.path}`} 
                    className={navLink} 
                    // FIX: Replaced exact prop with end for v6 compatibility.
                    end={item.path === ''} 
                    onClick={() => setIsSidebarOpen(false)}
                >
                    <item.icon className="h-5 w-5 mr-3 flex-shrink-0"/>
                    {styleText(item.name)}
                </NavLink>
            ))}
             <div className="pt-4 mt-4 border-t border-slate-300 dark:border-slate-700">
                 <NavLink 
                    to="/" 
                    className={`${commonLinkClasses} ${inactiveLinkClasses}`}
                    onClick={() => setIsSidebarOpen(false)}
                 >
                    <ArrowUturnLeftIcon className="h-5 w-5 mr-3 flex-shrink-0"/>
                    {styleText('Back to App')}
                </NavLink>
            </div>
        </nav>
    );

    return (
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
             <div className="px-4 mb-6 md:hidden flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{styleText('Admin Menu')}</h2>
                <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-800">
                    {isSidebarOpen ? <XMarkIcon className="h-6 w-6"/> : <Bars3Icon className="h-6 w-6"/>}
                </button>
            </div>

            <div className={`fixed inset-0 z-40 md:hidden transition-opacity ${isSidebarOpen ? 'bg-black/60' : 'pointer-events-none opacity-0'}`} onClick={() => setIsSidebarOpen(false)}></div>
            
            <div className={`fixed top-0 left-0 h-full w-64 bg-slate-100/90 dark:bg-slate-800/90 backdrop-blur-lg border-r border-slate-200 dark:border-slate-700 z-50 transform transition-transform md:hidden ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="p-4">
                     <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">{styleText('Admin Panel')}</h2>
                    {sidebarContent}
                </div>
            </div>

            <div className="flex flex-col md:flex-row gap-8">
                <aside className="hidden md:block md:w-64 flex-shrink-0 px-4">
                     <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 border border-slate-200 dark:border-slate-700">
                        <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-6 px-2">{styleText('Admin Panel')}</h2>
                        {sidebarContent}
                    </div>
                </aside>

                <main className="flex-1 min-w-0 px-4 sm:px-0">
                    {/* FIX: Replaced Switch with Routes and updated Route syntax for v6 compatibility. */}
                    <Routes>
                        <Route index element={<AdminDashboard />} />
                        <Route path="users" element={<UserManagement />} />
                        <Route path="broadcast" element={<Broadcast />} />
                        <Route path="sms-logs" element={<SmsLogs />} />
                        <Route path="transactions" element={<Transactions />} />
                        <Route path="settings" element={<Settings />} />
                        <Route path="blacklist" element={<Blacklist />} />
                        <Route path="redeem-codes" element={<RedeemCodes />} />
                        <Route path="broadcast-history" element={<BroadcastHistory />} />
                        <Route path="admins" element={<AdminManagement />} />
                        <Route path="api-docs" element={<ApiDocs />} />
                        <Route path="*" element={<NotFoundPage />} />
                    </Routes>
                </main>
            </div>
        </div>
    );
};

export default AdminPage;