
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { api } from '../services/api';
import { styleText, REFERRAL_DOMAIN } from '../constants';
import { SafeListItem, Transaction, SmsLog } from '../types';
import { ClipboardIcon, CheckIcon, UserCircleIcon, ShieldCheckIcon, LockClosedIcon, TicketIcon, ArrowRightOnRectangleIcon, GiftIcon, BanknotesIcon, ClockIcon } from '@heroicons/react/24/solid';
// FIX: Replaced useHistory with useNavigate for v6 compatibility.
import { useNavigate } from 'react-router-dom';

type ActiveTab = 'profile' | 'history' | 'security' | 'safelist' | 'redeem';

const StatWidget: React.FC<{title: string, value: string, icon: React.ReactNode}> = ({title, value, icon}) => (
    <div className="glass-card p-4 rounded-xl flex items-center gap-4">
        <div className="p-3 bg-slate-800/50 rounded-lg">{icon}</div>
        <div>
            <p className="text-slate-400 text-sm font-medium">{title}</p>
            <p className="text-xl font-bold text-white">{value}</p>
        </div>
    </div>
);


const ProfilePage: React.FC = () => {
    const { user, refreshUser, logout } = useAuth();
    const { addToast } = useToast();
    // FIX: Replaced useHistory with useNavigate for v6 compatibility.
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState<ActiveTab>('profile');

    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [smsLogs, setSmsLogs] = useState<SmsLog[]>([]);
    const [safelist, setSafelist] = useState<SafeListItem[]>([]);
    const [newSafeNumber, setNewSafeNumber] = useState('');
    const [newSafeNote, setNewSafeNote] = useState('');
    const [copied, setCopied] = useState(false);
    
    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const [redeemCode, setRedeemCode] = useState('');
    const [canClaimBonus, setCanClaimBonus] = useState(false);


    const fetchProfileData = useCallback(async () => {
        if (user) {
            const [userTransactions, userSafelist, userSmsLogs] = await Promise.all([
                api.getTransactions(user.id, 10),
                api.getSafelist(user.id),
                api.getUserHistory(user.id, 10),
            ]);
            setTransactions(userTransactions);
            setSafelist(userSafelist);
            setSmsLogs(userSmsLogs);
        }
    }, [user]);

    const checkBonusStatus = useCallback(() => {
        if (user?.dailyBonusClaimed) {
            const today = new Date().toISOString().split('T')[0];
            const lastClaimDate = new Date(user.dailyBonusClaimed).toISOString().split('T')[0];
            setCanClaimBonus(today !== lastClaimDate);
        } else if (user) {
            setCanClaimBonus(true);
        }
    }, [user]);

    useEffect(() => {
        fetchProfileData();
        checkBonusStatus();
    }, [fetchProfileData, checkBonusStatus]);
    
    const handleAddSafelist = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        if (!/^01[3-9]\d{8}$/.test(newSafeNumber)) {
            return addToast('Invalid Bangladeshi phone number format.', 'error');
        }
        const result = await api.addToSafelist(user.id, newSafeNumber, newSafeNote);
        if (result.success) {
            addToast(result.message, 'success');
            setNewSafeNumber('');
            setNewSafeNote('');
            await fetchProfileData();
        } else {
            addToast(result.message, 'error');
        }
    };

    const handleRemoveSafelist = async (phoneNumber: string) => {
        if (!user) return;
        const result = await api.removeFromSafelist(user.id, phoneNumber);
        if (result.success) {
            addToast(result.message, 'info');
            await fetchProfileData();
        } else {
            addToast(result.message, 'error');
        }
    };
    
    const copyReferralLink = () => {
        if(!user) return;
        const link = `https://${REFERRAL_DOMAIN}/#/login?ref=${user.referralCode}`;
        navigator.clipboard.writeText(link);
        setCopied(true);
        addToast('Referral link copied!', 'success');
        setTimeout(() => setCopied(false), 2000);
    };

    const handleChangePassword = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        if (newPassword !== confirmPassword) {
            return addToast("New passwords do not match.", 'error');
        }
        if (newPassword.length < 6) {
            return addToast("Password must be at least 6 characters long.", 'error');
        }

        const result = await api.changePassword(user.id, oldPassword, newPassword);
        if (result.success) {
            addToast(result.message, 'success');
            setOldPassword('');
            setNewPassword('');
            setConfirmPassword('');
        } else {
            addToast(result.message, 'error');
        }
    };

    const handleRedeemCode = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!user || !redeemCode) return;
        const result = await api.redeemCode(user.id, redeemCode);
        if(result.success) {
            addToast(result.message, 'success');
            setRedeemCode('');
            await refreshUser();
        } else {
            addToast(result.message, 'error');
        }
    };
    
    const handleClaimBonus = async () => {
        if (!user || !canClaimBonus) return;
        const result = await api.claimDailyBonus(user.id);
        if (result.success) {
            addToast(result.message, 'success');
            await refreshUser();
            setCanClaimBonus(false);
        } else {
            addToast(result.message, 'error');
        }
    }

    const handleLogout = () => {
        logout();
        // FIX: Replaced history.push with navigate for v6 compatibility.
        navigate('/login');
    };

    if (!user) return null;
    
    const getStatusChip = (status: SmsLog['status']) => {
        switch (status) {
            case 'completed': return <span className="px-2 py-1 text-xs font-semibold text-green-800 bg-green-200 dark:text-green-200 dark:bg-green-900 rounded-full">Completed</span>;
            case 'failed': return <span className="px-2 py-1 text-xs font-semibold text-red-800 bg-red-200 dark:text-red-200 dark:bg-red-900 rounded-full">Failed</span>;
            case 'running': return <span className="px-2 py-1 text-xs font-semibold text-sky-800 bg-sky-200 dark:text-sky-200 dark:bg-sky-900 rounded-full">Running</span>;
            case 'started': return <span className="px-2 py-1 text-xs font-semibold text-yellow-800 bg-yellow-200 dark:text-yellow-200 dark:bg-yellow-900 rounded-full">Started</span>;
        }
    };

    const TabButton: React.FC<{tab: ActiveTab, label: string, icon: React.ElementType}> = ({tab, label, icon: Icon}) => (
         <button onClick={() => setActiveTab(tab)} className={`flex-1 flex items-center justify-center gap-2 p-3 text-sm font-semibold rounded-lg transition-all duration-300 ${activeTab === tab ? 'bg-sky-500 text-white shadow-lg' : 'text-slate-300 hover:bg-slate-700'}`}>
            <Icon className="h-5 w-5"/>
            <span className="hidden sm:inline">{styleText(label)}</span>
        </button>
    );

    return (
        <div className="max-w-5xl mx-auto py-6 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
                <h1 className="text-4xl font-extrabold text-white">{styleText(`${user.firstName}'s Profile`)}</h1>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 px-4 sm:px-0">
                <StatWidget title={styleText('Your Diamonds')} value={user.diamonds.toLocaleString()} icon={<BanknotesIcon className="h-8 w-8 text-sky-400" />} />
                <StatWidget title={styleText('Total Attacks')} value={user.totalSmss.toLocaleString()} icon={<span className="text-3xl">💣</span>} />
                <StatWidget title={styleText('Referral Count')} value={user.referralCount.toLocaleString()} icon={<span className="text-3xl">👥</span>} />
                <div className="glass-card p-4 rounded-xl flex items-center justify-center">
                    <button 
                    onClick={handleClaimBonus}
                    disabled={!canClaimBonus}
                    className="w-full h-full flex flex-col items-center justify-center bg-green-600/20 hover:bg-green-600/40 disabled:bg-slate-700/50 disabled:cursor-not-allowed rounded-lg text-green-300 disabled:text-slate-400 transition-colors"
                    >
                    <GiftIcon className="h-8 w-8 mb-1"/>
                    <span className="font-bold text-sm">{styleText(canClaimBonus ? 'Claim Daily Bonus' : 'Bonus Claimed')}</span>
                    </button>
                </div>
            </div>

            <div className="glass-card shadow-2xl rounded-2xl p-4 md:p-6">
                <div className="flex justify-center bg-slate-900/50 p-1 rounded-xl mb-6">
                    <TabButton tab="profile" label="Profile" icon={UserCircleIcon} />
                    <TabButton tab="history" label="History" icon={ClockIcon} />
                    <TabButton tab="security" label="Security" icon={LockClosedIcon} />
                    <TabButton tab="safelist" label="Safelist" icon={ShieldCheckIcon} />
                    <TabButton tab="redeem" label="Redeem" icon={TicketIcon} />
                </div>
                
                <div className="min-h-[350px]">
                    {activeTab === 'profile' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in">
                            <div className="space-y-6">
                                 <div className="bg-slate-800/50 p-6 rounded-xl">
                                    <h3 className="text-lg font-bold text-white mb-4">{styleText('👥 Referral Program')}</h3>
                                    <p className="text-slate-400 text-xs mb-4">{styleText(`Share your code (it's your user ID) to earn diamonds!`)}</p>
                                    <div className="bg-slate-700 p-3 rounded-lg flex items-center justify-between">
                                        <code className="text-sky-300 text-sm">{user.referralCode}</code>
                                        <button onClick={copyReferralLink} title="Copy Referral Link">
                                            {copied ? <CheckIcon className="h-5 w-5 text-green-400"/> : <ClipboardIcon className="h-5 w-5 text-slate-400 hover:text-white"/>}
                                        </button>
                                    </div>
                                </div>
                                <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold py-2.5 px-4 rounded-lg text-sm">
                                    <ArrowRightOnRectangleIcon className="h-5 w-5" />
                                    {styleText('Logout')}
                                </button>
                            </div>
                            <div className="bg-slate-800/50 p-6 rounded-xl">
                                <h3 className="text-lg font-bold text-white mb-4">{styleText('📜 Recent Activity')}</h3>
                                <div className="space-y-3 max-h-[340px] overflow-y-auto pr-2">
                                    {transactions.length > 0 ? transactions.map(tx => (
                                        <div key={tx.id} className="flex justify-between items-center text-sm">
                                            <div>
                                                <p className="font-semibold text-slate-200">{tx.reason.replace(/_/g, ' ').toUpperCase()}</p>
                                                <p className="text-slate-400 text-xs">{new Date(tx.timestamp).toLocaleString()}</p>
                                            </div>
                                            <p className={`font-bold font-mono ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                                {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString()} 💎
                                            </p>
                                        </div>
                                    )) : <p className="text-slate-400 text-center">{styleText('No recent transactions.')}</p>}
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'history' && (
                        <div className="animate-fade-in">
                            <h3 className="text-lg font-bold text-white mb-4">{styleText('💣 Attack History')}</h3>
                            <div className="space-y-3 max-h-[340px] overflow-y-auto pr-2">
                                {smsLogs.length > 0 ? smsLogs.map(log => (
                                    <div key={log.id} className="flex justify-between items-center bg-slate-800/50 p-3 rounded-lg">
                                        <div>
                                            <p className="font-semibold text-slate-200">Target: <span className="font-mono">{log.targetNumber}</span></p>
                                            <p className="text-xs text-slate-400">Amount: {log.amount} | Cost: {log.cost} 💎</p>
                                            <p className="text-xs text-slate-500">{new Date(log.timestamp).toLocaleString()}</p>
                                        </div>
                                        {getStatusChip(log.status)}
                                    </div>
                                )) : <p className="text-slate-400 text-center py-10">{styleText('No attack history found.')}</p>}
                            </div>
                        </div>
                    )}
                    
                    {activeTab === 'security' && (
                        <div className="animate-fade-in max-w-md mx-auto">
                            <h3 className="text-lg font-bold text-white mb-4">{styleText('🔑 Change Password')}</h3>
                            <form onSubmit={handleChangePassword} className="space-y-4">
                                <input type="password" value={oldPassword} onChange={e => setOldPassword(e.target.value)} placeholder="Old Password" required className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:ring-sky-500 focus:border-sky-500" />
                                <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="New Password" required className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:ring-sky-500 focus:border-sky-500" />
                                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Confirm New Password" required className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:ring-sky-500 focus:border-sky-500" />
                                <button type="submit" className="w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2.5 px-4 rounded-lg text-sm">{styleText('Update Password')}</button>
                            </form>
                        </div>
                    )}
                    
                    {activeTab === 'safelist' && (
                         <div className="animate-fade-in">
                            <h3 className="text-lg font-bold text-white mb-4">{styleText('🛡️ My Safe List')}</h3>
                            <form onSubmit={handleAddSafelist} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                <input type="text" value={newSafeNumber} onChange={e => setNewSafeNumber(e.target.value)} placeholder="Phone Number" className="md:col-span-1 bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:ring-sky-500 focus:border-sky-500" />
                                <input type="text" value={newSafeNote} onChange={e => setNewSafeNote(e.target.value)} placeholder="Note (e.g., Mom)" className="md:col-span-1 bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:ring-sky-500 focus:border-sky-500" />
                                <button type="submit" className="md:col-span-1 bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2.5 px-4 rounded-lg text-sm">{styleText('Add Number')}</button>
                            </form>
                            <div className="max-h-60 overflow-y-auto pr-2 space-y-2">
                                {safelist.length > 0 ? safelist.map(item => (
                                    <div key={item.phoneNumber} className="flex justify-between items-center bg-slate-800/50 p-3 rounded-lg">
                                        <div>
                                            <p className="font-mono text-slate-200">{item.phoneNumber}</p>
                                            <p className="text-xs text-slate-400">{item.note || 'No note'}</p>
                                        </div>
                                        <button onClick={() => handleRemoveSafelist(item.phoneNumber)} className="text-red-400 hover:text-red-300 text-xs font-semibold">{styleText('REMOVE')}</button>
                                    </div>
                                )) : <p className="text-slate-400 text-center">{styleText('Your safelist is empty.')}</p>}
                            </div>
                        </div>
                    )}

                    {activeTab === 'redeem' && (
                        <div className="animate-fade-in max-w-md mx-auto">
                            <h3 className="text-lg font-bold text-white mb-4">{styleText('🎟️ Redeem Code')}</h3>
                             <p className="text-slate-400 text-xs text-center mb-4">{styleText('Have a code? Enter it below to claim your reward!')}</p>
                            <form onSubmit={handleRedeemCode} className="flex gap-4">
                                <input type="text" value={redeemCode} onChange={e => setRedeemCode(e.target.value)} placeholder="Enter your code" required className="flex-grow bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:ring-sky-500 focus:border-sky-500" />
                                <button type="submit" className="bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2.5 px-6 rounded-lg text-sm">{styleText('Claim')}</button>
                            </form>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;
<style>{`
    @keyframes fade-in {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-in {
        animation: fade-in 0.5s ease-out forwards;
    }
`}</style>