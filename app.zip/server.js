
require('dotenv').config();
const express = require('express');
const { Sequelize, DataTypes, Op } = require('sequelize');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();

// --- Middleware ---
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '.')));

// --- Constants ---
const PORT = process.env.PORT || 5055;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    console.error("FATAL ERROR: JWT_SECRET must be defined in .env file.");
    process.exit(1);
}
const OWNER_ID = 1;

// --- Sequelize Setup ---
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './database.sqlite',
    logging: false
});

// --- Models ---
const User = sequelize.define('User', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    username: { type: DataTypes.STRING, allowNull: false, unique: true, validate: { isLowercase: true } },
    password: { type: DataTypes.STRING, allowNull: false },
    firstName: { type: DataTypes.STRING, allowNull: false },
    diamonds: { type: DataTypes.INTEGER, defaultValue: 0 },
    totalSmss: { type: DataTypes.INTEGER, defaultValue: 0 },
    referralCode: { type: DataTypes.STRING, unique: true },
    referredBy: { type: DataTypes.INTEGER, defaultValue: null },
    referralCount: { type: DataTypes.INTEGER, defaultValue: 0 },
    dailyBonusClaimed: { type: DataTypes.DATE, defaultValue: null },
    joinedDate: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    lastActive: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    isBlocked: { type: DataTypes.BOOLEAN, defaultValue: false },
    isAdmin: { type: DataTypes.BOOLEAN, defaultValue: false },
    lastReadBroadcastTimestamp: { type: DataTypes.DATE, defaultValue: null }
}, { timestamps: false });

const Transaction = sequelize.define('Transaction', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: { type: DataTypes.INTEGER, allowNull: false, references: { model: User, key: 'id' } },
    username: { type: DataTypes.STRING, allowNull: false },
    amount: { type: DataTypes.INTEGER, allowNull: false },
    reason: { type: DataTypes.STRING, allowNull: false },
    timestamp: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
}, { timestamps: false });

const SmsLog = sequelize.define('SmsLog', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: { type: DataTypes.INTEGER, allowNull: false, references: { model: User, key: 'id' } },
    username: { type: DataTypes.STRING, allowNull: false },
    targetNumber: { type: DataTypes.STRING, allowNull: false },
    amount: { type: DataTypes.INTEGER, allowNull: false },
    cost: { type: DataTypes.INTEGER, allowNull: false },
    status: { type: DataTypes.STRING, defaultValue: 'started' },
    taskId: { type: DataTypes.STRING, unique: true },
    progress: { type: DataTypes.STRING, defaultValue: null },
    timestamp: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
}, { timestamps: false });

const SafeListItem = sequelize.define('SafeListItem', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: { type: DataTypes.INTEGER, allowNull: false, references: { model: User, key: 'id' } },
    phoneNumber: { type: DataTypes.STRING, allowNull: false },
    note: { type: DataTypes.STRING },
    addedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
}, { timestamps: false });
User.hasMany(SafeListItem, { foreignKey: 'userId', as: 'safelist' });

const BlacklistItem = sequelize.define('BlacklistItem', {
    phoneNumber: { type: DataTypes.STRING, primaryKey: true },
    reason: { type: DataTypes.STRING, allowNull: false },
    addedBy: { type: DataTypes.INTEGER, allowNull: false },
    addedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
}, { timestamps: false });

const RedeemCode = sequelize.define('RedeemCode', {
    code: { type: DataTypes.STRING, primaryKey: true },
    amount: { type: DataTypes.INTEGER, allowNull: false },
    maxUsers: { type: DataTypes.INTEGER, allowNull: false },
    usedBy: { type: DataTypes.JSON, defaultValue: [] },
    isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
    createdAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    createdBy: { type: DataTypes.INTEGER, allowNull: false }
}, { timestamps: false });

const Broadcast = sequelize.define('Broadcast', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    adminId: { type: DataTypes.INTEGER, allowNull: false },
    message: { type: DataTypes.STRING, allowNull: false },
    sentAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    stats: { type: DataTypes.JSON, defaultValue: { success: 0, failed: 0 } },
    buttonText: { type: DataTypes.STRING, allowNull: true },
    buttonUrl: { type: DataTypes.STRING, allowNull: true }
}, { timestamps: false });

const Setting = sequelize.define('Setting', {
    key: { type: DataTypes.STRING, primaryKey: true },
    value: { type: DataTypes.STRING }
}, { timestamps: false });

// --- Helper Functions ---
async function generateUniqueReferralCode() {
    let code;
    let isUnique = false;
    do {
        // Generate an 8-digit number
        code = Math.floor(10000000 + Math.random() * 90000000).toString();
        const existingUser = await User.findOne({ where: { referralCode: code } });
        if (!existingUser) {
            isUnique = true;
        }
    } while (!isUnique);
    return code;
}

// Hooks
User.addHook('beforeCreate', async (user, options) => {
    user.referralCode = await generateUniqueReferralCode();
});

User.addHook('afterCreate', async (user, options) => {
    if (user.id === OWNER_ID) {
        user.isAdmin = true;
        user.diamonds = 1000000;
        await user.save();
    }
});


// --- Middlewares ---
const authMiddleware = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ message: 'Authorization token required' });
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await User.findByPk(decoded.id, { attributes: { exclude: ['password'] } });
        if (!user) return res.status(401).json({ message: 'User not found' });
        req.user = user;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Invalid or expired token' });
    }
};

const adminMiddleware = (req, res, next) => {
    if (req.user && req.user.isAdmin) {
        next();
    } else {
        res.status(403).json({ message: 'Access denied. Admin privileges required.' });
    }
};

const getSettings = async () => {
    const settings = await Setting.findAll();
    const settingsObj = settings.reduce((acc, setting) => {
        try { acc[setting.key] = JSON.parse(setting.value); } catch { acc[setting.key] = setting.value; }
        return acc;
    }, {});
    return {
        maintenanceMode: false, dailyBonus: 200, referralBonus: 150, smsCost: 1,
        apiKey: "bot", maxSmsAmount: 200, maxReferrals: 50, requestTimeout: 30, smsApiUrl: "https://back.zone.id/api-proxy",
        ...settingsObj
    };
};

// --- API Proxy Setup ---
const blacklistCheckMiddleware = async (req, res, next) => {
    const targetNumber = req.query.num;
    if (targetNumber) {
        const isBlacklisted = await BlacklistItem.findByPk(targetNumber);
        if (isBlacklisted) {
            // Stop the request here if the number is blacklisted
            return res.status(403).json({
                success: false,
                message: 'This number is blacklisted and cannot be targeted.'
            });
        }
    }
    next(); // Proceed to the proxy if not blacklisted
};

app.use('/api-proxy', blacklistCheckMiddleware, createProxyMiddleware({
    router: async (req) => {
        const settings = await getSettings();
        return settings.smsApiUrl || "https://back.zone.id/api-proxy";
    },
    changeOrigin: true,
    pathRewrite: { '^/api-proxy': '' },
    onProxyReq: (proxyReq, req, res) => {
        console.log(`[Proxy] Forwarding request to: ${proxyReq.protocol}//${proxyReq.host}${proxyReq.path}`);
    },
    onError: (err, req, res) => {
        console.error('[Proxy] Error:', err);
        res.status(500).send('Proxy Error');
    }
}));


// --- Routers ---
const authRouter = require('./routes/auth');
const userRouter = require('./routes/user');
const adminRouter = require('./routes/admin');
const mainApiRouter = express.Router();

app.use('/api/auth', authRouter(User, bcrypt, jwt, JWT_SECRET, getSettings));
app.use('/api/users', authMiddleware, userRouter(User, Transaction, SmsLog, SafeListItem, RedeemCode, getSettings));
app.use('/api/admin', authMiddleware, adminMiddleware, adminRouter(User, Transaction, SmsLog, BlacklistItem, RedeemCode, Broadcast, Setting, getSettings));

// --- Public / User-Authenticated Routes ---

// Fetch settings (for all authenticated users)
mainApiRouter.get('/settings', authMiddleware, async (req, res) => {
    res.json(await getSettings());
});

// Leaderboard & Broadcast (Public/Semi-public)
mainApiRouter.get('/leaderboard', authMiddleware, async (req, res) => {
    const { type, limit = 20 } = req.query;
    const orderMap = {
        'smss': 'totalSmss',
        'diamonds': 'diamonds',
        'referrals': 'referralCount'
    };
    if (!orderMap[type]) return res.status(400).json({ message: 'Invalid leaderboard type' });

    const users = await User.findAll({
        order: [[orderMap[type], 'DESC']],
        limit: parseInt(limit),
        attributes: { exclude: ['password'] }
    });
    res.json(users);
});

mainApiRouter.get('/broadcasts/recent', authMiddleware, async (req, res) => {
    const { limit = 5 } = req.query;
    const broadcasts = await Broadcast.findAll({ order: [['sentAt', 'DESC']], limit: parseInt(limit) });
    res.json(broadcasts);
});

mainApiRouter.get('/broadcasts/unread', authMiddleware, async (req, res) => {
    const lastRead = req.user.lastReadBroadcastTimestamp || new Date(0);
    const broadcasts = await Broadcast.findAll({ where: { sentAt: { [Op.gt]: lastRead } } });
    res.json(broadcasts);
});

mainApiRouter.get('/broadcasts/unread/count', authMiddleware, async (req, res) => {
    const lastRead = req.user.lastReadBroadcastTimestamp || new Date(0);
    const count = await Broadcast.count({ where: { sentAt: { [Op.gt]: lastRead } } });
    res.json(count);
});

mainApiRouter.post('/broadcasts/mark-read', authMiddleware, async (req, res) => {
    req.user.lastReadBroadcastTimestamp = new Date();
    await req.user.save();
    res.status(200).send();
});

// SMS Logging (called by realApiService after proxy call)
mainApiRouter.post('/sms/log-attack', authMiddleware, async (req, res) => {
    const { targetNumber, amount, cost, taskId } = req.body;
    const user = req.user;
    
    user.diamonds -= cost;
    user.totalSmss += 1;
    
    await SmsLog.create({ userId: user.id, username: user.username, targetNumber, amount, cost, taskId });
    await Transaction.create({ userId: user.id, username: user.username, amount: -cost, reason: 'sms_service' });
    await user.save();
    
    res.status(200).send();
});

mainApiRouter.post('/sms/update-status', authMiddleware, async (req, res) => {
    const { taskId, status, progress } = req.body;
    await SmsLog.update({ status, progress }, { where: { taskId } });
    res.status(200).send();
});


app.use('/api', mainApiRouter);

// Catch-all to serve React App
app.('*',get (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// --- Main Server Function ---
const startServer = async () => {
    try {
        console.log("Attempting to connect to SQL database...");
        await sequelize.authenticate();
        console.log("✅ Successfully connected to SQL database!");
        
        await sequelize.sync({ alter: true }); // Use alter to be safe on schema changes
        console.log("✅ All models were synchronized successfully.");

        // Create Owner and default settings if they don't exist
        const owner = await User.findByPk(OWNER_ID);
        if(!owner) {
            // The hooks will handle setting referral code and admin status
            await User.create({ id: OWNER_ID, username: 'jubair', password: await bcrypt.hash('@Jubair121', 10), firstName: 'Admin'});
        }
        const settingsExist = await Setting.count();
        if(settingsExist === 0) {
            await Setting.bulkCreate([
                { key: 'maintenanceMode', value: 'false'}, { key: 'dailyBonus', value: '200'},
                { key: 'referralBonus', value: '150'}, { key: 'smsCost', value: '1'},
                { key: 'apiKey', value: 'bot'}, { key: 'maxSmsAmount', value: '200'},
                { key: 'maxReferrals', value: '50'}, { key: 'requestTimeout', value: '30'},
                { key: 'smsApiUrl', value: '"https://back.zone.id/api-proxy"'}
            ]);
        }

        app.listen(PORT, () => {
            console.log(`✅ Backend server is listening on http://localhost:${PORT}`);
        });

    } catch (err) {
        console.error("❌ SQL Database connection error:", err);
        process.exit(1);
    }
}

startServer();