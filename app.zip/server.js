
require('dotenv').config();
const express = require('express');
const { Sequelize, DataTypes } = require('sequelize');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();

// --- Middleware ---
app.use(cors());
app.use(express.json());

// --- Constants ---
const PORT = process.env.PORT || 5055;
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
    console.error("FATAL ERROR: JWT_SECRET must be defined in .env file.");
    process.exit(1);
}

// --- Sequelize (SQL) Setup ---
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './database.sqlite', // This file will store the database
    logging: false // Disable SQL query logging for cleaner output
});

// --- Sequelize Models (Replaces Mongoose Schemas) ---
const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: {
            isLowercase: true,
        }
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    firstName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    diamonds: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    totalSmss: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    referralCode: {
        type: DataTypes.STRING,
        unique: true
    },
    referredBy: {
        type: DataTypes.INTEGER,
        defaultValue: null
    },
    referralCount: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    dailyBonusClaimed: {
        type: DataTypes.DATE,
        defaultValue: null
    },
    joinedDate: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    lastActive: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    isBlocked: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    isAdmin: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
}, {
    timestamps: false // We are using our own date fields
});

// Sequelize Hooks (Replaces Mongoose pre/post hooks)
User.addHook('afterCreate', async (user, options) => {
    // Set referral code based on the new ID
    user.referralCode = user.id.toString();
    
    // Make the first user (ID: 1) the owner/admin
    if (user.id === 1) {
        user.isAdmin = true;
        user.diamonds = 1000000;
    }
    
    await user.save();
});


// --- Auth Middleware ---
const authMiddleware = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ message: 'Authorization token required' });
    }
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        // Exclude password field when fetching user
        req.user = await User.findOne({ where: { id: decoded.id }, attributes: { exclude: ['password'] } });
        if (!req.user) return res.status(401).json({ message: 'User not found' });
        next();
    } catch (error) {
        res.status(401).json({ message: 'Invalid or expired token' });
    }
};

// --- API Routes ---
const authRouter = express.Router();

// Register a new user
authRouter.post('/register', async (req, res) => {
    try {
        let { username, firstName, password, referralCode } = req.body;
        if (!username || !firstName || !password) {
            return res.status(400).json({ message: 'Username, First Name, and Password are required' });
        }
        
        username = username.toLowerCase().trim();

        const existingUser = await User.findOne({ where: { username: username } });
        if (existingUser) {
            return res.status(400).json({ message: 'Username is already taken.' });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const newUser = await User.create({
            username,
            firstName,
            password: hashedPassword,
            diamonds: referralCode ? 50 : 0
        });

        // The 'afterCreate' hook will handle setting the referralCode and admin status
        const userToReturn = await User.findOne({ where: { id: newUser.id }, attributes: { exclude: ['password'] } });
        
        const token = jwt.sign({ id: newUser.id }, JWT_SECRET, { expiresIn: '7d' });
        res.status(201).json({ token, user: userToReturn.toJSON() });

    } catch (error) {
        console.error("Registration Error:", error);
        res.status(500).json({ message: 'Server error during registration' });
    }
});

// Login user
authRouter.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ where: { username: username.toLowerCase() } });
        
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Invalid username or password.' });
        }
        if (user.isBlocked) {
            return res.status(403).json({ message: 'Your account has been banned.' });
        }
        
        user.lastActive = new Date();
        await user.save();
        
        const userToReturn = user.toJSON();
        delete userToReturn.password;

        const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
        res.json({ token, user: userToReturn });
    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({ message: 'Server error during login' });
    }
});

// Get current user data from token
authRouter.get('/me', authMiddleware, (req, res) => {
    res.json({ user: req.user });
});

// Main API Router
const apiRouter = express.Router();
apiRouter.get('/admin/settings', (req, res) => {
    // This should eventually come from a settings table in the database
    res.json({
        maintenanceMode: false, dailyBonus: 200, referralBonus: 150, smsCost: 1,
        apiKey: "bot", maxSmsAmount: 200, maxReferrals: 50, requestTimeout: 30, smsApiUrl: ""
    });
});

apiRouter.post('/sms/log-attack', authMiddleware, (req, res) => {
    console.log(`Attack logged for user ${req.user.id}:`, req.body);
    // Add logic here to save to SmsLog table in SQLite
    res.status(200).send();
});

apiRouter.post('/sms/update-status', (req, res) => {
    console.log(`Updating status for task:`, req.body.taskId);
    // Add logic here to update log in SQLite
    res.status(200).send();
});

// Use the routers
app.use('/api/auth', authRouter);
app.use('/api', apiRouter);

// --- Main Server Function ---
const startServer = async () => {
    try {
        console.log("Attempting to connect to SQL database...");
        await sequelize.authenticate();
        console.log("✅ Successfully connected to SQL database!");
        
        // Sync all defined models to the DB.
        // This will create the tables if they don't exist.
        await sequelize.sync();
        console.log("✅ All models were synchronized successfully.");

        app.listen(PORT, () => {
            console.log(`✅ Backend server is listening on http://localhost:${PORT}`);
        });

    } catch (err) {
        console.error("❌ SQL Database connection error:", err);
        process.exit(1);
    }
}

startServer();
