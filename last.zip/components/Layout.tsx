import React from 'react';
import { useLocation } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isLoginPage = location.pathname === '/login';

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans flex flex-col">
      {!isLoginPage && <Navbar />}
      <main className={`flex-grow ${!isLoginPage ? "pt-20 pb-10" : ""}`}>
        {children}
      </main>
      {!isLoginPage && <Footer />}
    </div>
  );
};

export default Layout;