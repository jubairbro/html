import React from 'react';
import { styleText } from '../constants';

const Footer: React.FC = () => {
    return (
        <footer className="bg-gray-800/80 backdrop-blur-sm shadow-inner mt-auto py-4">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400 text-sm">
                <p>{styleText('Powered by Jubair bro')}</p>
            </div>
        </footer>
    );
};

export default Footer;
