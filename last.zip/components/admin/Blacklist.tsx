import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/mockApiService';
import { BlacklistItem } from '../../types';
import { styleText } from '../../constants';
import { useToast } from '../../contexts/ToastContext';

const Blacklist: React.FC = () => {
    const { addToast } = useToast();
    const [blacklist, setBlacklist] = useState<BlacklistItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [newNumber, setNewNumber] = useState('');
    const [newReason, setNewReason] = useState('');
    const [error, setError] = useState('');

    const fetchBlacklist = useCallback(async () => {
        setLoading(true);
        const data = await api.getBlacklist();
        setBlacklist(data);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchBlacklist();
    }, [fetchBlacklist]);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!/^01[3-9]\d{8}$/.test(newNumber)) {
            setError('Invalid Bangladeshi phone number format.');
            return;
        }
        if (!newReason) {
            setError('Reason is required.');
            return;
        }
        const result = await api.addToBlacklist(newNumber, newReason);
        if (result.success) {
            addToast(result.message, 'success');
            setNewNumber('');
            setNewReason('');
            await fetchBlacklist();
        } else {
            setError(result.message);
        }
    };

    const handleRemove = async (phoneNumber: string) => {
        const result = await api.removeFromBlacklist(phoneNumber);
        if (result.success) {
            addToast(result.message, 'info');
            await fetchBlacklist();
        } else {
            addToast(result.message, 'error');
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-blue-500 rounded-full animate-spin"></div></div>;
    }

    return (
        <div>
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('Blacklist Management')}</h1>

            <div className="bg-gray-700/50 p-6 rounded-xl mb-8">
                <h2 className="text-lg font-bold text-white mb-4">{styleText('Add to Blacklist')}</h2>
                <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <input type="text" value={newNumber} onChange={e => setNewNumber(e.target.value)} placeholder="Phone Number" className="md:col-span-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm"/>
                    <input type="text" value={newReason} onChange={e => setNewReason(e.target.value)} placeholder="Reason" className="md:col-span-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm"/>
                    <button type="submit" className="md:col-span-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg text-sm">{styleText('Blacklist Number')}</button>
                </form>
                {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
            </div>
            
            <div className="bg-gray-700/50 p-6 rounded-xl">
                 <h2 className="text-lg font-bold text-white mb-4">{styleText('Blacklisted Numbers')}</h2>
                 <div className="max-h-96 overflow-y-auto pr-2 space-y-3">
                     {blacklist.length > 0 ? blacklist.map(item => (
                         <div key={item.phoneNumber} className="flex justify-between items-center bg-gray-600/50 p-3 rounded-lg">
                             <div>
                                 <p className="font-mono text-gray-200">{item.phoneNumber}</p>
                                 <p className="text-xs text-gray-400">{item.reason}</p>
                                 <p className="text-xs text-gray-500">Added by Admin ID {item.addedBy} on {new Date(item.addedAt).toLocaleDateString()}</p>
                             </div>
                             <button onClick={() => handleRemove(item.phoneNumber)} className="text-blue-400 hover:text-blue-300 text-xs font-semibold">{styleText('REMOVE')}</button>
                         </div>
                     )) : <p className="text-gray-400 text-center">{styleText('Blacklist is empty.')}</p>}
                 </div>
            </div>
        </div>
    );
};

export default Blacklist;