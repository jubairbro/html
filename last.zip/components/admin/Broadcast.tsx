import React, { useState } from 'react';
import { api } from '../../services/mockApiService';
import { generateBroadcastMessage } from '../../services/geminiService';
import { styleText } from '../../constants';
import { useToast } from '../../contexts/ToastContext';

const Broadcast: React.FC = () => {
    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(false);
    const { addToast } = useToast();
    
    const [geminiTopic, setGeminiTopic] = useState('');
    const [geminiSuggestions, setGeminiSuggestions] = useState<string[]>([]);
    const [geminiLoading, setGeminiLoading] = useState(false);

    const handleBroadcast = async () => {
        if (!message) {
            addToast('Message cannot be empty.', 'error');
            return;
        }
        
        setLoading(true);
        try {
            const result = await api.broadcastMessage(message);
            addToast(`Broadcast sent! Success: ${result.success}, Failed: ${result.failed}.`, 'success');
            setMessage('');
        } catch (error) {
            addToast('An error occurred during broadcast.', 'error');
        } finally {
            setLoading(false);
        }
    };
    
    const handleGenerateWithGemini = async () => {
        if(!geminiTopic) return;
        setGeminiLoading(true);
        setGeminiSuggestions([]);
        try {
            const suggestions = await generateBroadcastMessage(geminiTopic);
            setGeminiSuggestions(suggestions);
        } catch (error) {
            console.error(error);
            addToast("Failed to generate messages. Please try again.", 'error');
        } finally {
            setGeminiLoading(false);
        }
    };

    return (
        <div>
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('Broadcast Message')}</h1>
            
            <div className="bg-gray-700/50 p-6 rounded-xl mb-8">
                <h2 className="text-lg font-bold text-white mb-4">{styleText('💡 Generate with AI')}</h2>
                <div className="flex gap-2 mb-4">
                    <input 
                        type="text"
                        value={geminiTopic}
                        onChange={e => setGeminiTopic(e.target.value)}
                        placeholder="Enter a topic (e.g., new bonus)"
                        className="flex-grow bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white"
                    />
                    <button 
                        onClick={handleGenerateWithGemini}
                        disabled={geminiLoading || !geminiTopic}
                        className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-6 rounded-lg disabled:bg-gray-500 flex items-center"
                    >
                         {geminiLoading ? <div className="w-5 h-5 border-2 border-t-transparent rounded-full animate-spin"></div> : '✨ Generate'}
                    </button>
                </div>
                {geminiSuggestions.length > 0 && (
                    <div className="space-y-2">
                        <p className='text-xs text-gray-400 mb-2'>Click "Use" to copy a suggestion to the message box below.</p>
                        {geminiSuggestions.map((suggestion, i) => (
                            <div key={i} className="bg-gray-600/50 p-3 rounded-lg flex justify-between items-center text-sm">
                                <p className="text-gray-200">{suggestion}</p>
                                <button onClick={() => setMessage(suggestion)} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-1 px-3 rounded-md text-xs ml-4">{styleText('Use')}</button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
            
            <div className="bg-gray-700/50 p-6 rounded-xl">
                 <h2 className="text-lg font-bold text-white mb-4">{styleText('Compose Message')}</h2>
                <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Enter your message here..."
                    rows={6}
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white mb-4"
                />
                
                <button
                    onClick={handleBroadcast}
                    disabled={loading || !message}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg disabled:bg-gray-500"
                >
                    {loading ? 'Sending...' : '🚀 Send Broadcast to All Users'}
                </button>
            </div>
        </div>
    );
};

export default Broadcast;