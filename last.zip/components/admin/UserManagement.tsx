import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/mockApiService';
import { User, SmsLog, SafeListItem } from '../../types';
import { styleText } from '../../constants';
import { useToast } from '../../contexts/ToastContext';

const UserManagement: React.FC = () => {
    const { addToast } = useToast();
    const [searchId, setSearchId] = useState('');
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [userHistory, setUserHistory] = useState<SmsLog[]>([]);
    const [userSafelist, setUserSafelist] = useState<SafeListItem[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSearch = useCallback(async () => {
        if (!searchId) return;
        setLoading(true);
        setError('');
        setSelectedUser(null);
        setUserHistory([]);
        setUserSafelist([]);
        try {
            const userIdNum = parseInt(searchId);
            const user = await api.getUser(userIdNum);
            if (user) {
                setSelectedUser(user);
                const [history, safelist] = await Promise.all([
                    api.getUserHistory(userIdNum, 10),
                    api.getSafelist(userIdNum)
                ]);
                setUserHistory(history);
                setUserSafelist(safelist);
            } else {
                setError('User not found.');
            }
        } catch {
            setError('Invalid User ID format.');
        } finally {
            setLoading(false);
        }
    }, [searchId]);

    const handleToggleBan = async () => {
        if (!selectedUser) return;
        const result = await api.toggleUserBan(selectedUser.id);
        if (result.user) {
            setSelectedUser(result.user);
            addToast(result.message, 'success');
        } else {
            addToast(result.message, 'error');
        }
    };

    const handleResetPassword = async () => {
        if (!selectedUser) return;
        const newPassword = prompt(`Enter new password for ${selectedUser.username}:`);
        if (newPassword && newPassword.length >= 6) {
            const result = await api.adminResetPassword(selectedUser.id, newPassword);
            if (result.success) {
                addToast(result.message, 'success');
            } else {
                addToast(result.message, 'error');
            }
        } else if (newPassword) {
            addToast('Password must be at least 6 characters long.', 'error');
        }
    };

    const handleManageDiamonds = async (action: 'add' | 'deduct') => {
        if (!selectedUser) return;
        const amountStr = prompt(`Enter amount of diamonds to ${action}:`);
        if (amountStr) {
            const amount = parseInt(amountStr);
            if (!isNaN(amount) && amount > 0) {
                const result = await api.manageDiamonds(selectedUser.id, action === 'add' ? amount : -amount);
                if (result.user) {
                    setSelectedUser(result.user);
                    addToast(result.message, 'success');
                } else {
                    addToast(result.message, 'error');
                }
            } else {
                addToast('Invalid amount.', 'error');
            }
        }
    };
    
    return (
        <div>
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('User Management')}</h1>
            
            <div className="flex gap-2 mb-6">
                <input 
                    type="text" 
                    value={searchId}
                    onChange={e => setSearchId(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    placeholder="Enter User ID and press Enter"
                    className="flex-grow bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white"
                />
                <button 
                    onClick={handleSearch}
                    disabled={loading || !searchId}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg disabled:bg-gray-500"
                >
                    {loading ? '...' : 'Search'}
                </button>
            </div>
            
            {error && <p className="text-red-400 text-center bg-red-900/50 p-3 rounded-lg mb-6">{error}</p>}
            
            {selectedUser && (
                <div className="bg-gray-700/50 p-6 rounded-xl">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        <div>
                            <h2 className="text-xl font-bold text-white mb-4">{styleText('User Details')}</h2>
                            <div className="space-y-2 text-sm">
                                <p><span className="font-semibold text-gray-400 w-24 inline-block">ID:</span> {selectedUser.id}</p>
                                <p><span className="font-semibold text-gray-400 w-24 inline-block">Username:</span> {selectedUser.username}</p>
                                <p><span className="font-semibold text-gray-400 w-24 inline-block">First Name:</span> {selectedUser.firstName}</p>
                                <p><span className="font-semibold text-gray-400 w-24 inline-block">Diamonds:</span> 💎 {selectedUser.diamonds.toLocaleString()}</p>
                                <p><span className="font-semibold text-gray-400 w-24 inline-block">Total SMS:</span> 💣 {selectedUser.totalSmss.toLocaleString()}</p>
                                <p><span className="font-semibold text-gray-400 w-24 inline-block">Status:</span> <span className={selectedUser.isBlocked ? 'text-red-400' : 'text-green-400'}>{selectedUser.isBlocked ? 'Banned' : 'Active'}</span></p>
                            </div>
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-white mb-4">{styleText('Actions')}</h2>
                            <div className="grid grid-cols-2 gap-3">
                                <button onClick={() => handleManageDiamonds('add')} className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg">{styleText('Add 💎')}</button>
                                <button onClick={() => handleManageDiamonds('deduct')} className="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-4 rounded-lg">{styleText('Deduct 💎')}</button>
                                <button onClick={handleResetPassword} className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg">{styleText('Reset Pass')}</button>
                                <button onClick={handleToggleBan} className={`${selectedUser.isBlocked ? 'bg-blue-500 hover:bg-blue-600' : 'bg-red-600 hover:bg-red-700'} text-white font-semibold py-2 px-4 rounded-lg`}>{styleText(selectedUser.isBlocked ? 'Unban' : 'Ban')}</button>
                            </div>
                        </div>
                        <div className="md:col-span-2 mt-4 grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div>
                                <h3 className="text-lg font-bold text-white mb-2">{styleText("Recent SMS History")}</h3>
                                <div className="max-h-60 overflow-y-auto pr-2 space-y-2">
                                    {userHistory.length > 0 ? userHistory.map(log => (
                                        <div key={log.id} className="flex justify-between items-center bg-gray-600/50 p-2 rounded-lg text-sm">
                                            <div>
                                                <p className="font-mono">{log.targetNumber}</p>
                                                <p className="text-xs text-gray-400">{new Date(log.timestamp).toLocaleString()}</p>
                                            </div>
                                            <p>{log.amount} SMS (-{log.cost} 💎)</p>
                                        </div>
                                    )) : <p className="text-gray-400 italic">No history found.</p>}
                                </div>
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-white mb-2">{styleText("User's Safelist")}</h3>
                                <div className="max-h-60 overflow-y-auto pr-2 space-y-2">
                                    {userSafelist.length > 0 ? userSafelist.map(item => (
                                        <div key={item.phoneNumber} className="bg-gray-600/50 p-2 rounded-lg text-sm">
                                            <p className="font-mono">{item.phoneNumber}</p>
                                            <p className="text-xs text-gray-400 italic">{item.note || 'No note'}</p>
                                        </div>
                                    )) : <p className="text-gray-400 italic">Safelist is empty.</p>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserManagement;