import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { styleText } from '../constants';

const LoginPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login, signup } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        if (!username || !password) {
            setError("Username and Password are required.");
            setLoading(false);
            return;
        }
        const user = await login(username, password);
        if (user) {
          navigate('/');
        } else {
          setError('Invalid username or password.');
        }
      } else {
        if (!username || !firstName || !password) {
            setError("Username, First Name, and Password are required.");
            setLoading(false);
            return;
        }
        if (password !== confirmPassword) {
            setError("Passwords do not match.");
            setLoading(false);
            return;
        }
        const user = await signup(username, firstName, password, referralCode);
        if (user) {
          navigate('/');
        } else {
          setError('Username already exists or invalid referral code.');
        }
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 px-4">
      <div className="w-full max-w-md p-8 space-y-8 bg-gray-800 rounded-2xl shadow-2xl">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-2">{styleText(isLogin ? 'WELCOME BACK' : 'CREATE ACCOUNT')}</h1>
          <p className="text-gray-400">{styleText(isLogin ? 'Login to continue your session' : 'Join us to start your journey')}</p>
        </div>
        
        <div className="flex justify-center bg-gray-700 p-1 rounded-lg">
          <button
            onClick={() => setIsLogin(true)}
            className={`w-1/2 py-2 text-sm font-semibold rounded-md transition-all duration-300 ${isLogin ? 'bg-blue-600 text-white shadow' : 'text-gray-300'}`}
          >
            {styleText('LOGIN')}
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`w-1/2 py-2 text-sm font-semibold rounded-md transition-all duration-300 ${!isLogin ? 'bg-blue-600 text-white shadow' : 'text-gray-300'}`}
          >
            {styleText('SIGN UP')}
          </button>
        </div>
        
        <form className="space-y-6" onSubmit={handleSubmit}>
          {!isLogin && (
             <input
              type="text"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder={styleText('First Name')}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          )}
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder={styleText('Username')}
            autoComplete="username"
            className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
           <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={styleText('Password')}
            autoComplete={isLogin ? "current-password" : "new-password"}
            className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {!isLogin && (
            <>
            <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={styleText('Confirm Password')}
                autoComplete="new-password"
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <input
              type="text"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value)}
              placeholder={styleText('Referral Code (Optional)')}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            </>
          )}
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 focus:ring-offset-gray-800 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center"
          >
            {loading ? <div className="w-6 h-6 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : styleText(isLogin ? 'LOGIN' : 'SIGN UP')}
          </button>
        </form>
         <div className="text-center text-xs text-gray-500">
            <p>Need help? Contact Admin Telegram<code className="bg-gray-700 p-1 rounded">@JubairZ</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;