
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Using a mock service.");
}

const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

const generateBroadcastMessageMock = async (topic: string): Promise<string[]> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return [
        `📢 Exciting News! Announcing our new feature related to ${topic}! Check it out now!`,
        `🚀 Update Alert! We've just rolled out improvements for ${topic}. Enjoy the enhanced experience!`,
        `✨ Special Announcement on ${topic}! Don't miss out on what's new. Visit the app to learn more.`
    ];
};


export const generateBroadcastMessage = async (topic: string): Promise<string[]> => {
  if (!ai) {
    return generateBroadcastMessageMock(topic);
  }

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Generate 3 short, engaging, and exciting broadcast messages for a web app announcement. The topic is "${topic}". Each message should be under 150 characters. Do not use hashtags. Return as a JSON array of strings. Example for topic "new referral program": ["🚀 Our new referral program is here! Invite friends and earn big rewards!", "💰 Earn more with friends! Check out our new referral program today!", "🔥 Big update! You can now invite friends and get rewarded. See details inside!"]`,
    });
    
    const text = response.text?.trim();

    if (!text) {
        throw new Error("Empty response from Gemini API.");
    }
    
    // Clean the response to be valid JSON
    const jsonString = text.replace(/^```json\n?/, '').replace(/\n?```$/, '');

    const messages: string[] = JSON.parse(jsonString);
    return messages;
  } catch (error) {
    console.error("Error generating broadcast message with Gemini:", error);
    return generateBroadcastMessageMock(topic); // Fallback to mock on error
  }
};
