import { User, Transaction, SmsLog, SafeListItem, BlacklistItem, RedeemCode, SystemSettings, BroadcastLog } from '../types';
import { OWNER_ID, DEFAULT_DAILY_BONUS, DEFAULT_REFERRAL_BONUS, DEFAULT_SMS_COST, DEFAULT_MAX_SMS_AMOUNT, DEFAULT_MAX_REFERRALS, SIGNUP_REFERRAL_BONUS } from '../constants';

// --- STORAGE HELPERS ---
const getFromStorage = <T>(key: string, defaultValue: T): T => {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.warn(`Error reading from localStorage key "${key}":`, error);
        return defaultValue;
    }
};

const saveToStorage = (key: string, value: any): void => {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error(`Error writing to localStorage key "${key}":`, error);
    }
};

// --- DATABASE STATE & HELPERS ---
type Db = {
    users: User[];
    transactions: Transaction[];
    smsLogs: SmsLog[];
    broadcastLogs: BroadcastLog[];
    blacklist: BlacklistItem[];
    redeemCodes: RedeemCode[];
    settings: SystemSettings;
    loggedInUserId: number | null;
    _nextId: { [key: string]: number };
};

const db: Db = {
    users: getFromStorage<User[]>('db_users', []),
    transactions: getFromStorage<Transaction[]>('db_transactions', []),
    smsLogs: getFromStorage<SmsLog[]>('db_smsLogs', []),
    broadcastLogs: getFromStorage<BroadcastLog[]>('db_broadcastLogs', []),
    blacklist: getFromStorage<BlacklistItem[]>('db_blacklist', []),
    redeemCodes: getFromStorage<RedeemCode[]>('db_redeemCodes', []),
    settings: getFromStorage<SystemSettings>('db_settings', {
        maintenanceMode: false,
        dailyBonus: DEFAULT_DAILY_BONUS,
        referralBonus: DEFAULT_REFERRAL_BONUS,
        smsCost: DEFAULT_SMS_COST,
        apiKey: "bot",
        maxSmsAmount: DEFAULT_MAX_SMS_AMOUNT,
        maxReferrals: DEFAULT_MAX_REFERRALS,
        smsApiUrl: "http://sms.jubairbro.store:5000",
        requestTimeout: 30,
    }),
    loggedInUserId: getFromStorage<number | null>('db_loggedInUserId', null),
    _nextId: getFromStorage<{ [key: string]: number }>('db_nextId', { user: 1, tx: 1, sms: 1, code: 1, broadcast: 1 }),
};

const _save = () => {
    // Simulate async operation
    setTimeout(() => {
        for (const key in db) {
            if (key.startsWith('_')) continue;
            saveToStorage(`db_${key}`, (db as any)[key]);
        }
        saveToStorage('db_nextId', db._nextId);
    }, 100);
};

const _getNewId = (type: 'user' | 'tx' | 'sms' | 'code' | 'broadcast') => {
    const id = db._nextId[type];
    db._nextId[type]++;
    return id;
};

// --- DATABASE INITIALIZATION ---
const initializeDatabase = () => {
    const ownerExists = db.users.some(u => u.id === OWNER_ID);
    if (!ownerExists) {
        db.users.push({
            id: OWNER_ID,
            // Default Owner Credentials
            username: 'Jubair',
            password: '@Jubair121', 
            firstName: 'Admin',
            diamonds: 1000000,
            totalSmss: 0,
            referralCode: 'JUBAIR121',
            referredBy: null,
            referralCount: 0,
            dailyBonusClaimed: null,
            joinedDate: new Date().toISOString(),
            lastActive: new Date().toISOString(),
            isBlocked: false,
            isAdmin: true,
            safelist: [],
            lastReadBroadcastTimestamp: null,
        });
        _save();
    }
};
initializeDatabase();

// --- MOCK API SERVICE ---
export const api = {
    // --- Auth ---
    async getLoggedInUser(): Promise<User | null> {
        await new Promise(res => setTimeout(res, 200)); // Simulate network delay
        if (!db.loggedInUserId) return null;
        const user = db.users.find(u => u.id === db.loggedInUserId);
        if (user) {
            // Return a copy without the password
            const { password, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    },
    async login(username: string, passwordIn: string): Promise<User | null> {
        await new Promise(res => setTimeout(res, 500));
        const user = db.users.find(u => u.username.toLowerCase() === username.toLowerCase() && !u.isBlocked);
        if (user && user.password === passwordIn) {
            db.loggedInUserId = user.id;
            user.lastActive = new Date().toISOString();
            _save();
            const { password, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    },
    async logout(): Promise<void> {
        db.loggedInUserId = null;
        _save();
    },
    async register(username: string, firstName: string, passwordIn: string, referralCode?: string): Promise<User | null> {
        await new Promise(res => setTimeout(res, 500));
        if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
            return null; // Username exists
        }

        let referredBy: User | undefined;
        if (referralCode) {
            referredBy = db.users.find(u => u.referralCode === referralCode);
            if (!referredBy) return null; // Invalid referral code
        }
        
        const newUser: User = {
            id: _getNewId('user'),
            username,
            password: passwordIn,
            firstName,
            diamonds: referredBy ? SIGNUP_REFERRAL_BONUS : 0,
            totalSmss: 0,
            referralCode: Math.random().toString(36).substring(2, 10).toUpperCase(),
            referredBy: referredBy ? referredBy.id : null,
            referralCount: 0,
            dailyBonusClaimed: null,
            joinedDate: new Date().toISOString(),
            lastActive: new Date().toISOString(),
            isBlocked: false,
            isAdmin: false,
            safelist: [],
            lastReadBroadcastTimestamp: null,
        };
        db.users.push(newUser);

        if (referredBy) {
            if (referredBy.referralCount < db.settings.maxReferrals) {
                referredBy.referralCount++;
                referredBy.diamonds += db.settings.referralBonus;
                 db.transactions.unshift({ id: `tx${_getNewId('tx')}`, userId: referredBy.id, username: referredBy.username, amount: db.settings.referralBonus, reason: 'referral_bonus', timestamp: new Date().toISOString()});
            }
        }
        
        db.loggedInUserId = newUser.id;
        _save();
        const { password, ...userWithoutPassword } = newUser;
        return userWithoutPassword;
    },

    // --- User Actions ---
    async getUser(userId: number): Promise<User | null> {
        const user = db.users.find(u => u.id === userId);
        if(user) {
            const { password, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    },
    async getRecentUsers(limit: number): Promise<User[]> {
        return [...db.users]
            .sort((a,b) => new Date(b.joinedDate).getTime() - new Date(a.joinedDate).getTime())
            .slice(0, limit)
            .map(u => { const { password, ...rest } = u; return rest; });
    },
    async claimDailyBonus(userId: number): Promise<{ success: boolean, message: string, amount?: number }> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        
        const today = new Date().toISOString().split('T')[0];
        if (user.dailyBonusClaimed && user.dailyBonusClaimed.startsWith(today)) {
            return { success: false, message: "You have already claimed your daily bonus today." };
        }
        
        user.diamonds += db.settings.dailyBonus;
        user.dailyBonusClaimed = new Date().toISOString();
        db.transactions.unshift({ id: `tx${_getNewId('tx')}`, userId: user.id, username: user.username, amount: db.settings.dailyBonus, reason: 'daily_bonus', timestamp: new Date().toISOString()});
        _save();
        return { success: true, message: `You claimed ${db.settings.dailyBonus} diamonds!`, amount: db.settings.dailyBonus };
    },
    async sendSms(userId: number, target: string, amount: number, onUpdate: (log: SmsLog) => void): Promise<{ success: boolean, message: string, log?: SmsLog }> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        if (db.settings.maintenanceMode && !user.isAdmin) return { success: false, message: "System is under maintenance." };
        if (db.blacklist.some(b => b.phoneNumber === target)) return { success: false, message: "This number is blacklisted." };
        
        const isSelfSafeguarded = db.users.some(u => u.safelist.some(s => s.phoneNumber === target));
        if (isSelfSafeguarded) return { success: false, message: "This number is protected in a user's safelist." };
        
        const cost = amount * db.settings.smsCost;
        if (user.diamonds < cost) return { success: false, message: "Insufficient diamonds." };

        user.diamonds -= cost;
        user.totalSmss += amount;
        
        const log: SmsLog = { id: `sms${_getNewId('sms')}`, userId, username: user.username, targetNumber: target, amount, cost, timestamp: new Date().toISOString(), status: 'started' };
        db.smsLogs.unshift(log);
        onUpdate(log);
        
        // Simulate sending progress
        setTimeout(() => {
            const logToUpdate = db.smsLogs.find(l => l.id === log.id);
            if(logToUpdate) {
                logToUpdate.status = Math.random() > 0.1 ? 'completed' : 'failed';
                onUpdate(logToUpdate);
                _save();
            }
        }, db.settings.requestTimeout * 100 + Math.random() * 1000);

        db.transactions.unshift({ id: `tx${_getNewId('tx')}`, userId, username: user.username, amount: -cost, reason: 'sms_service', timestamp: new Date().toISOString() });
        _save();
        return { success: true, message: "SMS attack started.", log };
    },
    async changePassword(userId: number, oldPass: string, newPass: string): Promise<{success: boolean, message: string}> {
        const user = db.users.find(u => u.id === userId);
        if (!user || user.password !== oldPass) {
            return { success: false, message: "Incorrect old password." };
        }
        user.password = newPass;
        _save();
        return { success: true, message: "Password changed successfully." };
    },


    // --- Data Retrieval ---
    async getUserHistory(userId: number, limit: number): Promise<SmsLog[]> {
        return db.smsLogs.filter(log => log.userId === userId).slice(0, limit);
    },
    async getTransactions(userId: number, limit: number): Promise<Transaction[]> {
        return db.transactions.filter(tx => tx.userId === userId).sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, limit);
    },
    async getLeaderboard(type: 'diamonds' | 'referrals' | 'smss', limit: number): Promise<User[]> {
        const sorted = [...db.users].sort((a, b) => {
            if (type === 'diamonds') return b.diamonds - a.diamonds;
            if (type === 'referrals') return b.referralCount - a.referralCount;
            if (type === 'smss') return b.totalSmss - a.totalSmss;
            return 0;
        });
        return sorted.slice(0, limit).map(u => { const { password, ...rest } = u; return rest; });
    },

    // --- Safelist ---
    async getSafelist(userId: number): Promise<SafeListItem[]> {
        const user = db.users.find(u => u.id === userId);
        return user ? user.safelist : [];
    },
    async addToSafelist(userId: number, phoneNumber: string, note: string): Promise<{ success: boolean, message: string }> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        if (user.safelist.some(item => item.phoneNumber === phoneNumber)) {
            return { success: false, message: "Number already in safelist." };
        }
        user.safelist.push({ phoneNumber, note, addedAt: new Date().toISOString() });
        _save();
        return { success: true, message: "Added to safelist." };
    },
    async removeFromSafelist(userId: number, phoneNumber: string): Promise<{ success: boolean, message: string }> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.safelist = user.safelist.filter(item => item.phoneNumber !== phoneNumber);
            _save();
            return { success: true, message: "Removed from safelist." };
        }
        return { success: false, message: "User not found." };
    },

    // --- Broadcast ---
    async getRecentBroadcasts(limit: number): Promise<BroadcastLog[]> {
        return [...db.broadcastLogs].sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime()).slice(0, limit);
    },
    async getUnreadBroadcastsCount(userId: number): Promise<number> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return 0;
        if (!user.lastReadBroadcastTimestamp) {
            return db.broadcastLogs.length; // If never read, all are unread
        }
        const lastReadDate = new Date(user.lastReadBroadcastTimestamp);
        return db.broadcastLogs.filter(b => new Date(b.sentAt) > lastReadDate).length;
    },
    async markBroadcastsAsRead(userId: number): Promise<void> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.lastReadBroadcastTimestamp = new Date().toISOString();
            _save();
        }
    },

    // --- Admin ---
    async getSystemStats(): Promise<any> {
        return {
            users: db.users.length,
            activeToday: db.users.filter(u => new Date(u.lastActive) > new Date(Date.now() - 24 * 60 * 60 * 1000)).length,
            smss: db.smsLogs.reduce((acc, log) => acc + log.amount, 0),
            diamonds: db.users.reduce((acc, u) => acc + u.diamonds, 0),
            bannedUsers: db.users.filter(u => u.isBlocked).length,
            blacklistedNumbers: db.blacklist.length,
            totalTransactions: db.transactions.length
        };
    },
    async toggleUserBan(userId: number): Promise<{user: User | null, message: string}> {
        if (userId === OWNER_ID) return {user: null, message: "Cannot ban the owner."};
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.isBlocked = !user.isBlocked;
            _save();
            const { password, ...userWithoutPassword } = user;
            return {user: userWithoutPassword, message: `User has been ${user.isBlocked ? 'banned' : 'unbanned'}.`};
        }
        return {user: null, message: "User not found."};
    },
    async adminResetPassword(userId: number, newPass: string): Promise<{success: boolean, message: string}> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.password = newPass;
            _save();
            return {success: true, message: "Password reset successfully."};
        }
        return {success: false, message: "Failed to reset password."};
    },
    async manageDiamonds(userId: number, amount: number): Promise<{user: User | null, message: string}> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            if (amount < 0 && user.diamonds < Math.abs(amount)) {
                return {user: null, message: "User has insufficient diamonds to deduct."};
            }
            user.diamonds += amount;
            const reason = amount > 0 ? 'admin_gift' : 'admin_deduct';
            db.transactions.unshift({ id: `tx${_getNewId('tx')}`, userId, username: user.username, amount, reason, timestamp: new Date().toISOString()});
            _save();
            const { password, ...userWithoutPassword } = user;
            return {user: userWithoutPassword, message: `Successfully managed diamonds.`};
        }
        return {user: null, message: "User not found."};
    },
    async broadcastMessage(message: string): Promise<{ success: number, failed: number }> {
        await new Promise(res => setTimeout(res, 2000));
        const stats = { success: db.users.filter(u => !u.isBlocked).length, failed: 0 };
        db.broadcastLogs.unshift({
            id: `bc${_getNewId('broadcast')}`,
            adminId: db.loggedInUserId!,
            message,
            sentAt: new Date().toISOString(),
            stats
        });
        _save();
        console.log(`BROADCASTING: "${message}" to ${stats.success} users.`);
        return stats;
    },
    async getSettings(): Promise<SystemSettings> {
        return {...db.settings};
    },
    async updateSettings(newSettings: SystemSettings): Promise<SystemSettings> {
        db.settings = newSettings;
        _save();
        return {...db.settings};
    },
    async getBlacklist(): Promise<BlacklistItem[]> {
        return [...db.blacklist];
    },
    async addToBlacklist(phoneNumber: string, reason: string): Promise<{ success: boolean, message: string }> {
        if (db.blacklist.some(item => item.phoneNumber === phoneNumber)) {
            return { success: false, message: "Number already blacklisted." };
        }
        db.blacklist.unshift({ phoneNumber, reason, addedBy: db.loggedInUserId!, addedAt: new Date().toISOString() });
        _save();
        return { success: true, message: "Added to blacklist." };
    },
    async removeFromBlacklist(phoneNumber: string): Promise<{ success: boolean, message: string }> {
        const initialLength = db.blacklist.length;
        db.blacklist = db.blacklist.filter(item => item.phoneNumber !== phoneNumber);
        _save();
        return { success: db.blacklist.length < initialLength, message: db.blacklist.length < initialLength ? "Removed from blacklist." : "Number not found in blacklist." };
    },
    async getRedeemCodes(): Promise<RedeemCode[]> {
        return [...db.redeemCodes].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    },
    async createRedeemCode(code: string, amount: number, maxUsers: number): Promise<{ success: boolean, message: string }> {
        if (db.redeemCodes.some(c => c.code.toLowerCase() === code.toLowerCase())) {
            return { success: false, message: "Code already exists." };
        }
        db.redeemCodes.unshift({ code, amount, maxUsers, usedBy: [], isActive: true, createdAt: new Date().toISOString(), createdBy: db.loggedInUserId! });
        _save();
        return { success: true, message: "Code created." };
    },
    async deleteRedeemCode(code: string): Promise<{ success: boolean, message: string }> {
        const initialLength = db.redeemCodes.length;
        db.redeemCodes = db.redeemCodes.filter(c => c.code !== code);
        _save();
        return { success: db.redeemCodes.length < initialLength, message: db.redeemCodes.length < initialLength ? "Code deleted." : "Code not found." };
    },
    async getAllSmsLogs(): Promise<SmsLog[]> {
        return [...db.smsLogs];
    },
    async getAllTransactions(): Promise<Transaction[]> {
        return [...db.transactions];
    },
    async getBroadcastHistory(): Promise<BroadcastLog[]> {
        return [...db.broadcastLogs];
    },
    async getAdmins(): Promise<User[]> {
        return db.users.filter(u => u.isAdmin).map(u => { const { password, ...rest } = u; return rest; });
    },
    async addAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        if (user.isAdmin) return { success: false, message: "User is already an admin." };
        user.isAdmin = true;
        _save();
        return { success: true, message: "Admin added." };
    },
    async removeAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        if (userId === OWNER_ID) return { success: false, message: "Cannot remove the owner." };
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        if (!user.isAdmin) return { success: false, message: "User is not an admin." };
        user.isAdmin = false;
        _save();
        return { success: true, message: "Admin removed." };
    },
};