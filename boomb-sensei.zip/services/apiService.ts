import { SystemSettings, SmsApiResponse, TaskStatusResponse } from "../types";

const API_PROXY_PATH = '/api-proxy';

const handleApiError = async (response: Response): Promise<string> => {
    switch(response.status) {
        case 401: return "Invalid API Key. Please check the key in the admin settings.";
        case 429: return "API Rate Limit Exceeded. Please try again later.";
        case 400:
        case 422:
             try {
                const errorData = await response.json();
                return errorData.message || "Invalid Input: The API rejected the phone number or amount.";
            } catch {
                return "Invalid Input: The API rejected the request.";
            }
        case 500:
        case 502:
        case 503:
        case 504:
            return "SMS API Server Error. Please try again later.";
        default:
            return `API Error: Received status code ${response.status}.`;
    }
}

export const sendSmsRequest = async (settings: SystemSettings, targetNumber: string, amount: number): Promise<SmsApiResponse> => {
    const url = new URL(`${window.location.origin}${API_PROXY_PATH}/api`);
    url.searchParams.append('key', settings.apiKey);
    url.searchParams.append('num', targetNumber);
    url.searchParams.append('amount', amount.toString());

    try {
        const response = await fetch(url.toString(), {
            method: 'GET',
            signal: AbortSignal.timeout(settings.requestTimeout * 1000)
        });
        if (!response.ok) {
            const errorMessage = await handleApiError(response);
            return { success: false, message: errorMessage };
        }
        return await response.json() as SmsApiResponse;
    } catch (error) {
        console.error("SMS API Request Error:", error);
        if (error instanceof Error) {
            if (error.name === 'TimeoutError') {
                 return { success: false, message: `API request timed out after ${settings.requestTimeout} seconds.` };
            }
            if(error.message.includes('Failed to fetch')) {
                 return { success: false, message: "Network Error: Could not connect to the API. Check your connection and proxy settings." };
            }
            return { success: false, message: error.message };
        }
        return { success: false, message: "An unknown network error occurred." };
    }
};

export const checkTaskStatus = async (taskId: string): Promise<TaskStatusResponse> => {
     const url = new URL(`${window.location.origin}${API_PROXY_PATH}/task_status`);
     url.searchParams.append('task_id', taskId);

     try {
        const response = await fetch(url.toString(), {
            method: 'GET',
             signal: AbortSignal.timeout(5000)
        });
        if (!response.ok) {
            throw new Error(`API returned status ${response.status}`);
        }
        return await response.json() as TaskStatusResponse;
     } catch (error) {
        console.error("Task Status API Error:", error);
        return {
            task_id: taskId,
            status: 'failed',
            phone: 'Unknown',
            amount: 0,
            created_at: new Date().toISOString(),
            error: 'Failed to fetch status update.'
        };
     }
};
