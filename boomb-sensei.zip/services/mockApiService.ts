/**
 * Mock API Service
 * ----------------
 * This file simulates a backend server by storing data in the browser's localStorage.
 * It's designed to mimic the behavior of a real API, allowing for full frontend
 * development and testing without a live backend.
 *
 * Each function is documented to explain its purpose, parameters, business logic,
 * and return values, making it a reference implementation for the real backend.
 */
import { User, Transaction, SmsLog, SafeListItem, BlacklistItem, RedeemCode, SystemSettings, Broadcast, SmsApiResponse, TaskStatusResponse } from '../types';
import { OWNER_ID, DEFAULT_DAILY_BONUS, DEFAULT_REFERRAL_BONUS, DEFAULT_SMS_COST, DEFAULT_MAX_SMS_AMOUNT, DEFAULT_MAX_REFERRALS, SIGNUP_REFERRAL_BONUS } from '../constants';

// --- STORAGE HELPERS ---
const getFromStorage = <T>(key: string, defaultValue: T): T => {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.warn(`Error reading from localStorage key "${key}":`, error);
        return defaultValue;
    }
};

const saveToStorage = (key: string, value: any): void => {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error(`Error writing to localStorage key "${key}":`, error);
    }
};

// --- DATABASE STATE & HELPERS ---
type Db = {
    users: User[];
    transactions: Transaction[];
    smsLogs: SmsLog[];
    broadcasts: Broadcast[];
    blacklist: BlacklistItem[];
    redeemCodes: RedeemCode[];
    settings: SystemSettings;
    loggedInUserId: number | null;
    _nextId: { [key: string]: number };
};

const db: Db = {
    users: getFromStorage<User[]>('db_users', []),
    transactions: getFromStorage<Transaction[]>('db_transactions', []),
    smsLogs: getFromStorage<SmsLog[]>('db_smsLogs', []),
    broadcasts: getFromStorage<Broadcast[]>('db_broadcasts', []),
    blacklist: getFromStorage<BlacklistItem[]>('db_blacklist', []),
    redeemCodes: getFromStorage<RedeemCode[]>('db_redeemCodes', []),
    settings: getFromStorage<SystemSettings>('db_settings', {
        maintenanceMode: false,
        dailyBonus: DEFAULT_DAILY_BONUS,
        referralBonus: DEFAULT_REFERRAL_BONUS,
        smsCost: DEFAULT_SMS_COST,
        apiKey: "bot",
        maxSmsAmount: DEFAULT_MAX_SMS_AMOUNT,
        maxReferrals: DEFAULT_MAX_REFERRALS,
        smsApiUrl: "http://sms.jubairbro.store:5000",
        requestTimeout: 30,
    }),
    loggedInUserId: getFromStorage<number | null>('db_loggedInUserId', null),
    _nextId: getFromStorage<{ [key: string]: number }>('db_nextId', { user: 1, tx: 1, sms: 1, code: 1, broadcast: 1 }),
};

const _save = () => {
    // Simulate async operation
    setTimeout(() => {
        for (const key in db) {
            if (key.startsWith('_')) continue;
            saveToStorage(`db_${key}`, (db as any)[key]);
        }
        saveToStorage('db_nextId', db._nextId);
    }, 100);
};

const _getNewId = (type: 'user' | 'tx' | 'sms' | 'code' | 'broadcast') => {
    const id = db._nextId[type];
    db._nextId[type]++;
    // FIX: Return a number to match the type definition of ID fields.
    return id;
};

// --- DATABASE INITIALIZATION ---
const initializeDatabase = () => {
    const ownerExists = db.users.some(u => u.id === OWNER_ID);
    if (!ownerExists) {
        db.users.push({
            id: OWNER_ID,
            username: 'Jubair',
            password: '@Jubair121', 
            firstName: 'Admin',
            diamonds: 1000000,
            totalSmss: 0,
            referralCode: OWNER_ID.toString(),
            referredBy: null,
            referralCount: 0,
            dailyBonusClaimed: null,
            joinedDate: new Date().toISOString(),
            lastActive: new Date().toISOString(),
            isBlocked: false,
            isAdmin: true,
            safelist: [],
            lastReadBroadcastTimestamp: null,
        });
        _save();
    }
};
initializeDatabase();

// --- MOCK API SERVICE ---
export const mockApi = {
    /**
     * Retrieves the currently logged-in user's data from session.
     * @returns {Promise<User | null>} The user object without password, or null if not logged in.
     */
    async getLoggedInUser(): Promise<User | null> {
        await new Promise(res => setTimeout(res, 200)); // Simulate network delay
        if (!db.loggedInUserId) return null;
        const user = db.users.find(u => u.id === db.loggedInUserId);
        if (user) {
            const { password, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    },
    /**
     * Authenticates a user.
     * @param {string} username - The user's username.
     * @param {string} passwordIn - The user's password.
     * @returns {Promise<User | null>} The user object on success, null on failure.
     */
    async login(username: string, passwordIn: string): Promise<User | null> {
        await new Promise(res => setTimeout(res, 500));
        const user = db.users.find(u => u.username.toLowerCase() === username.toLowerCase() && !u.isBlocked);
        if (user && user.password === passwordIn) {
            db.loggedInUserId = user.id;
            user.lastActive = new Date().toISOString();
            _save();
            const { password, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    },
    /**
     * Clears the current user session.
     */
    async logout(): Promise<void> {
        db.loggedInUserId = null;
        _save();
    },
    /**
     * Registers a new user.
     * @param {string} username - The new user's username. Must be unique (case-insensitive).
     * @param {string} firstName - The new user's first name.
     * @param {string} passwordIn - The new user's password.
     * @param {string} [referralCode] - An optional referral code from another user.
     * @returns {Promise<User | null>} The newly created user object, or throws an error on failure.
     */
    async register(username: string, firstName: string, passwordIn: string, referralCode?: string): Promise<User | null> {
        await new Promise(res => setTimeout(res, 500));
        if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
            throw new Error('Username is already taken.');
        }

        let referredBy: User | undefined;
        if (referralCode) {
            const refId = parseInt(referralCode);
            if(isNaN(refId)) throw new Error('Invalid referral code.');
            referredBy = db.users.find(u => u.id === refId);
            if (!referredBy) throw new Error('Invalid referral code.');
        }
        
        // FIX: Removed parseInt as _getNewId now returns a number.
        const newUserId = _getNewId('user');
        const newUser: User = {
            id: newUserId,
            username,
            password: passwordIn,
            firstName,
            diamonds: referredBy ? SIGNUP_REFERRAL_BONUS : 0,
            totalSmss: 0,
            referralCode: newUserId.toString(),
            referredBy: referredBy ? referredBy.id : null,
            referralCount: 0,
            dailyBonusClaimed: null,
            joinedDate: new Date().toISOString(),
            lastActive: new Date().toISOString(),
            isBlocked: false,
            isAdmin: false,
            safelist: [],
            lastReadBroadcastTimestamp: null,
        };
        db.users.push(newUser);

        // If a valid referrer was found, credit them.
        if (referredBy) {
            if (referredBy.referralCount < db.settings.maxReferrals) {
                referredBy.referralCount++;
                referredBy.diamonds += db.settings.referralBonus;
                 db.transactions.unshift({ id: _getNewId('tx'), userId: referredBy.id, username: referredBy.username, amount: db.settings.referralBonus, reason: 'referral_bonus', timestamp: new Date().toISOString()});
            }
        }
        
        db.loggedInUserId = newUser.id;
        _save();
        const { password, ...userWithoutPassword } = newUser;
        return userWithoutPassword;
    },

    // --- User Actions ---
    async getUser(userId: number): Promise<User | null> {
        const user = db.users.find(u => u.id === userId);
        if(user) {
            const { password, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    },
    async getRecentUsers(limit: number): Promise<User[]> {
        return [...db.users]
            .sort((a,b) => new Date(b.joinedDate).getTime() - new Date(a.joinedDate).getTime())
            .slice(0, limit)
            .map(u => { const { password, ...rest } = u; return rest; });
    },
    async claimDailyBonus(userId: number): Promise<{ success: boolean, message: string, amount?: number }> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        
        const today = new Date().toISOString().split('T')[0];
        if (user.dailyBonusClaimed && user.dailyBonusClaimed.startsWith(today)) {
            return { success: false, message: "You have already claimed your daily bonus today." };
        }
        
        user.diamonds += db.settings.dailyBonus;
        user.dailyBonusClaimed = new Date().toISOString();
        db.transactions.unshift({ id: _getNewId('tx'), userId: user.id, username: user.username, amount: db.settings.dailyBonus, reason: 'daily_bonus', timestamp: new Date().toISOString()});
        _save();
        return { success: true, message: `You claimed ${db.settings.dailyBonus} diamonds!`, amount: db.settings.dailyBonus };
    },
    async logSmsAttack(userId: number, targetNumber: string, amount: number, cost: number, taskId: string): Promise<SmsLog> {
        const user = db.users.find(u => u.id === userId);
        if (!user) throw new Error("User not found for logging SMS attack.");

        user.diamonds -= cost;
        user.totalSmss += 1;

        db.transactions.unshift({ id: _getNewId('tx'), userId, username: user.username, amount: -cost, reason: 'sms_service', timestamp: new Date().toISOString() });
        const log: SmsLog = { id: _getNewId('sms'), userId, username: user.username, targetNumber, amount, cost, timestamp: new Date().toISOString(), status: 'started', taskId };
        db.smsLogs.unshift(log);

        _save();
        return log;
    },
     async updateSmsLogStatus(taskId: string, status: SmsLog['status'], progress?: string): Promise<void> {
        const log = db.smsLogs.find(l => l.taskId === taskId);
        if (log) {
            log.status = status;
            if (progress) log.progress = progress;
            _save();
        }
    },
    async changePassword(userId: number, oldPass: string, newPass: string): Promise<{success: boolean, message: string}> {
        const user = db.users.find(u => u.id === userId);
        if (!user || user.password !== oldPass) {
            return { success: false, message: "Incorrect old password." };
        }
        user.password = newPass;
        _save();
        return { success: true, message: "Password changed successfully." };
    },
    async redeemCode(userId: number, code: string): Promise<{success: boolean, message: string}> {
        const user = db.users.find(u => u.id === userId);
        const codeData = db.redeemCodes.find(c => c.code.toLowerCase() === code.toLowerCase());

        if (!user) return { success: false, message: "User not found." };
        if (!codeData || !codeData.isActive) return { success: false, message: "Invalid or inactive code." };
        if (codeData.usedBy.includes(userId)) return { success: false, message: "You have already used this code." };
        if (codeData.usedBy.length >= codeData.maxUsers) {
            codeData.isActive = false;
            _save();
            return { success: false, message: "This code has reached its usage limit." };
        }

        user.diamonds += codeData.amount;
        codeData.usedBy.push(userId);
        if (codeData.usedBy.length >= codeData.maxUsers) {
            codeData.isActive = false;
        }

        db.transactions.unshift({ id: _getNewId('tx'), userId, username: user.username, amount: codeData.amount, reason: `redeem_${code}`, timestamp: new Date().toISOString() });
        _save();
        return { success: true, message: `Successfully redeemed ${codeData.amount} diamonds!` };
    },

    // --- Data Retrieval ---
    async getUserHistory(userId: number, limit: number): Promise<SmsLog[]> {
        return db.smsLogs.filter(log => log.userId === userId).slice(0, limit);
    },
    async getTransactions(userId: number, limit: number): Promise<Transaction[]> {
        return db.transactions.filter(tx => tx.userId === userId).sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, limit);
    },
    async getLeaderboard(type: 'diamonds' | 'referrals' | 'smss', limit: number): Promise<User[]> {
        const sorted = [...db.users].sort((a, b) => {
            if (type === 'diamonds') return b.diamonds - a.diamonds;
            if (type === 'referrals') return b.referralCount - a.referralCount;
            if (type === 'smss') return b.totalSmss - a.totalSmss;
            return 0;
        });
        return sorted.slice(0, limit).map(u => { const { password, ...rest } = u; return rest; });
    },

    // --- Safelist ---
    async getSafelist(userId: number): Promise<SafeListItem[]> {
        const user = db.users.find(u => u.id === userId);
        return user ? user.safelist : [];
    },
    async addToSafelist(userId: number, phoneNumber: string, note: string): Promise<{ success: boolean, message: string }> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        if (user.safelist.some(item => item.phoneNumber === phoneNumber)) {
            return { success: false, message: "Number already in safelist." };
        }
        user.safelist.push({ phoneNumber, note, addedAt: new Date().toISOString() });
        _save();
        return { success: true, message: "Added to safelist." };
    },
    async removeFromSafelist(userId: number, phoneNumber: string): Promise<{ success: boolean, message: string }> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.safelist = user.safelist.filter(item => item.phoneNumber !== phoneNumber);
            _save();
            return { success: true, message: "Removed from safelist." };
        }
        return { success: false, message: "User not found." };
    },

    // --- Broadcast ---
    async getRecentBroadcasts(limit: number): Promise<Broadcast[]> {
        return [...db.broadcasts].sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime()).slice(0, limit);
    },
    async getUnreadBroadcasts(userId: number): Promise<Broadcast[]> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return [];
        const lastReadDate = user.lastReadBroadcastTimestamp ? new Date(user.lastReadBroadcastTimestamp) : new Date(0);
        return db.broadcasts.filter(b => new Date(b.sentAt) > lastReadDate);
    },
    async getUnreadBroadcastsCount(userId: number): Promise<number> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return 0;
        if (!user.lastReadBroadcastTimestamp) {
            return db.broadcasts.length; // If never read, all are unread
        }
        const lastReadDate = new Date(user.lastReadBroadcastTimestamp);
        return db.broadcasts.filter(b => new Date(b.sentAt) > lastReadDate).length;
    },
    async markBroadcastsAsRead(userId: number): Promise<void> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.lastReadBroadcastTimestamp = new Date().toISOString();
            _save();
        }
    },

    // --- Admin ---
    async getAllUsers(page: number, limit: number, searchTerm: string): Promise<{users: User[], total: number}> {
        const filteredUsers = db.users.filter(u => 
            u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
            u.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            u.id.toString().includes(searchTerm)
        );
        const paginatedUsers = filteredUsers.slice((page - 1) * limit, page * limit);
        return {
            users: paginatedUsers.map(u => { const { password, ...rest } = u; return rest; }),
            total: filteredUsers.length
        };
    },
    async getSystemStats(): Promise<any> {
        return {
            users: db.users.length,
            activeToday: db.users.filter(u => new Date(u.lastActive) > new Date(Date.now() - 24 * 60 * 60 * 1000)).length,
            smss: db.smsLogs.length, // Total attacks
            diamonds: db.users.reduce((acc, u) => acc + u.diamonds, 0),
            bannedUsers: db.users.filter(u => u.isBlocked).length,
            blacklistedNumbers: db.blacklist.length,
            totalTransactions: db.transactions.length
        };
    },
    async toggleUserBan(userId: number): Promise<{user: User | null, message: string}> {
        if (userId === OWNER_ID) return {user: null, message: "Cannot ban the owner."};
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.isBlocked = !user.isBlocked;
            _save();
            const { password, ...userWithoutPassword } = user;
            return {user: userWithoutPassword, message: `User has been ${user.isBlocked ? 'banned' : 'unbanned'}.`};
        }
        return {user: null, message: "User not found."};
    },
    async adminResetPassword(userId: number, newPass: string): Promise<{success: boolean, message: string}> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            user.password = newPass;
            _save();
            return {success: true, message: "Password reset successfully."};
        }
        return {success: false, message: "Failed to reset password."};
    },
    async manageDiamonds(userId: number, amount: number): Promise<{user: User | null, message: string}> {
        const user = db.users.find(u => u.id === userId);
        if (user) {
            if (amount < 0 && user.diamonds < Math.abs(amount)) {
                return {user: null, message: "User has insufficient diamonds to deduct."};
            }
            user.diamonds += amount;
            const reason = amount > 0 ? 'admin_gift' : 'admin_deduct';
            db.transactions.unshift({ id: _getNewId('tx'), userId, username: user.username, amount, reason, timestamp: new Date().toISOString()});
            _save();
            const { password, ...userWithoutPassword } = user;
            return {user: userWithoutPassword, message: `Successfully managed diamonds.`};
        }
        return {user: null, message: "User not found."};
    },
    async broadcastMessage(message: string, buttonText?: string, buttonUrl?: string): Promise<{ success: number, failed: number }> {
        await new Promise(res => setTimeout(res, 2000));
        const stats = { success: db.users.filter(u => !u.isBlocked).length, failed: 0 };
        db.broadcasts.unshift({
            id: _getNewId('broadcast'),
            adminId: db.loggedInUserId!,
            message,
            buttonText,
            buttonUrl,
            sentAt: new Date().toISOString(),
            stats
        });
        _save();
        console.log(`BROADCASTING: "${message}" to ${stats.success} users.`);
        return stats;
    },
    async getSettings(): Promise<SystemSettings> {
        return {...db.settings};
    },
    async updateSettings(newSettings: SystemSettings): Promise<SystemSettings> {
        db.settings = newSettings;
        _save();
        return {...db.settings};
    },
    async getBlacklist(): Promise<BlacklistItem[]> {
        return [...db.blacklist];
    },
    async addToBlacklist(phoneNumber: string, reason: string): Promise<{ success: boolean, message: string }> {
        if (db.blacklist.some(item => item.phoneNumber === phoneNumber)) {
            return { success: false, message: "Number already blacklisted." };
        }
        db.blacklist.unshift({ phoneNumber, reason, addedBy: db.loggedInUserId!, addedAt: new Date().toISOString() });
        _save();
        return { success: true, message: "Added to blacklist." };
    },
    async removeFromBlacklist(phoneNumber: string): Promise<{ success: boolean, message: string }> {
        const initialLength = db.blacklist.length;
        db.blacklist = db.blacklist.filter(item => item.phoneNumber !== phoneNumber);
        _save();
        return { success: db.blacklist.length < initialLength, message: db.blacklist.length < initialLength ? "Removed from blacklist." : "Number not found in blacklist." };
    },
    async getRedeemCodes(): Promise<RedeemCode[]> {
        return [...db.redeemCodes].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    },
    async createRedeemCode(code: string, amount: number, maxUsers: number): Promise<{ success: boolean, message: string }> {
        if (db.redeemCodes.some(c => c.code.toLowerCase() === code.toLowerCase())) {
            return { success: false, message: "Code already exists." };
        }
        db.redeemCodes.unshift({ code, amount, maxUsers, usedBy: [], isActive: true, createdAt: new Date().toISOString(), createdBy: db.loggedInUserId! });
        _save();
        return { success: true, message: "Code created." };
    },
    async deleteRedeemCode(code: string): Promise<{ success: boolean, message: string }> {
        const initialLength = db.redeemCodes.length;
        db.redeemCodes = db.redeemCodes.filter(c => c.code !== code);
        _save();
        return { success: db.redeemCodes.length < initialLength, message: db.redeemCodes.length < initialLength ? "Code deleted." : "Code not found." };
    },
    async getAllSmsLogs(page: number, limit: number): Promise<{logs: SmsLog[], total: number}> {
        const sortedLogs = [...db.smsLogs].sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        return {
            logs: sortedLogs.slice((page-1) * limit, page * limit),
            total: sortedLogs.length
        };
    },
    async getAllTransactions(page: number, limit: number): Promise<{transactions: Transaction[], total: number}> {
        const sortedTxs = [...db.transactions].sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
         return {
            transactions: sortedTxs.slice((page-1) * limit, page * limit),
            total: sortedTxs.length
        };
    },
    async getBroadcastHistory(): Promise<Broadcast[]> {
        return [...db.broadcasts].sort((a,b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
    },
    async getAdmins(): Promise<User[]> {
        return db.users.filter(u => u.isAdmin).map(u => { const { password, ...rest } = u; return rest; });
    },
    async addAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        if (user.isAdmin) return { success: false, message: "User is already an admin." };
        user.isAdmin = true;
        _save();
        return { success: true, message: "Admin added." };
    },
    async removeAdmin(userId: number): Promise<{ success: boolean, message: string }> {
        if (userId === OWNER_ID) return { success: false, message: "Cannot remove the owner." };
        const user = db.users.find(u => u.id === userId);
        if (!user) return { success: false, message: "User not found." };
        if (!user.isAdmin) return { success: false, message: "User is not an admin." };
        user.isAdmin = false;
        _save();
        return { success: true, message: "Admin removed." };
    },
    
    // --- SMS API ---
    async sendSmsRequest(settings: SystemSettings, targetNumber: string, amount: number): Promise<SmsApiResponse> {
        await new Promise(res => setTimeout(res, 1500));
        const taskId = `mock_task_${Date.now()}`;
        
        // Simulate the entire flow including logging and status updates
        this.logSmsAttack(db.loggedInUserId!, targetNumber, amount, amount * settings.smsCost, taskId)
            .then(log => {
                setTimeout(() => this.updateSmsLogStatus(log.taskId!, 'running', '50%'), 2000);
                setTimeout(() => this.updateSmsLogStatus(log.taskId!, 'completed', 'Finished!'), 4000);
            });

        return {
            success: true,
            message: 'Attack initiated (mock).',
            task_id: taskId,
        };
    },
    async checkTaskStatus(taskId: string): Promise<TaskStatusResponse> {
        // This is called by the UI poller, so it should return the current status from the mock DB.
        const log = db.smsLogs.find(l => l.taskId === taskId);
        if (!log) {
            return { task_id: taskId, status: 'not_found', phone: '', amount: 0, created_at: '' };
        }
        return {
            task_id: taskId,
            // FIX: Map 'started' status to 'running' to match the TaskStatusResponse type.
            status: log.status === 'started' ? 'running' : log.status,
            phone: log.targetNumber,
            amount: log.amount,
            created_at: log.timestamp,
            progress: log.progress,
        };
    },
};