
import React, { useState, useEffect } from 'react';
// FIX: Corrected import path for the mock API service.
import { api } from './mockApiService';
import { User } from '../types';
import { styleText } from '../constants';

type LeaderboardType = 'diamonds' | 'referrals' | 'smss';

const LeaderboardPage: React.FC = () => {
    const [leaderboardType, setLeaderboardType] = useState<LeaderboardType>('smss');
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLeaderboard = async () => {
            setLoading(true);
            setUsers([]); // Clear previous users to show loader
            const data = await api.getLeaderboard(leaderboardType, 20);
            setUsers(data);
            setLoading(false);
        };
        fetchLeaderboard();
    }, [leaderboardType]);
    
    const getMedal = (index: number) => {
        if (index === 0) return <span className="text-3xl">🥇</span>;
        if (index === 1) return <span className="text-2xl">🥈</span>;
        if (index === 2) return <span className="text-xl">🥉</span>;
        return <span className="text-gray-400 font-bold">{index + 1}</span>;
    };

    const renderValue = (user: User) => {
        switch (leaderboardType) {
            case 'diamonds': return `💎 ${user.diamonds.toLocaleString()}`;
            case 'referrals': return `👥 ${user.referralCount.toLocaleString()}`;
            case 'smss': return `💣 ${user.totalSmss.toLocaleString()}`;
        }
    };
    
    const getTabClass = (type: LeaderboardType) => {
      return `w-full py-2.5 text-sm font-semibold rounded-lg transition-all duration-300 ${leaderboardType === type ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-300 hover:bg-gray-800'}`;
    };

    const SkeletonLoader = () => (
        <div className="space-y-3">
            {[...Array(10)].map((_, i) => (
                <div key={i} className="flex items-center glass-card p-4 rounded-lg animate-pulse">
                    <div className="w-12 h-6 bg-gray-700 rounded-md"></div>
                    <div className="flex-1 h-6 bg-gray-700 rounded-md mx-4"></div>
                    <div className="w-24 h-6 bg-gray-700 rounded-md"></div>
                </div>
            ))}
        </div>
    );

    return (
        <div className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-8 px-4 sm:px-0 text-center">{styleText('🏆 Leaderboards')}</h1>
            
            <div className="glass-card shadow-2xl rounded-2xl p-4 md:p-6">
                <div className="flex justify-center bg-gray-900/50 p-1 rounded-xl mb-6">
                    <button onClick={() => setLeaderboardType('smss')} className={getTabClass('smss')}>{styleText('Top Bombers')}</button>
                    <button onClick={() => setLeaderboardType('diamonds')} className={getTabClass('diamonds')}>{styleText('Top Richest')}</button>
                    <button onClick={() => setLeaderboardType('referrals')} className={getTabClass('referrals')}>{styleText('Top Referrers')}</button>
                </div>
                
                {loading ? (
                   <SkeletonLoader />
                ) : (
                    <div className="space-y-3">
                        {users.map((user, index) => (
                            <div key={user.id} className="flex items-center bg-gray-900/50 p-4 rounded-xl hover:bg-gray-800 transition-colors border border-transparent hover:border-indigo-500">
                                <div className="w-12 text-center font-bold text-lg flex items-center justify-center">{getMedal(index)}</div>
                                <div className="flex-1 font-semibold text-gray-200 ml-4">{user.firstName}</div>
                                <div className="font-bold text-indigo-400 font-mono text-lg">{renderValue(user)}</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default LeaderboardPage;