import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { styleText, APP_NAME } from '../constants';

const LoginPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login, signup } = useAuth();
  const location = useLocation();

  React.useEffect(() => {
    const params = new URLSearchParams(location.search);
    const ref = params.get('ref');
    if (ref) {
      setReferralCode(ref);
      setIsLogin(false); // Switch to sign-up form if ref link is used
    }
  }, [location.search]);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        if (!username || !password) {
            setError("Username and Password are required.");
            setLoading(false);
            return;
        }
        const user = await login(username, password);
        if (user) {
          navigate('/');
        } else {
          setError('Invalid username or password.');
        }
      } else {
        if (!username || !firstName || !password) {
            setError("Username, First Name, and Password are required.");
            setLoading(false);
            return;
        }
        if (username.length < 5) {
            setError("Username must be at least 5 characters long.");
            setLoading(false);
            return;
        }
        if (!/^[a-zA-Z0-9]+$/.test(username)) {
            setError("Username can only contain letters and numbers.");
            setLoading(false);
            return;
        }
        if (password !== confirmPassword) {
            setError("Passwords do not match.");
            setLoading(false);
            return;
        }
        const user = await signup(username, firstName, password, referralCode);
        if (user) {
          navigate('/');
        } else {
          setError('Username already exists or invalid referral code.');
        }
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 p-4 relative overflow-hidden">
       <div className="absolute -top-1/2 -left-1/2 w-[200%] h-[200%] bg-gradient-to-br from-indigo-900 via-gray-950 to-purple-900 animate-gradient-spin -z-10"></div>
       <div className="w-full max-w-md p-8 space-y-8 glass-card rounded-2xl shadow-2xl relative">
        <div className="text-center">
            <h1 className="text-5xl font-extrabold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
                💣 {styleText(APP_NAME)}
            </h1>
            <p className="text-gray-400">{styleText(isLogin ? 'Login to your control panel' : 'Create an account to begin')}</p>
        </div>
        
        <div className="flex justify-center bg-gray-900/50 p-1 rounded-xl">
          <button
            onClick={() => setIsLogin(true)}
            className={`w-1/2 py-2.5 text-sm font-semibold rounded-lg transition-all duration-300 ${isLogin ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-300'}`}
          >
            {styleText('LOGIN')}
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`w-1/2 py-2.5 text-sm font-semibold rounded-lg transition-all duration-300 ${!isLogin ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-300'}`}
          >
            {styleText('SIGN UP')}
          </button>
        </div>
        
        <form className="space-y-6" onSubmit={handleSubmit}>
          {!isLogin && (
             <input
              type="text"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder={styleText('First Name')}
              className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          )}
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder={styleText('Username')}
            autoComplete="username"
            className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
           <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={styleText('Password')}
            autoComplete={isLogin ? "current-password" : "new-password"}
            className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          {!isLogin && (
            <>
            <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={styleText('Confirm Password')}
                autoComplete="new-password"
                className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <input
              type="text"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value)}
              placeholder={styleText('Referral Code (Optional)')}
              className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            </>
          )}
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 focus:ring-offset-gray-900 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center"
          >
            {loading ? <div className="w-6 h-6 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : styleText(isLogin ? 'LOGIN' : 'SIGN UP')}
          </button>
        </form>
      </div>
      <style>{`
        @keyframes gradient-spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .animate-gradient-spin {
            animation: gradient-spin 15s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default LoginPage;
