import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { api } from '../services/mockApiService';
import { styleText, REFERRAL_DOMAIN } from '../constants';
import { SafeListItem, Transaction } from '../types';
import { ClipboardIcon, CheckIcon, UserCircleIcon, ShieldCheckIcon, LockClosedIcon, TicketIcon } from '@heroicons/react/24/solid';

type ActiveTab = 'profile' | 'security' | 'safelist' | 'redeem';

const ProfilePage: React.FC = () => {
    const { user, refreshUser } = useAuth();
    const { addToast } = useToast();
    const [activeTab, setActiveTab] = useState<ActiveTab>('profile');

    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [safelist, setSafelist] = useState<SafeListItem[]>([]);
    const [newSafeNumber, setNewSafeNumber] = useState('');
    const [newSafeNote, setNewSafeNote] = useState('');
    const [copied, setCopied] = useState(false);
    
    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const [redeemCode, setRedeemCode] = useState('');


    const fetchProfileData = useCallback(async () => {
        if (user) {
            const [userTransactions, userSafelist] = await Promise.all([
                api.getTransactions(user.id, 10),
                api.getSafelist(user.id)
            ]);
            setTransactions(userTransactions);
            setSafelist(userSafelist);
        }
    }, [user]);

    useEffect(() => {
        fetchProfileData();
    }, [fetchProfileData]);
    
    const handleAddSafelist = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        if (!/^01[3-9]\d{8}$/.test(newSafeNumber)) {
            return addToast('Invalid Bangladeshi phone number format.', 'error');
        }
        const result = await api.addToSafelist(user.id, newSafeNumber, newSafeNote);
        if (result.success) {
            addToast(result.message, 'success');
            setNewSafeNumber('');
            setNewSafeNote('');
            await fetchProfileData();
        } else {
            addToast(result.message, 'error');
        }
    };

    const handleRemoveSafelist = async (phoneNumber: string) => {
        if (!user) return;
        const result = await api.removeFromSafelist(user.id, phoneNumber);
        if (result.success) {
            addToast(result.message, 'info');
            await fetchProfileData();
        } else {
            addToast(result.message, 'error');
        }
    };
    
    const copyReferralLink = () => {
        if(!user) return;
        const link = `https://${REFERRAL_DOMAIN}/#/login?ref=${user.referralCode}`;
        navigator.clipboard.writeText(link);
        setCopied(true);
        addToast('Referral link copied!', 'success');
        setTimeout(() => setCopied(false), 2000);
    };

    const handleChangePassword = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        if (newPassword !== confirmPassword) {
            return addToast("New passwords do not match.", 'error');
        }
        if (newPassword.length < 6) {
            return addToast("Password must be at least 6 characters long.", 'error');
        }

        const result = await api.changePassword(user.id, oldPassword, newPassword);
        if (result.success) {
            addToast(result.message, 'success');
            setOldPassword('');
            setNewPassword('');
            setConfirmPassword('');
        } else {
            addToast(result.message, 'error');
        }
    };

    const handleRedeemCode = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!user || !redeemCode) return;
        const result = await api.redeemCode(user.id, redeemCode);
        if(result.success) {
            addToast(result.message, 'success');
            setRedeemCode('');
            await refreshUser();
        } else {
            addToast(result.message, 'error');
        }
    }

    if (!user) return null;
    
    const TabButton: React.FC<{tab: ActiveTab, label: string, icon: React.ElementType}> = ({tab, label, icon: Icon}) => (
         <button onClick={() => setActiveTab(tab)} className={`flex-1 flex items-center justify-center gap-2 p-3 text-sm font-semibold rounded-lg transition-all duration-300 ${activeTab === tab ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-300 hover:bg-gray-800'}`}>
            <Icon className="h-5 w-5"/>
            <span className="hidden sm:inline">{styleText(label)}</span>
        </button>
    );

    return (
        <div className="max-w-5xl mx-auto py-6 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
                <h1 className="text-4xl font-extrabold text-white">{styleText(`${user.firstName}'s Profile`)}</h1>
            </div>
            <div className="glass-card shadow-2xl rounded-2xl p-4 md:p-6">
                <div className="flex justify-center bg-gray-900/50 p-1 rounded-xl mb-6">
                    <TabButton tab="profile" label="Profile" icon={UserCircleIcon} />
                    <TabButton tab="security" label="Security" icon={LockClosedIcon} />
                    <TabButton tab="safelist" label="Safelist" icon={ShieldCheckIcon} />
                    <TabButton tab="redeem" label="Redeem" icon={TicketIcon} />
                </div>
                
                <div>
                    {activeTab === 'profile' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in">
                            <div className="space-y-6">
                                <div className="bg-gray-900/50 p-6 rounded-xl">
                                    <h3 className="text-lg font-bold text-white mb-4">{styleText('📊 Statistics')}</h3>
                                    <div className="space-y-3 text-gray-300 text-sm">
                                        <p className="flex justify-between"><span>💎 {styleText('Diamonds:')}</span> <span className="font-bold text-white font-mono">{user.diamonds.toLocaleString()}</span></p>
                                        <p className="flex justify-between"><span>💣 {styleText('Total Attacks:')}</span> <span className="font-bold text-white font-mono">{user.totalSmss.toLocaleString()}</span></p>
                                        <p className="flex justify-between"><span>👥 {styleText('Referrals:')}</span> <span className="font-bold text-white font-mono">{user.referralCount}</span></p>
                                    </div>
                                </div>
                                 <div className="bg-gray-900/50 p-6 rounded-xl">
                                    <h3 className="text-lg font-bold text-white mb-4">{styleText('👥 Referral Program')}</h3>
                                    <p className="text-gray-400 text-xs mb-4">{styleText(`Share your code (it's your user ID) to earn diamonds!`)}</p>
                                    <div className="bg-gray-800 p-3 rounded-lg flex items-center justify-between">
                                        <code className="text-indigo-300 text-sm">{user.referralCode}</code>
                                        <button onClick={copyReferralLink} title="Copy Referral Link">
                                            {copied ? <CheckIcon className="h-5 w-5 text-green-400"/> : <ClipboardIcon className="h-5 w-5 text-gray-400 hover:text-white"/>}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className="bg-gray-900/50 p-6 rounded-xl">
                                <h3 className="text-lg font-bold text-white mb-4">{styleText('📜 Recent Activity')}</h3>
                                <div className="space-y-3 max-h-[280px] overflow-y-auto pr-2">
                                    {transactions.length > 0 ? transactions.map(tx => (
                                        <div key={tx.id} className="flex justify-between items-center text-sm">
                                            <div>
                                                <p className="font-semibold text-gray-200">{tx.reason.replace(/_/g, ' ').toUpperCase()}</p>
                                                <p className="text-gray-400 text-xs">{new Date(tx.timestamp).toLocaleString()}</p>
                                            </div>
                                            <p className={`font-bold font-mono ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                                {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString()} 💎
                                            </p>
                                        </div>
                                    )) : <p className="text-gray-400 text-center">{styleText('No recent transactions.')}</p>}
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {activeTab === 'security' && (
                        <div className="animate-fade-in max-w-md mx-auto">
                            <h3 className="text-lg font-bold text-white mb-4">{styleText('🔑 Change Password')}</h3>
                            <form onSubmit={handleChangePassword} className="space-y-4">
                                <input type="password" value={oldPassword} onChange={e => setOldPassword(e.target.value)} placeholder="Old Password" required className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2.5 text-sm focus:ring-indigo-500 focus:border-indigo-500" />
                                <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="New Password" required className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2.5 text-sm focus:ring-indigo-500 focus:border-indigo-500" />
                                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Confirm New Password" required className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2.5 text-sm focus:ring-indigo-500 focus:border-indigo-500" />
                                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg text-sm">{styleText('Update Password')}</button>
                            </form>
                        </div>
                    )}
                    
                    {activeTab === 'safelist' && (
                         <div className="animate-fade-in">
                            <h3 className="text-lg font-bold text-white mb-4">{styleText('🛡️ My Safe List')}</h3>
                            <form onSubmit={handleAddSafelist} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                <input type="text" value={newSafeNumber} onChange={e => setNewSafeNumber(e.target.value)} placeholder="Phone Number" className="md:col-span-1 bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2.5 text-sm focus:ring-indigo-500 focus:border-indigo-500" />
                                <input type="text" value={newSafeNote} onChange={e => setNewSafeNote(e.target.value)} placeholder="Note (e.g., Mom)" className="md:col-span-1 bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2.5 text-sm focus:ring-indigo-500 focus:border-indigo-500" />
                                <button type="submit" className="md:col-span-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg text-sm">{styleText('Add Number')}</button>
                            </form>
                            <div className="max-h-60 overflow-y-auto pr-2 space-y-2">
                                {safelist.length > 0 ? safelist.map(item => (
                                    <div key={item.phoneNumber} className="flex justify-between items-center bg-gray-900/50 p-3 rounded-lg">
                                        <div>
                                            <p className="font-mono text-gray-200">{item.phoneNumber}</p>
                                            <p className="text-xs text-gray-400">{item.note || 'No note'}</p>
                                        </div>
                                        <button onClick={() => handleRemoveSafelist(item.phoneNumber)} className="text-red-400 hover:text-red-300 text-xs font-semibold">{styleText('REMOVE')}</button>
                                    </div>
                                )) : <p className="text-gray-400 text-center">{styleText('Your safelist is empty.')}</p>}
                            </div>
                        </div>
                    )}

                    {activeTab === 'redeem' && (
                        <div className="animate-fade-in max-w-md mx-auto">
                            <h3 className="text-lg font-bold text-white mb-4">{styleText('🎟️ Redeem Code')}</h3>
                             <p className="text-gray-400 text-xs text-center mb-4">{styleText('Have a code? Enter it below to claim your reward!')}</p>
                            <form onSubmit={handleRedeemCode} className="flex gap-4">
                                <input type="text" value={redeemCode} onChange={e => setRedeemCode(e.target.value)} placeholder="Enter your code" required className="flex-grow bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-2.5 text-sm focus:ring-indigo-500 focus:border-indigo-500" />
                                <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-6 rounded-lg text-sm">{styleText('Claim')}</button>
                            </form>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;
<style>{`
    @keyframes fade-in {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-in {
        animation: fade-in 0.5s ease-out forwards;
    }
`}</style>
