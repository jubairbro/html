import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { styleText, APP_NAME } from '../constants';
import { api } from '../services/mockApiService';
import NotificationDropdown from './NotificationDropdown';
import { BellIcon, Bars3Icon, XMarkIcon } from '@heroicons/react/24/solid';

const Navbar: React.FC = () => {
  const { user, logout, unreadCount, fetchUnreadCount } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleNotificationsToggle = async () => {
    const currentlyOpening = !isNotificationsOpen;
    setIsNotificationsOpen(currentlyOpening);
    
    if (currentlyOpening && unreadCount > 0 && user) {
        await api.markBroadcastsAsRead(user.id);
        await fetchUnreadCount(); 
    }
  };

  const commonLinkClasses = "px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200";
  const activeLinkClasses = "bg-indigo-600 text-white shadow-lg";
  const inactiveLinkClasses = "text-gray-300 hover:bg-gray-800 hover:text-white";

  const navLink = ({ isActive }: { isActive: boolean }) => 
    `${commonLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`;

  const navLinks = (
    <>
      <NavLink to="/" className={navLink} onClick={() => setIsMenuOpen(false)} end>💣 {styleText('Bomb')}</NavLink>
      <NavLink to="/profile" className={navLink} onClick={() => setIsMenuOpen(false)}>👤 {styleText('Profile')}</NavLink>
      <NavLink to="/leaderboard" className={navLink} onClick={() => setIsMenuOpen(false)}>🏆 {styleText('Leaders')}</NavLink>
      {user?.isAdmin && <NavLink to="/admin" className={navLink} onClick={() => setIsMenuOpen(false)}>👑 {styleText('Admin')}</NavLink>}
    </>
  );

  return (
    <nav className="glass-card fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-white font-bold text-xl">
              <NavLink to="/" className="flex items-center gap-2 group">
                <span className="text-3xl group-hover:animate-pulse">💣</span>
                <span className="hidden sm:inline bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400 font-extrabold">{styleText(APP_NAME)}</span>
              </NavLink>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navLinks}
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="ml-4 flex items-center md:ml-6">
                <div className="relative">
                  <button
                    onClick={handleNotificationsToggle}
                    className="relative p-2 rounded-full text-gray-300 hover:text-white hover:bg-gray-700/50 transition-colors"
                    aria-label="View notifications"
                  >
                    <BellIcon className="h-6 w-6" />
                    {unreadCount > 0 && (
                      <span className="absolute top-1 right-1 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                      </span>
                    )}
                  </button>
                  <NotificationDropdown isOpen={isNotificationsOpen} onClose={() => setIsNotificationsOpen(false)} />
                </div>
              <div className="text-gray-300 mx-4 font-semibold text-lg">
                💎 <span className="font-mono">{user?.diamonds.toLocaleString() || 0}</span>
              </div>
              <button
                onClick={handleLogout}
                className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-red-700 transition-colors shadow-md"
              >
                {styleText('Logout')}
              </button>
            </div>
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="bg-gray-800 inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <XMarkIcon className="block h-6 w-6" />
              ) : (
                <Bars3Icon className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden glass-card border-t border-gray-700">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 flex flex-col">
            {navLinks}
            <div className="border-t border-gray-700 my-2"></div>
             <div className="text-gray-300 px-3 py-2 font-semibold text-lg">
                💎 <span className="font-mono">{user?.diamonds.toLocaleString() || 0}</span>
              </div>
            <button
              onClick={handleLogout}
              className="bg-red-600 text-white text-left px-3 py-2 rounded-md text-sm font-medium hover:bg-red-700 transition-colors"
            >
              {styleText('Logout')}
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
