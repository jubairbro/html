
import React, { useState, useEffect, useCallback } from 'react';
// FIX: Corrected import path for the mock API service.
import { api } from '../../pages/mockApiService';
import { User } from '../../types';
import { styleText } from '../../constants';
import { useToast } from '../../contexts/ToastContext';
import Modal from '../Modal';

type ModalAction = 'add' | 'deduct' | 'resetPassword';

const UserManagement: React.FC = () => {
    const { addToast } = useToast();
    const [users, setUsers] = useState<User[]>([]);
    const [totalUsers, setTotalUsers] = useState(0);
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState('');
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalAction, setModalAction] = useState<ModalAction | null>(null);
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [inputValue, setInputValue] = useState('');

    const usersPerPage = 10;

    const fetchUsers = useCallback(async (page: number, search: string) => {
        setLoading(true);
        const { users: fetchedUsers, total } = await api.getAllUsers(page, usersPerPage, search);
        setUsers(fetchedUsers);
        setTotalUsers(total);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchUsers(currentPage, searchTerm);
    }, [currentPage, fetchUsers]);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        setCurrentPage(1);
        fetchUsers(1, searchTerm);
    };
    
    const totalPages = Math.ceil(totalUsers / usersPerPage);

    const openModal = (action: ModalAction, user: User) => {
        setSelectedUser(user);
        setModalAction(action);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setModalAction(null);
        setSelectedUser(null);
        setInputValue('');
    };

    const handleModalSubmit = async () => {
        if (!selectedUser || !modalAction) return;

        if (modalAction === 'add' || modalAction === 'deduct') {
            const amount = parseInt(inputValue);
            if (isNaN(amount) || amount <= 0) {
                return addToast('Please enter a valid positive number.', 'error');
            }
            const result = await api.manageDiamonds(selectedUser.id, modalAction === 'add' ? amount : -amount);
            if (result.user) {
                addToast(result.message, 'success');
                await fetchUsers(currentPage, searchTerm);
            } else {
                addToast(result.message, 'error');
            }
        } else if (modalAction === 'resetPassword') {
            if (inputValue.length < 6) {
                return addToast('Password must be at least 6 characters.', 'error');
            }
            const result = await api.adminResetPassword(selectedUser.id, inputValue);
            if (result.success) {
                addToast(result.message, 'success');
            } else {
                addToast(result.message, 'error');
            }
        }
        closeModal();
    };

    const handleToggleBan = async (user: User) => {
        const result = await api.toggleUserBan(user.id);
        if (result.user) {
            addToast(result.message, 'success');
            await fetchUsers(currentPage, searchTerm);
        } else {
            addToast(result.message, 'error');
        }
    };
    
    const getModalContent = () => {
        if(!modalAction || !selectedUser) return null;
        switch(modalAction) {
            case 'add':
                return { title: `Add Diamonds to ${selectedUser.username}`, inputType: 'number', inputPlaceholder: 'Amount to add' };
            case 'deduct':
                return { title: `Deduct Diamonds from ${selectedUser.username}`, inputType: 'number', inputPlaceholder: 'Amount to deduct' };
            case 'resetPassword':
                return { title: `Reset Password for ${selectedUser.username}`, inputType: 'text', inputPlaceholder: 'Enter new password' };
            default: return null;
        }
    };

    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('User Management')}</h1>
            
            <form onSubmit={handleSearch} className="flex gap-2 mb-6">
                <input 
                    type="text" 
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Search by ID, Username, or Name..."
                    className="flex-grow bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white"
                />
                <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-6 rounded-lg">{styleText('Search')}</button>
            </form>

            <div className="bg-gray-800/50 rounded-xl overflow-hidden border border-gray-700">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                            <tr>
                                <th className="px-6 py-3">User</th>
                                <th className="px-6 py-3">Diamonds</th>
                                <th className="px-6 py-3">Status</th>
                                <th className="px-6 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                <tr><td colSpan={4} className="text-center py-8"><div className="w-8 h-8 border-2 border-t-transparent border-white rounded-full animate-spin mx-auto"></div></td></tr>
                            ) : users.map(user => (
                                <tr key={user.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                                    <td className="px-6 py-4">
                                        <p className="font-semibold">{user.firstName} (@{user.username})</p>
                                        <p className="text-xs text-gray-500">ID: {user.id}</p>
                                    </td>
                                    <td className="px-6 py-4 font-mono">💎 {user.diamonds.toLocaleString()}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${user.isBlocked ? 'bg-red-900 text-red-300' : 'bg-green-900 text-green-300'}`}>
                                            {user.isBlocked ? 'Banned' : 'Active'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-center space-x-1">
                                        <button onClick={() => openModal('add', user)} className="p-1.5 text-xs bg-green-600 rounded hover:bg-green-500" title="Add Diamonds">➕💎</button>
                                        <button onClick={() => openModal('deduct', user)} className="p-1.5 text-xs bg-yellow-600 rounded hover:bg-yellow-500" title="Deduct Diamonds">➖💎</button>
                                        <button onClick={() => openModal('resetPassword', user)} className="p-1.5 text-xs bg-purple-600 rounded hover:bg-purple-500" title="Reset Password">🔑</button>
                                        <button onClick={() => handleToggleBan(user)} className={`p-1.5 text-xs ${user.isBlocked ? 'bg-sky-600 hover:bg-sky-500' : 'bg-red-600 hover:bg-red-500'} rounded`} title={user.isBlocked ? 'Unban User' : 'Ban User'}>🚫</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {users.length === 0 && !loading && <p className="text-center py-8 text-gray-400">No users found.</p>}
            </div>
            
             {totalPages > 1 && (
                <div className="flex justify-center mt-6">
                    <nav className="inline-flex rounded-md shadow">
                        <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-4 py-2 text-sm font-medium text-white bg-gray-800 rounded-l-lg hover:bg-gray-700 disabled:opacity-50">Prev</button>
                        <span className="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-900">Page {currentPage} of {totalPages}</span>
                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages} className="px-4 py-2 text-sm font-medium text-white bg-gray-800 rounded-r-lg hover:bg-gray-700 disabled:opacity-50">Next</button>
                    </nav>
                </div>
            )}

            <Modal 
                isOpen={isModalOpen}
                onClose={closeModal}
                title={getModalContent()?.title || ''}
                onConfirm={handleModalSubmit}
            >
                <input
                    type={getModalContent()?.inputType || 'text'}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={getModalContent()?.inputPlaceholder || ''}
                    className="w-full mt-4 bg-gray-800 border border-gray-600 rounded-lg px-4 py-2 text-white"
                    autoFocus
                />
            </Modal>
        </div>
    );
};

export default UserManagement;