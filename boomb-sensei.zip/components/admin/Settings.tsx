import React, { useState, useEffect } from 'react';
import { api } from '../../services/mockApiService';
import { SystemSettings } from '../../types';
import { styleText } from '../../constants';
import { useToast } from '../../contexts/ToastContext';

const Settings: React.FC = () => {
    const { addToast } = useToast();
    const [settings, setSettings] = useState<SystemSettings | null>(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        const fetchSettings = async () => {
            setLoading(true);
            const data = await api.getSettings();
            setSettings(data);
            setLoading(false);
        };
        fetchSettings();
    }, []);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        if (!settings) return;
        const { name, value, type } = e.target;
        
        let processedValue: string | number | boolean = value;
        if (type === 'number') {
            processedValue = parseInt(value, 10);
            if (isNaN(processedValue)) processedValue = 0;
        } else if (name === 'maintenanceMode') {
            processedValue = value === 'true';
        }

        setSettings({ ...settings, [name]: processedValue });
    };

    const handleSave = async () => {
        if (!settings) return;
        setSaving(true);
        await api.updateSettings(settings);
        setSaving(false);
        addToast('Settings saved successfully!', 'success');
    };

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div></div>;
    }

    if (!settings) return <p>Could not load settings.</p>;
    
    const InputField = ({ label, name, type, value, children, placeholder }: {label: string, name: keyof SystemSettings, type: string, value: any, children?: React.ReactNode, placeholder?: string}) => (
        <div>
            <label htmlFor={name} className="block text-sm font-medium text-gray-300 mb-1">{styleText(label)}</label>
            {children ? children :
            <input
                type={type}
                id={name}
                name={name}
                value={value}
                onChange={handleInputChange}
                placeholder={placeholder}
                className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-2 text-white"
            />
            }
        </div>
    );

    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('System Settings')}</h1>
            
            <div className="space-y-6 bg-gray-800/50 p-6 rounded-xl border border-gray-700">
                <InputField label="Maintenance Mode" name="maintenanceMode" type="select" value={settings.maintenanceMode.toString()}>
                    <select id="maintenanceMode" name="maintenanceMode" value={settings.maintenanceMode.toString()} onChange={handleInputChange} className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-2 text-white">
                        <option value="false">Off</option>
                        <option value="true">On</option>
                    </select>
                </InputField>
                <hr className="border-gray-700"/>
                <h2 className="text-lg font-bold text-white -mb-2">{styleText('Economy Settings')}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <InputField label="Daily Bonus" name="dailyBonus" type="number" value={settings.dailyBonus} />
                    <InputField label="Referral Bonus" name="referralBonus" type="number" value={settings.referralBonus} />
                    <InputField label="SMS Cost (Diamonds)" name="smsCost" type="number" value={settings.smsCost} />
                    <InputField label="Max SMS Amount" name="maxSmsAmount" type="number" value={settings.maxSmsAmount} />
                </div>
                <InputField label="Max Referrals per User" name="maxReferrals" type="number" value={settings.maxReferrals} />
                 <hr className="border-gray-700"/>
                <h2 className="text-lg font-bold text-white -mb-2">{styleText('API Configuration')}</h2>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <InputField label="SMS API Key" name="apiKey" type="text" value={settings.apiKey} />
                    <InputField label="Request Timeout (seconds)" name="requestTimeout" type="number" value={settings.requestTimeout} />
                 </div>
                <p className="text-xs text-gray-400 mt-2">The SMS API URL is handled by the Nginx reverse proxy and is not set here.</p>

                <button
                    onClick={handleSave}
                    disabled={saving}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-lg disabled:bg-gray-500 mt-4"
                >
                    {saving ? 'Saving...' : 'Save Settings'}
                </button>
            </div>
        </div>
    );
};

export default Settings;
