import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/mockApiService';
import { SmsLog } from '../../types';
import { styleText } from '../../constants';

const SmsLogs: React.FC = () => {
    const [logs, setLogs] = useState<SmsLog[]>([]);
    const [totalLogs, setTotalLogs] = useState(0);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const logsPerPage = 15;

    const fetchLogs = useCallback(async (page: number) => {
        setLoading(true);
        const { logs: fetchedLogs, total } = await api.getAllSmsLogs(page, logsPerPage);
        setLogs(fetchedLogs);
        setTotalLogs(total);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchLogs(currentPage);
    }, [currentPage, fetchLogs]);

    const totalPages = Math.ceil(totalLogs / logsPerPage);

    const getStatusChip = (status: SmsLog['status']) => {
        switch (status) {
            case 'completed': return <span className="px-2 py-1 text-xs font-semibold text-green-200 bg-green-900 rounded-full">Completed</span>;
            case 'failed': return <span className="px-2 py-1 text-xs font-semibold text-red-200 bg-red-900 rounded-full">Failed</span>;
            case 'running': return <span className="px-2 py-1 text-xs font-semibold text-sky-200 bg-sky-900 rounded-full">Running</span>;
            case 'started': return <span className="px-2 py-1 text-xs font-semibold text-yellow-200 bg-yellow-900 rounded-full">Started</span>;
        }
    };
    
    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('System-Wide SMS Logs')}</h1>

            <div className="bg-gray-800/50 rounded-xl overflow-hidden border border-gray-700">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                            <tr>
                                <th scope="col" className="px-6 py-3">User</th>
                                <th scope="col" className="px-6 py-3">Target</th>
                                <th scope="col" className="px-6 py-3">Amount</th>
                                <th scope="col" className="px-6 py-3">Cost</th>
                                <th scope="col" className="px-6 py-3">Status</th>
                                <th scope="col" className="px-6 py-3">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                <tr><td colSpan={6} className="text-center py-8"><div className="w-8 h-8 border-2 border-t-transparent border-white rounded-full animate-spin mx-auto"></div></td></tr>
                            ) : logs.map(log => (
                                <tr key={log.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                                    <td className="px-6 py-4">{log.username} ({log.userId})</td>
                                    <td className="px-6 py-4 font-mono">{log.targetNumber}</td>
                                    <td className="px-6 py-4">{log.amount}</td>
                                    <td className="px-6 py-4 text-red-400">{log.cost} 💎</td>
                                    <td className="px-6 py-4">{getStatusChip(log.status)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {logs.length === 0 && !loading && <p className="text-center py-8 text-gray-400">No SMS logs found.</p>}
            </div>
            
             {totalPages > 1 && (
                <div className="flex justify-center mt-6">
                    <nav className="inline-flex rounded-md shadow">
                        <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-4 py-2 text-sm font-medium text-white bg-gray-800 rounded-l-lg hover:bg-gray-700 disabled:opacity-50">Prev</button>
                        <span className="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-900">Page {currentPage} of {totalPages}</span>
                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages} className="px-4 py-2 text-sm font-medium text-white bg-gray-800 rounded-r-lg hover:bg-gray-700 disabled:opacity-50">Next</button>
                    </nav>
                </div>
            )}
        </div>
    );
};

export default SmsLogs;
