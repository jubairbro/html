import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/mockApiService';
import { User } from '../../types';
import { styleText } from '../../constants';
import { OWNER_ID } from '../../constants';
import { useToast } from '../../contexts/ToastContext';

const AdminManagement: React.FC = () => {
    const { addToast } = useToast();
    const [admins, setAdmins] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [newAdminId, setNewAdminId] = useState('');
    const [error, setError] = useState('');

    const fetchAdmins = useCallback(async () => {
        setLoading(true);
        const data = await api.getAdmins();
        setAdmins(data);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchAdmins();
    }, [fetchAdmins]);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        try {
            const userId = parseInt(newAdminId);
            const result = await api.addAdmin(userId);
            if (result.success) {
                addToast(result.message, 'success');
                setNewAdminId('');
                await fetchAdmins();
            } else {
                setError(result.message);
            }
        } catch {
            setError('Invalid User ID.');
        }
    };

    const handleRemove = async (userId: number) => {
        const result = await api.removeAdmin(userId);
        if(result.success) {
             addToast(result.message, 'info');
             await fetchAdmins();
        } else {
            addToast(result.message, 'error');
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div></div>;
    }

    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('Admin Management')}</h1>

            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 mb-8">
                <h2 className="text-lg font-bold text-white mb-4">{styleText('Add New Admin')}</h2>
                <form onSubmit={handleAdd} className="flex gap-4">
                    <input type="text" value={newAdminId} onChange={e => setNewAdminId(e.target.value)} placeholder="User ID" className="flex-grow bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"/>
                    <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg text-sm">{styleText('Add Admin')}</button>
                </form>
                {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
            </div>
            
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700">
                 <h2 className="text-lg font-bold text-white mb-4">{styleText('Current Admins')}</h2>
                 <div className="space-y-3">
                     {admins.map(admin => (
                         <div key={admin.id} className="flex justify-between items-center bg-gray-700/50 p-3 rounded-lg">
                             <div>
                                 <p className="font-semibold text-gray-200">{admin.firstName} (@{admin.username})</p>
                                 <p className="text-xs text-gray-400">ID: {admin.id}</p>
                             </div>
                             {admin.id === OWNER_ID ? (
                                <span className="text-xs font-bold text-yellow-400">OWNER</span>
                             ) : (
                               <button onClick={() => handleRemove(admin.id)} className="text-red-400 hover:text-red-300 text-xs font-semibold">{styleText('REMOVE')}</button>
                             )}
                         </div>
                     ))}
                 </div>
            </div>
        </div>
    );
};

export default AdminManagement;
