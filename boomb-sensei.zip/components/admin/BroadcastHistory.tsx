
import React, { useState, useEffect } from 'react';
// FIX: Corrected import path for the mock API service.
import { api } from '../../pages/mockApiService';
import { Broadcast } from '../../types';
import { styleText } from '../../constants';

const BroadcastHistory: React.FC = () => {
    const [history, setHistory] = useState<Broadcast[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchHistory = async () => {
            setLoading(true);
            const data = await api.getBroadcastHistory();
            setHistory(data);
            setLoading(false);
        };
        fetchHistory();
    }, []);

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div></div>;
    }

    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('Broadcast History')}</h1>

            <div className="space-y-4">
                {history.length > 0 ? history.map(log => (
                    <div key={log.id} className="bg-gray-800/50 border border-gray-700 p-4 rounded-xl">
                        <p className="text-gray-200 mb-2">"{log.message}"</p>
                        <div className="text-xs text-gray-400 flex justify-between items-center">
                            <span>Sent by Admin ID {log.adminId} on {new Date(log.sentAt).toLocaleString()}</span>
                            <span>
                                <span className="text-green-400">Success: {log.stats.success}</span> | <span className="text-red-400">Failed: {log.stats.failed}</span>
                            </span>
                        </div>
                    </div>
                )) : (
                    <p className="text-center text-gray-400 py-8">No broadcast history found.</p>
                )}
            </div>
        </div>
    );
};

export default BroadcastHistory;