import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/mockApiService';
import { RedeemCode } from '../../types';
import { styleText } from '../../constants';
import { useToast } from '../../contexts/ToastContext';

const RedeemCodes: React.FC = () => {
    const { addToast } = useToast();
    const [codes, setCodes] = useState<RedeemCode[]>([]);
    const [loading, setLoading] = useState(true);
    const [newCode, setNewCode] = useState('');
    const [newAmount, setNewAmount] = useState('');
    const [newLimit, setNewLimit] = useState('');
    const [error, setError] = useState('');

    const fetchCodes = useCallback(async () => {
        setLoading(true);
        const data = await api.getRedeemCodes();
        setCodes(data);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchCodes();
    }, [fetchCodes]);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        const amountNum = parseInt(newAmount);
        const limitNum = parseInt(newLimit);

        if (!newCode || isNaN(amountNum) || isNaN(limitNum) || amountNum <= 0 || limitNum <= 0) {
            setError('Please fill all fields with valid values.');
            return;
        }
        
        const result = await api.createRedeemCode(newCode, amountNum, limitNum);
        if (result.success) {
            addToast(result.message, 'success');
            setNewCode('');
            setNewAmount('');
            setNewLimit('');
            await fetchCodes();
        } else {
            setError(result.message);
        }
    };

    const handleDelete = async (code: string) => {
        const result = await api.deleteRedeemCode(code);
        if (result.success) {
            addToast(result.message, 'info');
            await fetchCodes();
        } else {
            addToast(result.message, 'error');
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div></div>;
    }

    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('Redeem Codes')}</h1>

            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 mb-8">
                <h2 className="text-lg font-bold text-white mb-4">{styleText('Create New Code')}</h2>
                <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <input type="text" value={newCode} onChange={e => setNewCode(e.target.value)} placeholder="Code (e.g., WELCOME50)" className="md:col-span-1 bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"/>
                    <input type="number" value={newAmount} onChange={e => setNewAmount(e.target.value)} placeholder="Diamond Amount" className="md:col-span-1 bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"/>
                    <input type="number" value={newLimit} onChange={e => setNewLimit(e.target.value)} placeholder="Usage Limit" className="md:col-span-1 bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"/>
                    <button type="submit" className="md:col-span-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg text-sm">{styleText('Create Code')}</button>
                </form>
                {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
            </div>
            
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700">
                 <h2 className="text-lg font-bold text-white mb-4">{styleText('Existing Codes')}</h2>
                 <div className="max-h-96 overflow-y-auto pr-2 space-y-3">
                     {codes.length > 0 ? codes.map(code => (
                         <div key={code.code} className="flex justify-between items-center bg-gray-700/50 p-3 rounded-lg">
                             <div>
                                 <p className="font-mono text-gray-200">{code.code}</p>
                                 <p className="text-xs text-gray-400">💎 {code.amount} | Limit: {code.usedBy.length}/{code.maxUsers}</p>
                             </div>
                             <div className="flex items-center gap-4">
                               <span className={`text-xs font-bold ${code.isActive && code.usedBy.length < code.maxUsers ? 'text-green-400' : 'text-red-400'}`}>
                                   {code.isActive && code.usedBy.length < code.maxUsers ? 'ACTIVE' : 'INACTIVE'}
                               </span>
                               <button onClick={() => handleDelete(code.code)} className="text-red-400 hover:text-red-300 text-xs font-semibold">{styleText('DELETE')}</button>
                             </div>
                         </div>
                     )) : <p className="text-gray-400 text-center">{styleText('No redeem codes found.')}</p>}
                 </div>
            </div>
        </div>
    );
};

export default RedeemCodes;
