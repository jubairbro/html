import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../services/mockApiService';
import { Transaction } from '../../types';
import { styleText } from '../../constants';

const Transactions: React.FC = () => {
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [totalTxs, setTotalTxs] = useState(0);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const txsPerPage = 15;

    const fetchTxs = useCallback(async (page: number) => {
        setLoading(true);
        const { transactions: fetchedTxs, total } = await api.getAllTransactions(page, txsPerPage);
        setTransactions(fetchedTxs);
        setTotalTxs(total);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchTxs(currentPage);
    }, [currentPage, fetchTxs]);

    const totalPages = Math.ceil(totalTxs / txsPerPage);

    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('System-Wide Transactions')}</h1>

            <div className="bg-gray-800/50 rounded-xl overflow-hidden border border-gray-700">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                            <tr>
                                <th scope="col" className="px-6 py-3">User</th>
                                <th scope="col" className="px-6 py-3">Amount</th>
                                <th scope="col" className="px-6 py-3">Reason</th>
                                <th scope="col" className="px-6 py-3">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                             {loading ? (
                                <tr><td colSpan={4} className="text-center py-8"><div className="w-8 h-8 border-2 border-t-transparent border-white rounded-full animate-spin mx-auto"></div></td></tr>
                            ) : transactions.map(tx => (
                                <tr key={tx.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                                    <td className="px-6 py-4">{tx.username} ({tx.userId})</td>
                                    <td className={`px-6 py-4 font-bold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                        {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString()} 💎
                                    </td>
                                    <td className="px-6 py-4">{tx.reason.replace(/_/g, ' ').toUpperCase()}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">{new Date(tx.timestamp).toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {transactions.length === 0 && !loading && <p className="text-center py-8 text-gray-400">No transactions found.</p>}
            </div>
            
             {totalPages > 1 && (
                <div className="flex justify-center mt-6">
                    <nav className="inline-flex rounded-md shadow">
                        <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-4 py-2 text-sm font-medium text-white bg-gray-800 rounded-l-lg hover:bg-gray-700 disabled:opacity-50">Prev</button>
                        <span className="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-900">Page {currentPage} of {totalPages}</span>
                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages} className="px-4 py-2 text-sm font-medium text-white bg-gray-800 rounded-r-lg hover:bg-gray-700 disabled:opacity-50">Next</button>
                    </nav>
                </div>
            )}
        </div>
    );
};

export default Transactions;
