import React, { useState, useEffect } from 'react';
import { api } from '../../services/mockApiService';
import { styleText } from '../../constants';
import { User } from '../../types';

interface SystemStats {
    users: number;
    activeToday: number;
    smss: number;
    diamonds: number;
    bannedUsers: number;
    blacklistedNumbers: number;
    totalTransactions: number;
}

const StatCard: React.FC<{ title: string, value: string | number, icon: string }> = ({ title, value, icon }) => (
    <div className="bg-gray-800/50 p-6 rounded-xl flex items-center gap-4 hover:bg-gray-700/50 transition-colors border border-gray-700">
        <div className="text-4xl">{icon}</div>
        <div>
            <p className="text-gray-400 text-sm font-medium">{title}</p>
            <p className="text-2xl font-bold text-white">{value.toLocaleString()}</p>
        </div>
    </div>
);


const AdminDashboard: React.FC = () => {
    const [stats, setStats] = useState<SystemStats | null>(null);
    const [recentUsers, setRecentUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            const [systemStats, users] = await Promise.all([
                api.getSystemStats(),
                api.getRecentUsers(5)
            ]);
            setStats(systemStats);
            setRecentUsers(users);
            setLoading(false);
        };
        fetchData();
    }, []);

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div></div>;
    }

    if (!stats) return <p className="text-center text-gray-400">Could not load system stats.</p>;

    return (
        <div className="bg-gray-900 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('System Dashboard')}</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <StatCard title={styleText('Total Users')} value={stats.users} icon="👥" />
                <StatCard title={styleText('Active Today')} value={stats.activeToday} icon="📊" />
                <StatCard title={styleText('Total SMS Sent')} value={stats.smss} icon="💣" />
                <StatCard title={styleText('Circulating Diamonds')} value={stats.diamonds} icon="💎" />
                 <StatCard title={styleText('Total Transactions')} value={stats.totalTransactions} icon="📜" />
                <StatCard title={styleText('Banned Users')} value={stats.bannedUsers} icon="🚫" />
                <StatCard title={styleText('Blacklisted Numbers')} value={stats.blacklistedNumbers} icon="🛡️" />
            </div>

            <div>
                <h2 className="text-xl font-bold text-white mb-4">{styleText('Recently Joined Users')}</h2>
                <div className="bg-gray-800/50 rounded-xl border border-gray-700">
                    <div className="divide-y divide-gray-700">
                        {recentUsers.map(user => (
                            <div key={user.id} className="p-4 flex justify-between items-center">
                                <div>
                                    <p className="font-semibold text-gray-200">{user.firstName} (@{user.username})</p>
                                    <p className="text-sm text-gray-400">ID: {user.id}</p>
                                </div>
                                <div className="text-sm text-gray-300">{new Date(user.joinedDate).toLocaleDateString()}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
