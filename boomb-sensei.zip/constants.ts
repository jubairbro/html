export const APP_NAME = 'BOOMB SENSEI';
export const OWNER_ID = 1; // Default first user
export const DEFAULT_DAILY_BONUS = 200;
export const DEFAULT_REFERRAL_BONUS = 150;
export const DEFAULT_SMS_COST = 1;
export const DEFAULT_MAX_SMS_AMOUNT = 200;
export const DEFAULT_MAX_REFERRALS = 50;
export const SIGNUP_REFERRAL_BONUS = 50;
export const REFERRAL_DOMAIN = 'back.zone.id';

export const SMALL_CAPS_MAPPING: { [key: string]: string } = {
    'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ғ', 'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ',
    'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ',
    's': 's', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ',
    '0': '𝟶', '1': '𝟷', '2': '𝟸', '3': '𝟹', '4': '𝟺', '5': '𝟻', '6': '𝟼', '7': '𝟽', '8': '𝟾', '9': '𝟿'
};

export const styleText = (text: string): string => {
    // This now handles uppercase, lowercase, numbers, and symbols gracefully.
    return text.toString().split('').map(char => {
        const lowerChar = char.toLowerCase();
        if (SMALL_CAPS_MAPPING[lowerChar]) {
            return SMALL_CAPS_MAPPING[lowerChar];
        }
        return char;
    }).join('');
};
